package cnk.acco_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)

public class EntityDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String entityName;
   private java.lang.String entityMarket;
   private java.lang.String entityType;

   public EntityDetails()
   {
   }

   public java.lang.String getEntityName()
   {
      return this.entityName;
   }

   public void setEntityName(java.lang.String entityName)
   {
      this.entityName = entityName;
   }

   public java.lang.String getEntityMarket()
   {
      return this.entityMarket;
   }

   public void setEntityMarket(java.lang.String entityMarket)
   {
      this.entityMarket = entityMarket;
   }

   public java.lang.String getEntityType()
   {
      return this.entityType;
   }

   public void setEntityType(java.lang.String entityType)
   {
      this.entityType = entityType;
   }

   public EntityDetails(java.lang.String entityName,
         java.lang.String entityMarket, java.lang.String entityType)
   {
      this.entityName = entityName;
      this.entityMarket = entityMarket;
      this.entityType = entityType;
   }

}