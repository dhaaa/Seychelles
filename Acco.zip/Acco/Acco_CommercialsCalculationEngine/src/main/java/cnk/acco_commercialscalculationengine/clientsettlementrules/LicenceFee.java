package cnk.acco_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)

public class LicenceFee implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees;

   public LicenceFee()
   {
   }

   public cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees getOtherFees()
   {
      return this.otherFees;
   }

   public void setOtherFees(
         cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

   public LicenceFee(
         cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

}