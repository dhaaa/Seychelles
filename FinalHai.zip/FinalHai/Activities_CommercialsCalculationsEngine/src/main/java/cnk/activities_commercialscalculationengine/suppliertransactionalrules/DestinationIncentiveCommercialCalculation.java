package cnk.activities_commercialscalculationengine.suppliertransactionalrules;

public class DestinationIncentiveCommercialCalculation {

	 static final long serialVersionUID = 1L;

	   private java.lang.String selectedRow;

	   public DestinationIncentiveCommercialCalculation()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public DestinationIncentiveCommercialCalculation(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }
}
