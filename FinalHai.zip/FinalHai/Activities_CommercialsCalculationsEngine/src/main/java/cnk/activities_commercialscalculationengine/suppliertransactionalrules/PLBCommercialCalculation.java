package cnk.activities_commercialscalculationengine.suppliertransactionalrules;

public class PLBCommercialCalculation {

	 static final long serialVersionUID = 1L;

	   private java.lang.String selectedRow;

	   public PLBCommercialCalculation()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public PLBCommercialCalculation(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }
}
