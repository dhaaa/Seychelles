package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RoomDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String roomType;
   private java.lang.String roomCategory;
   private boolean isAdvanced;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails;
   private double totalReceivables;
   private double totalPayables;
   private java.util.List<java.lang.String> commercialsApplied;
   private double totalFare;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials;

   public void ClientCommercialCalculation(String CommercialName, String CommercialType, String CommercialProperty, double RetentionPercentage, double RetentionAmountPercentage, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetls)
   {

      if (CommercialProperty.toUpperCase().equals("RETENTION"))
         CalculateRetentionCommercial(CommercialName, CommercialType, RetentionPercentage, RetentionAmountPercentage, entyDtls, roomDetls);
      else
         CalculateAdditionalCommercial(CommercialName, AdditionalPercentage, AdditionalAmount, FareComponent, TaxComponent, Currency, entyDtls, roomDetls);
   }

   public void CalculateRetentionCommercial(String CommercialName, String CommercialType, double RetentionPercentage, double RetentionAmountPercentage, EntityDetails entyDtls, RoomDetails roomDetls)
   {
      RetentionCommercialDetails retComDtls = new RetentionCommercialDetails();
      double tempAmount = 0;
      if (entyDtls.getParentEntityName() == null)
      {
         for (CommercialDetails commdetails : roomDetls.getCommercialDetails())
         {
            if (CommercialName.equals(commdetails.getCommercialName()))
            {
               if (RetentionAmountPercentage != 0)
               {
                  tempAmount = commdetails.getCommercialCalculationAmount() * (RetentionAmountPercentage / 100);
                  retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                  retComDtls.setRemainingAmount(commdetails.getCommercialCalculationAmount() - tempAmount);
               }
               if (RetentionPercentage != 0)
               {
                  double percentageAmount = 0;
                  if (commdetails.getCommercialCalculationAmount() != 0)
                  {
                     percentageAmount = (commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount()) * (RetentionPercentage / 100);
                     retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  else
                  {
                     percentageAmount = commdetails.getCommercialAmount() * (RetentionPercentage / 100);
                     retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  retComDtls.setRetentionPercentage(RetentionPercentage);
               }
               retComDtls.setCommercialAmount(tempAmount);
               retComDtls.setCommercialName(CommercialName);
            }

         }
      }
      else
      {
         for (EntityCommercials parentEntity : roomDetls.getEntityCommercials())
         {
            if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName()))
            {
               for (RetentionCommercialDetails retcommdetails : parentEntity.getRetentionCommercialDetails())
               {
                  if (CommercialName.equals(retcommdetails.getCommercialName()))
                  {
                     if (RetentionAmountPercentage != 0)
                     {
                        tempAmount = retcommdetails.getRemainingAmount() * (RetentionAmountPercentage / 100);
                        retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                        retComDtls.setRemainingAmount(retcommdetails.getRemainingAmount() - tempAmount);
                     }
                     if (RetentionPercentage != 0)
                     {
                        double percentageAmount = 0;
                        percentageAmount = retcommdetails.getRemainingPercentageAmount() * (RetentionPercentage / 100);
                        tempAmount = tempAmount + percentageAmount;
                        retComDtls.setRetentionPercentage(RetentionPercentage);
                        retComDtls.setRemainingPercentageAmount(retcommdetails.getRemainingPercentageAmount() - percentageAmount);
                     }
                     retComDtls.setCommercialAmount(tempAmount);
                     retComDtls.setCommercialName(CommercialName);
                  }
               }
            }
         }
      }
      if (roomDetls.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
         entityCommercials.getRetentionCommercialDetails().add(retComDtls);
         roomDetls.setEntityCommercials(new ArrayList<EntityCommercials>());
         roomDetls.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetls.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getRetentionCommercialDetails() == null)
                  entityComm.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
               entityComm.getRetentionCommercialDetails().add(retComDtls);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
            entityCommercials.getRetentionCommercialDetails().add(retComDtls);
            roomDetls.getEntityCommercials().add(entityCommercials);
         }

      }
      entyDtls.getEntityStatus().add(CommercialName + "RetentionCompleted");
   }

   public void CalculateAdditionalCommercial(String CommercialName, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetls) {

		AdditionalCommercialDetails addComm = new AdditionalCommercialDetails();
		addComm.setCommercialName(CommercialName);
		addComm.setCommercialFareComponent(FareComponent);

		if (AdditionalPercentage > 0) {
			addComm.setCommercialCalculationPercentage(AdditionalPercentage);
			if (TaxComponent == null) {
				if (FareComponent.equals("Total")) addComm.setCommercialAmount(roomDetls.getTotalFare() * AdditionalPercentage / 100);
				else addComm.setCommercialAmount(roomDetls.getFareBreakUp().getBaseFare() * AdditionalPercentage / 100);
			}
			else {
				if (FareComponent.equals("Basic")) addComm.setCommercialAmount(roomDetls.getFareBreakUp().getBaseFare());

				List < String > tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
				double commercialAmount = 0;
				for (TaxDetails taxes: roomDetls.getFareBreakUp().getTaxDetails()) {
					for (String tempTaxName: tempTaxDetails) {
						if (tempTaxName.equals(taxes.getTaxName())) {
							commercialAmount = commercialAmount + taxes.getTaxValue();
							if (addComm.getCommercialFareComponent() == null) addComm.setCommercialFareComponent(tempTaxName);
							else addComm.setCommercialFareComponent(addComm.getCommercialFareComponent() + "," + tempTaxName);
						}
					}
				}
				addComm.setCommercialAmount((addComm.getCommercialAmount() + commercialAmount) * AdditionalPercentage / 100);
			}
		}
		if (AdditionalAmount > 0) {
			addComm.setCommercialAmount(addComm.getCommercialAmount() + AdditionalAmount);
			if (addComm.getCommercialCurrency() == null) addComm.setCommercialCurrency(Currency);
			addComm.setCommercialCalculationAmount(AdditionalAmount);
		}

		if (roomDetls.getEntityCommercials() == null) {
			EntityCommercials entityCommercials = new EntityCommercials();
			entityCommercials.setEntityName(entyDtls.getEntityName());
			roomDetls.setEntityCommercials(new ArrayList < EntityCommercials > ());
			entityCommercials.setAdditionalCommercialDetails(new ArrayList < AdditionalCommercialDetails > ());
			entityCommercials.getAdditionalCommercialDetails().add(addComm);
			roomDetls.getEntityCommercials().add(entityCommercials);
		}
		else {
			boolean isEntityPresent = false;
			for (EntityCommercials entityComm: roomDetls.getEntityCommercials()) {
				if (entyDtls.getEntityName().equals(entityComm.getEntityName())) {
					if (entityComm.getAdditionalCommercialDetails() == null) entityComm.setAdditionalCommercialDetails(new ArrayList < AdditionalCommercialDetails > ());
					entityComm.getAdditionalCommercialDetails().add(addComm);
					isEntityPresent = true;
					break;
				}
			}
			if (isEntityPresent == false) {
				EntityCommercials entityCommercials = new EntityCommercials();
				entityCommercials.setEntityName(entyDtls.getEntityName());
				entityCommercials.setAdditionalCommercialDetails(new ArrayList < AdditionalCommercialDetails > ());
				entityCommercials.getAdditionalCommercialDetails().add(addComm);
				roomDetls.getEntityCommercials().add(entityCommercials);
			}

		}
		entyDtls.getEntityStatus().add(CommercialName + "AdditionalCompleted");
	}

    
    public void CalculateMarkUpCommercial(double MarkUpPercentage, double MarkUpAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetls, double MinSellingPrice) {
		System.out.println("Hi1");
		MarkUpCommercialDetails markComm = new MarkUpCommercialDetails();
		
		if (entyDtls.getParentEntityName() == null) {

			if (roomDetls.getFareBreakUp() == null) {
				ParentFareBreakUpNull(MarkUpPercentage, MarkUpAmount, entyDtls, roomDetls, markComm);
				if ((markComm.getCommercialAmount() + roomDetls.getTotalFare()) < MinSellingPrice) {
					System.out.println("Hi4");
					markComm.setTotalFare(MinSellingPrice);
				}

			}
			else {
				System.out.println("Hi3");
			     ParentMarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, entyDtls, roomDetls, markComm);
				System.out.println("MarkUpCommercialAmount	" + markComm.getCommercialAmount() + "	roomDetlsa Total Fare	" + roomDetls.getTotalFare() + "	Min Selling Price	" + MinSellingPrice);
				if ((markComm.getCommercialAmount() + roomDetls.getTotalFare()) < MinSellingPrice) {
					System.out.println("Hi4");
					markComm.setTotalFare(MinSellingPrice);
					markComm.getFareBreakUp().setBaseFare(roomDetls.getFareBreakUp().getBaseFare() + (MinSellingPrice - roomDetls.getTotalFare()));
					markComm.getFareBreakUp().getTaxDetails().removeAll(markComm.getFareBreakUp().getTaxDetails());
					markComm.getFareBreakUp().getTaxDetails().addAll(roomDetls.getFareBreakUp().getTaxDetails());
				}
				
			}
		}

		else {

			System.out.println("Hi7");
			for (EntityCommercials parentEntity: roomDetls.getEntityCommercials()) {
				System.out.println("Hi8");
				if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName())) {

					System.out.println("Hi9");
					if (parentEntity.getMarkUpCommercialDetails().getFareBreakUp() == null) {
						//MarkUpCommercialDetails markComm = new MarkUpCommercialDetails();
						ChildFareBreakUpNull(MarkUpPercentage, MarkUpAmount, entyDtls, roomDetls, markComm, parentEntity.getMarkUpCommercialDetails());
						if ((markComm.getCommercialAmount() + parentEntity.getMarkUpCommercialDetails().getTotalFare()) < MinSellingPrice) {
							System.out.println("Hi4");
							markComm.setTotalFare(MinSellingPrice);
						}
					}
					else {
						//MarkUpCommercialDetails markComm = new MarkUpCommercialDetails();
						System.out.println("Hi10");
						ChildMarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, entyDtls, roomDetls, markComm, parentEntity.getMarkUpCommercialDetails());
						System.out.println("Hi100");
						if ((markComm.getCommercialAmount() + parentEntity.getMarkUpCommercialDetails().getTotalFare()) < MinSellingPrice) {
							markComm.setTotalFare(MinSellingPrice);
							markComm.getFareBreakUp().setBaseFare(parentEntity.getMarkUpCommercialDetails().getFareBreakUp().getBaseFare() + (MinSellingPrice - parentEntity.getMarkUpCommercialDetails().getTotalFare()));
							markComm.getFareBreakUp().getTaxDetails().removeAll(markComm.getFareBreakUp().getTaxDetails());
							markComm.getFareBreakUp().getTaxDetails().addAll(roomDetls.getFareBreakUp().getTaxDetails());
						}
						System.out.println("Hi101");
					}
				}
			}

		}
		
		//entyDtls.getEntityStatus().add(entyDtls.getEntityName() + "MarkUpCompleted");

	}

	public  void ParentMarkUpCalculation(double MarkUpPercentage, double MarkUpAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetls, MarkUpCommercialDetails markComm) {
		markComm.setFareBreakUp(new FareBreakUp());
		markComm.getFareBreakUp().setTaxDetails(new ArrayList < TaxDetails > ());
		markComm.setCommercialAmount(0.0);
		if (MarkUpPercentage > 0) {
			System.out.println("Hi15");
			markComm.setCommercialCalculationPercentage(MarkUpPercentage);
			if (TaxComponent == null) {
				System.out.println("Hi16");
					if (FareComponent.equals("Total")) {
						System.out.println("Hi17");
						double commercialAmt = roomDetls.getTotalFare() * MarkUpPercentage / 100;
						markComm.setCommercialAmount(commercialAmt);
						markComm.setCommercialFareComponent(FareComponent);
						markComm.getFareBreakUp().setBaseFare(roomDetls.getFareBreakUp().getBaseFare() + (roomDetls.getFareBreakUp().getBaseFare() * MarkUpPercentage / 100));
						for (TaxDetails taxes: roomDetls.getFareBreakUp().getTaxDetails()) {
							TaxDetails td = new TaxDetails();
							td.setTaxName(taxes.getTaxName());
							td.setTaxValue(taxes.getTaxValue() + (taxes.getTaxValue() * MarkUpPercentage / 100));
							System.out.println("Hi32");
							markComm.getFareBreakUp().getTaxDetails().add(td);

						}
					}

					else {
						System.out.println("Hi18");
						markComm.setCommercialAmount(roomDetls.getFareBreakUp().getBaseFare() * MarkUpPercentage / 100);
						markComm.setCommercialFareComponent(FareComponent);
						markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + roomDetls.getFareBreakUp().getBaseFare());
						for (TaxDetails taxes: roomDetls.getFareBreakUp().getTaxDetails()) {
							TaxDetails td = new TaxDetails();
							td.setTaxName(taxes.getTaxName());
							td.setTaxValue(taxes.getTaxValue());
							System.out.println("Hi32");
							markComm.getFareBreakUp().getTaxDetails().add(td);
						
					}
				}
			}
			else {
				System.out.println("Hi399");
				markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + roomDetls.getFareBreakUp().getBaseFare());
				System.out.println("Hi499");
				System.out.println("FareComponent" + FareComponent);
				if (! (FareComponent == null)) {
						System.out.println("Hi19");
						markComm.setCommercialAmount(roomDetls.getFareBreakUp().getBaseFare() * MarkUpPercentage / 100);
						markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + roomDetls.getFareBreakUp().getBaseFare());
						markComm.setCommercialFareComponent(FareComponent);
				}
				System.out.println("Hi199");
				List < String > tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
				System.out.println("Hi299");
				double commercialAmount = 0;
				for (TaxDetails taxes: roomDetls.getFareBreakUp().getTaxDetails()) {
					TaxDetails td = new TaxDetails();
					 td.setTaxName(taxes.getTaxName());
					  td.setTaxValue(taxes.getTaxValue());
					System.out.println("Hi20");
					for (String tempTaxName: tempTaxDetails) {
						System.out.println("Hi21");
						if (tempTaxName.equals(taxes.getTaxName())) {
							double TaxComVal = (taxes.getTaxValue() * MarkUpPercentage / 100);
							td.setTaxValue(taxes.getTaxValue() + TaxComVal);
							System.out.println("Hi22");
							commercialAmount = commercialAmount + TaxComVal;

							if (markComm.getCommercialFareComponent() == null)
								markComm.setCommercialFareComponent(tempTaxName);
							else 
								markComm.setCommercialFareComponent(markComm.getCommercialFareComponent() + "," + tempTaxName);
						}
					}
					markComm.getFareBreakUp().getTaxDetails().add(td);
				}
				System.out.println("Hi23");
				markComm.setCommercialAmount((markComm.getCommercialAmount() + commercialAmount));

			}
		}
		if (MarkUpAmount > 0) {
			System.out.println("Hi24");
			markComm.setCommercialAmount(markComm.getCommercialAmount() + MarkUpAmount);
			if (MarkUpPercentage == 0)
			{
				markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + markComm.getFareBreakUp().getBaseFare());
				for (TaxDetails taxes: roomDetls.getFareBreakUp().getTaxDetails()) {
					TaxDetails td = new TaxDetails();
					td.setTaxName(taxes.getTaxName());
					td.setTaxValue(taxes.getTaxValue());
					System.out.println("Hi32");
					markComm.getFareBreakUp().getTaxDetails().add(td);
				
			}
			}
			else {
					if (! (FareComponent == null))
						markComm.getFareBreakUp().setBaseFare(markComm.getFareBreakUp().getBaseFare() + MarkUpAmount);
					else
					{
						List < String > tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
						System.out.println("TempTaxDetails"+tempTaxDetails.toString());
						for (TaxDetails taxes: markComm.getFareBreakUp().getTaxDetails()) {
							System.out.println("TaxName is:"+taxes.getTaxName());
							for (String tempTaxName: tempTaxDetails) {
								System.out.println("TempTaxName is:"+tempTaxName.toString());
								if (tempTaxName.equals(taxes.getTaxName())) {
									System.out.println("Boolean is"+tempTaxName.equals(taxes.getTaxName()));
						taxes.setTaxValue(taxes.getTaxValue() + MarkUpAmount);
									}
							}
					}
				}
			}
		}	 
			//markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + roomDetls.getFareBreakUp().getBaseFare());
			markComm.setCommercialCurrency(Currency);
			markComm.setCommercialCalculationAmount(MarkUpAmount);
			markComm.setTotalFare(markComm.getCommercialAmount() + roomDetls.getTotalFare());

		if (roomDetls.getEntityCommercials() == null) {
			EntityCommercials entityCommercials = new EntityCommercials();
			entityCommercials.setEntityName(entyDtls.getEntityName());
			roomDetls.setEntityCommercials(new ArrayList < EntityCommercials > ());
			entityCommercials.setMarkUpCommercialDetails(markComm);
			roomDetls.getEntityCommercials().add(entityCommercials);
		}
		else {
			boolean isEntityPresent = false;
			for (EntityCommercials entitycommercials: roomDetls.getEntityCommercials()) {
				if (entitycommercials.getEntityName().equals(entyDtls.getEntityName())) {
					entitycommercials.setMarkUpCommercialDetails(markComm);
					isEntityPresent = true;
				}
			}
			if (isEntityPresent == false) {
				EntityCommercials entityCommercials = new EntityCommercials();
				entityCommercials.setEntityName(entyDtls.getEntityName());
				entityCommercials.setMarkUpCommercialDetails(markComm);
				roomDetls.getEntityCommercials().add(entityCommercials);
			}
		}
		markComm.setCommercialName("MarkUp");
	}
	public  void ChildMarkUpCalculation(double MarkUpPercentage, double MarkUpAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetls, MarkUpCommercialDetails markComm, MarkUpCommercialDetails markComm1) {

		markComm.setFareBreakUp(new FareBreakUp());
		markComm.getFareBreakUp().setTaxDetails(new ArrayList < TaxDetails > ());
		markComm.setCommercialAmount(0.0);
		if (MarkUpPercentage > 0) {
			System.out.println("Hi15");
			markComm.setCommercialCalculationPercentage(MarkUpPercentage);
			if (TaxComponent == null) {
				System.out.println("Hi16");
				System.out.println(FareComponent);
					System.out.println("Hi177");
					if (FareComponent.equals("Total")) {
						System.out.println("Hi17");
						double commercialAmt = markComm1.getTotalFare() * MarkUpPercentage / 100;
						markComm.setCommercialAmount(commercialAmt);
						markComm.setCommercialFareComponent(FareComponent);
						markComm.getFareBreakUp().setBaseFare((markComm1.getFareBreakUp().getBaseFare() * MarkUpPercentage / 100) + markComm1.getFareBreakUp().getBaseFare());
						for (TaxDetails taxes: markComm1.getFareBreakUp().getTaxDetails()) {
							TaxDetails td = new TaxDetails();
							td.setTaxName(taxes.getTaxName());
							td.setTaxValue(taxes.getTaxValue() + (taxes.getTaxValue() * MarkUpPercentage / 100));
							System.out.println("Hi32");
							markComm.getFareBreakUp().getTaxDetails().add(td);
						}
					}
					else {
						System.out.println("Hi18");
						markComm.setCommercialAmount(markComm1.getFareBreakUp().getBaseFare() * MarkUpPercentage / 100);
						markComm.setCommercialFareComponent(FareComponent);
						markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + markComm1.getFareBreakUp().getBaseFare());
						System.out.println("ParentBaseFare:" + markComm1.getFareBreakUp().getBaseFare() + "  ChildBaseFare" + markComm.getFareBreakUp().getBaseFare());
						for (TaxDetails taxes: markComm1.getFareBreakUp().getTaxDetails()) {
							TaxDetails td = new TaxDetails();
							td.setTaxName(taxes.getTaxName());
							td.setTaxValue(taxes.getTaxValue());
							System.out.println("Hi32");
							markComm.getFareBreakUp().getTaxDetails().add(td);
						}
					}
			}
			else {
				markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + markComm1.getFareBreakUp().getBaseFare());
				if (! (FareComponent == null)) {
						System.out.println("Hi19");
						markComm.setCommercialAmount(markComm1.getFareBreakUp().getBaseFare() * MarkUpPercentage / 100);
						markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + markComm1.getFareBreakUp().getBaseFare());
						markComm.setCommercialFareComponent(FareComponent);
				}
				List < String > tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
				double commercialAmount = 0;
				for (TaxDetails taxes: markComm1.getFareBreakUp().getTaxDetails()) {
					TaxDetails td = new TaxDetails();
					 td.setTaxName(taxes.getTaxName());
					  td.setTaxValue(taxes.getTaxValue());
					System.out.println("Hi20");
					for (String tempTaxName: tempTaxDetails) {
						System.out.println("Hi21");
						if (tempTaxName.equals(taxes.getTaxName())) {
							double TaxComVal = (taxes.getTaxValue() * MarkUpPercentage / 100);
							td.setTaxValue(taxes.getTaxValue() + TaxComVal);
							System.out.println("Hi22");
							commercialAmount = commercialAmount + TaxComVal;

							if (markComm.getCommercialFareComponent() == null)
								markComm.setCommercialFareComponent(tempTaxName);
							else 
								markComm.setCommercialFareComponent(markComm.getCommercialFareComponent() + "," + tempTaxName);
						}
					}
					markComm.getFareBreakUp().getTaxDetails().add(td);
				}
				System.out.println("Hi23");
				markComm.setCommercialAmount((markComm.getCommercialAmount() + commercialAmount));
			}
		}
		if (MarkUpAmount > 0) {
			System.out.println("Hi24");
			markComm.setCommercialAmount(markComm.getCommercialAmount() + MarkUpAmount);
			if (MarkUpPercentage == 0)
			{
				markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + markComm1.getFareBreakUp().getBaseFare());
				for (TaxDetails taxes: markComm1.getFareBreakUp().getTaxDetails()) {
							TaxDetails td = new TaxDetails();
							td.setTaxName(taxes.getTaxName());
							td.setTaxValue(taxes.getTaxValue());
							System.out.println("Hi32");
							markComm.getFareBreakUp().getTaxDetails().add(td);
						}
			}
			else
			{
					if (! (FareComponent == null)) 
						markComm.getFareBreakUp().setBaseFare(markComm.getFareBreakUp().getBaseFare() + MarkUpAmount);
					else
					{
						List < String > tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
						for (TaxDetails taxes: markComm.getFareBreakUp().getTaxDetails()) {
							for (String tempTaxName: tempTaxDetails) {
								if (tempTaxName.equals(taxes.getTaxName())) {
						taxes.setTaxValue(taxes.getTaxValue() + MarkUpAmount);
					}
							}
						}
				}
				}
			}
			markComm.setCommercialCurrency(Currency);
			markComm.setCommercialCalculationAmount(MarkUpAmount);
			System.out.println("ParentBaseFare:" + markComm1.getFareBreakUp().getBaseFare() + "  ChildBaseFare" + markComm.getFareBreakUp().getBaseFare());
			markComm.setTotalFare(markComm.getCommercialAmount() + markComm1.getTotalFare());
		System.out.println("FareComponent is  " + FareComponent);

		boolean isEntityPresent = false;
		for (EntityCommercials entitycommercials: roomDetls.getEntityCommercials()) {
			if (entitycommercials.getEntityName().equals(entyDtls.getEntityName())) {
				entitycommercials.setMarkUpCommercialDetails(markComm);
				isEntityPresent = true;
			}
		}
		if (isEntityPresent == false) {
			EntityCommercials entityCommercials = new EntityCommercials();
			entityCommercials.setEntityName(entyDtls.getEntityName());
			entityCommercials.setMarkUpCommercialDetails(markComm);
			roomDetls.getEntityCommercials().add(entityCommercials);
		}

		markComm.setCommercialName("MarkUp");
	}
	public  void ParentFareBreakUpNull(double MarkUpPercentage, double MarkUpAmount, EntityDetails entyDtls, RoomDetails roomDetls, MarkUpCommercialDetails markComm) {
		double totalFare = roomDetls.getTotalFare();
		double markUpTotalFare = 0;
		if (MarkUpPercentage > 0) {
			markComm.setTotalFare(totalFare + (totalFare * MarkUpPercentage / 100));
			markUpTotalFare = markComm.getTotalFare();
		}
		if (MarkUpAmount > 0 && markUpTotalFare > 0) markComm.setTotalFare(markUpTotalFare + MarkUpAmount);
		else markComm.setTotalFare(totalFare + MarkUpAmount);

		if (roomDetls.getEntityCommercials() == null) {
			EntityCommercials entityCommercials = new EntityCommercials();
			entityCommercials.setEntityName(entyDtls.getEntityName());
			roomDetls.setEntityCommercials(new ArrayList < EntityCommercials > ());
			entityCommercials.setMarkUpCommercialDetails(markComm);
			roomDetls.getEntityCommercials().add(entityCommercials);
		}
		else {
			boolean isEntityPresent = false;
			for (EntityCommercials entitycommercials: roomDetls.getEntityCommercials()) {
				if (entitycommercials.getEntityName().equals(entyDtls.getEntityName())) {
					entitycommercials.setMarkUpCommercialDetails(markComm);
					isEntityPresent = true;
				}
			}
			if (isEntityPresent == false) {
				EntityCommercials entityCommercials = new EntityCommercials();
				entityCommercials.setEntityName(entyDtls.getEntityName());
				entityCommercials.setMarkUpCommercialDetails(markComm);
				roomDetls.getEntityCommercials().add(entityCommercials);
			}
		}
		markComm.setCommercialName("MarkUp");

	}
	public  void ChildFareBreakUpNull(double MarkUpPercentage, double MarkUpAmount, EntityDetails entyDtls, RoomDetails roomDetls, MarkUpCommercialDetails markComm, MarkUpCommercialDetails markComm1) {
		double totalFare = markComm1.getTotalFare();
		double markUpTotalFare = 0;
		if (MarkUpPercentage > 0) {
			markComm.setTotalFare(totalFare + (totalFare * MarkUpPercentage / 100));
			markUpTotalFare = markComm.getTotalFare();
		}
		if (MarkUpAmount > 0 && markUpTotalFare > 0) markComm.setTotalFare(markUpTotalFare + MarkUpAmount);
		else markComm.setTotalFare(totalFare + MarkUpAmount);

		boolean isEntityPresent = false;
		for (EntityCommercials entitycommercials: roomDetls.getEntityCommercials()) {
			if (entitycommercials.getEntityName().equals(entyDtls.getEntityName())) {
				entitycommercials.setMarkUpCommercialDetails(markComm);
				isEntityPresent = true;
			}
		}
		if (isEntityPresent == false) {
			EntityCommercials entityCommercials = new EntityCommercials();
			entityCommercials.setEntityName(entyDtls.getEntityName());
			entityCommercials.setMarkUpCommercialDetails(markComm);
			roomDetls.getEntityCommercials().add(entityCommercials);
		}
		markComm.setCommercialName("MarkUp");

	}
	




   public RoomDetails()
   {
   }

   public java.lang.String getRoomType()
   {
      return this.roomType;
   }

   public void setRoomType(java.lang.String roomType)
   {
      this.roomType = roomType;
   }

   public java.lang.String getRoomCategory()
   {
      return this.roomCategory;
   }

   public void setRoomCategory(java.lang.String roomCategory)
   {
      this.roomCategory = roomCategory;
   }

   public boolean isIsAdvanced()
   {
      return this.isAdvanced;
   }

   public void setIsAdvanced(boolean isAdvanced)
   {
      this.isAdvanced = isAdvanced;
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp getFareBreakUp()
   {
      return this.fareBreakUp;
   }

   public void setFareBreakUp(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp)
   {
      this.fareBreakUp = fareBreakUp;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> getCommercialDetails()
   {
      return this.commercialDetails;
   }

   public void setCommercialDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails)
   {
      this.commercialDetails = commercialDetails;
   }

   public double getTotalReceivables()
   {
      return this.totalReceivables;
   }

   public void setTotalReceivables(double totalReceivables)
   {
      this.totalReceivables = totalReceivables;
   }

   public double getTotalPayables()
   {
      return this.totalPayables;
   }

   public void setTotalPayables(double totalPayables)
   {
      this.totalPayables = totalPayables;
   }

   public java.util.List<java.lang.String> getCommercialsApplied()
   {
      return this.commercialsApplied;
   }

   public void setCommercialsApplied(
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.commercialsApplied = commercialsApplied;
   }

   public double getTotalFare()
   {
      return this.totalFare;
   }

   public void setTotalFare(double totalFare)
   {
      this.totalFare = totalFare;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> getEntityCommercials()
   {
      return this.entityCommercials;
   }

   public void setEntityCommercials(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials)
   {
      this.entityCommercials = entityCommercials;
   }

   public RoomDetails(
         java.lang.String roomType,
         java.lang.String roomCategory,
         boolean isAdvanced,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails,
         double totalReceivables,
         double totalPayables,
         java.util.List<java.lang.String> commercialsApplied,
         double totalFare,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials)
   {
      this.roomType = roomType;
      this.roomCategory = roomCategory;
      this.isAdvanced = isAdvanced;
      this.fareBreakUp = fareBreakUp;
      this.commercialDetails = commercialDetails;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.commercialsApplied = commercialsApplied;
      this.totalFare = totalFare;
      this.entityCommercials = entityCommercials;
   }

}