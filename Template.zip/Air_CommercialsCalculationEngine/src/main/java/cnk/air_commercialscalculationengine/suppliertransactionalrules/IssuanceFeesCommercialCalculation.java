package cnk.air_commercialscalculationengine.suppliertransactionalrules;

public class IssuanceFeesCommercialCalculation {


	   static final long serialVersionUID = 1L;

	   private java.lang.String selectedRow;

	   public IssuanceFeesCommercialCalculation()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public IssuanceFeesCommercialCalculation(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }
}
