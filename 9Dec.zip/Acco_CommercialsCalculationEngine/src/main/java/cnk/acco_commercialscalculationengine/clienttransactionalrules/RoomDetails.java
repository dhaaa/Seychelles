package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RoomDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String roomType;
   private java.lang.String roomCategory;
   private java.lang.String passengerType;
   private boolean isAdvanced;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails;
   private double totalReceivables;
   private double totalPayables;
   private double totalFare;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials;
   private java.util.List<java.lang.String> commercialsApplied;

   private double totalFareTemp;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUpTemp;

   private java.lang.String starCategory;

   private java.lang.String mealPlan;

   private java.lang.Integer passengerCount;

   private java.lang.Integer noOfNights;

   public void ClientCommercialCalculation(String CommercialName, String CommercialType, String CommercialProperty, double RetentionPercentage, double RetentionAmountPercentage, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetl)
   {

      if (CommercialProperty.equals("Retention"))
         CalculateRetentionCommercial(CommercialName, CommercialType, RetentionPercentage, RetentionAmountPercentage, entyDtls, roomDetl);
      else if (CommercialProperty.equals("Additional"))
         CalculateAdditionalCommercial(CommercialName, AdditionalPercentage, AdditionalAmount, FareComponent, TaxComponent, Currency, entyDtls, roomDetl);
      else
         CalculateFixedCommercial(CommercialName, CommercialType, RetentionPercentage, RetentionAmountPercentage, entyDtls, roomDetl);
   }

   public void CalculateRetentionCommercial(String CommercialName, String CommercialType, double RetentionPercentage, double RetentionAmountPercentage, EntityDetails entyDtls, RoomDetails roomDetl)
   {
      RetentionCommercialDetails retComDtls = new RetentionCommercialDetails();
      double tempAmount = 0;
      if (entyDtls.getParentEntityName() == null)
      {
         for (CommercialDetails commdetails : roomDetl.getCommercialDetails())
         {
            if (CommercialName.equals(commdetails.getCommercialName()))
            {
               retComDtls.setRemainingAmount(commdetails.getCommercialCalculationAmount());
               retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount());
               if (RetentionAmountPercentage != 0)
               {
                  tempAmount = commdetails.getCommercialCalculationAmount() * (RetentionAmountPercentage / 100);
                  retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                  retComDtls.setRemainingAmount(commdetails.getCommercialCalculationAmount() - tempAmount);
               }
               if (RetentionPercentage != 0)
               {
                  double percentageAmount = 0;
                  if (commdetails.getCommercialCalculationAmount() != 0)
                  {
                     percentageAmount = (commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount()) * (RetentionPercentage / 100);
                     retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  else
                  {
                     percentageAmount = commdetails.getCommercialAmount() * (RetentionPercentage / 100);
                     retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  retComDtls.setRetentionPercentage(RetentionPercentage);
               }
               retComDtls.setCommercialAmount(tempAmount);
               retComDtls.setCommercialName(CommercialName);
            }

         }
      }
      else
      {
         for (EntityCommercials parentEntity : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName()))
            {
               for (RetentionCommercialDetails retcommdetails : parentEntity.getRetentionCommercialDetails())
               {
                  if (CommercialName.equals(retcommdetails.getCommercialName()))
                  {
                     retComDtls.setRemainingAmount(retcommdetails.getRemainingAmount());
                     retComDtls.setRemainingPercentageAmount(retcommdetails.getRemainingPercentageAmount());
                     if (RetentionAmountPercentage != 0)
                     {
                        tempAmount = retcommdetails.getRemainingAmount() * (RetentionAmountPercentage / 100);
                        retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                        retComDtls.setRemainingAmount(retcommdetails.getRemainingAmount() - tempAmount);
                     }
                     if (RetentionPercentage != 0)
                     {
                        double percentageAmount = 0;
                        percentageAmount = retcommdetails.getRemainingPercentageAmount() * (RetentionPercentage / 100);
                        tempAmount = tempAmount + percentageAmount;
                        retComDtls.setRetentionPercentage(RetentionPercentage);
                        retComDtls.setRemainingPercentageAmount(retcommdetails.getRemainingPercentageAmount() - percentageAmount);
                     }
                     retComDtls.setCommercialAmount(tempAmount);
                     retComDtls.setCommercialName(CommercialName);
                  }
               }
            }
         }
      }
      if (roomDetl.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
         entityCommercials.getRetentionCommercialDetails().add(retComDtls);
         roomDetl.setEntityCommercials(new ArrayList<EntityCommercials>());
         roomDetl.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getRetentionCommercialDetails() == null)
                  entityComm.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
               entityComm.getRetentionCommercialDetails().add(retComDtls);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
            entityCommercials.getRetentionCommercialDetails().add(retComDtls);
            roomDetl.getEntityCommercials().add(entityCommercials);
         }

      }
      entyDtls.getEntityStatus().add(CommercialName + "RetentionCompleted");
   }

   public void CalculateFixedCommercial(String CommercialName, String CommercialType, double RetentionPercentage, double RetentionAmount, EntityDetails entyDtls, RoomDetails roomDetl)
   {
      FixedCommercialDetails fixedCommercialDetails = new FixedCommercialDetails();
      fixedCommercialDetails.setCalculationPercentage(RetentionPercentage);
      fixedCommercialDetails.setCalculationAmount(RetentionAmount);
      fixedCommercialDetails.setCommercialAmount(RetentionAmount + (RetentionPercentage / 100) * this.getTotalFare());
      fixedCommercialDetails.setCommercialName(CommercialName);
      /* if (entyDtls.getParentEntityName() == null) {
           for (CommercialDetails commdetails: roomDetl.getCommercialDetails()) {
               if (CommercialName.equals(commdetails.getCommercialName())) {
                   fixedCommercialDetails.setRemainingAmount(RetentionAmount);
                   fixedCommercialDetails.setRemainingPercentageAmount(commdetails.getCommercialAmount() * RetentionPercentage / 100);
                   fixedCommercialDetails.setRetentionPercentage(RetentionPercentage);
                   fixedCommercialDetails.setRetentionAmountPercentage(RetentionAmount);
                   fixedCommercialDetails.setCommercialAmount(fixedCommercialDetails.getRemainingAmount() + fixedCommercialDetails.getRemainingPercentageAmount());
                   fixedCommercialDetails.setCommercialName(CommercialName);
               }

           }
       } else {
           for (EntityCommercials parentEntity: roomDetl.getEntityCommercials()) {
               if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName())) {
                   for (RetentionCommercialDetails retcommdetails: parentEntity.getRetentionCommercialDetails()) {
                       if (CommercialName.equals(retcommdetails.getCommercialName())) {
                           fixedCommercialDetails.setRemainingAmount(RetentionAmount);
                           fixedCommercialDetails.setRemainingPercentageAmount(retcommdetails.getCommercialAmount() * RetentionPercentage / 100);
                           fixedCommercialDetails.setRetentionPercentage(RetentionPercentage);
                           fixedCommercialDetails.setRetentionAmountPercentage(RetentionAmount);
                           fixedCommercialDetails.setCommercialAmount(fixedCommercialDetails.getRemainingAmount() + fixedCommercialDetails.getRemainingPercentageAmount());
                           fixedCommercialDetails.setCommercialName(CommercialName);
                       }
                   }
               }
           }
       }*/
      if (roomDetl.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         entityCommercials.setFixedCommercialDetails(new ArrayList<FixedCommercialDetails>());
         entityCommercials.getFixedCommercialDetails().add(fixedCommercialDetails);
         roomDetl.setEntityCommercials(new ArrayList<EntityCommercials>());
         roomDetl.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getFixedCommercialDetails() == null)
                  entityComm.setFixedCommercialDetails(new ArrayList<FixedCommercialDetails>());
               entityComm.getFixedCommercialDetails().add(fixedCommercialDetails);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setFixedCommercialDetails(new ArrayList<FixedCommercialDetails>());
            entityCommercials.getFixedCommercialDetails().add(fixedCommercialDetails);
            roomDetl.getEntityCommercials().add(entityCommercials);
         }

      }
      entyDtls.getEntityStatus().add(CommercialName + "FixedCompleted");
   }

   public void CalculateAdditionalCommercial(String CommercialName, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetl)
   {

      AdditionalCommercialDetails addComm = new AdditionalCommercialDetails();
      addComm.setCommercialName(CommercialName);
      addComm.setCommercialFareComponent(FareComponent);

      if (AdditionalPercentage > 0)
      {
         addComm.setCommercialCalculationPercentage(AdditionalPercentage);
         if (TaxComponent == null)
         {
            if (FareComponent.equals("Total"))
               addComm.setCommercialAmount(roomDetl.getTotalFare() * AdditionalPercentage / 100);
            else
               addComm.setCommercialAmount(roomDetl.getFareBreakUp().getBaseFare() * AdditionalPercentage / 100);
         }
         else
         {
            if (FareComponent.equals("Basic"))
               addComm.setCommercialAmount(roomDetl.getFareBreakUp().getBaseFare());

            List<String> tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
            double commercialAmount = 0;
            for (TaxDetails taxes : roomDetl.getFareBreakUp().getTaxDetails())
            {
               for (String tempTaxName : tempTaxDetails)
               {
                  if (tempTaxName.equals(taxes.getTaxName()))
                  {
                     commercialAmount = commercialAmount + taxes.getTaxValue();
                     if (addComm.getCommercialFareComponent() == null)
                        addComm.setCommercialFareComponent(tempTaxName);
                     else
                        addComm.setCommercialFareComponent(addComm.getCommercialFareComponent() + "," + tempTaxName);
                  }
               }
            }
            addComm.setCommercialAmount((addComm.getCommercialAmount() + commercialAmount) * AdditionalPercentage / 100);
         }
      }
      if (AdditionalAmount > 0)
      {
         addComm.setCommercialAmount(addComm.getCommercialAmount() + AdditionalAmount);
         if (addComm.getCommercialCurrency() == null)
            addComm.setCommercialCurrency(Currency);
         addComm.setCommercialCalculationAmount(AdditionalAmount);
      }

      if (roomDetl.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         roomDetl.setEntityCommercials(new ArrayList<EntityCommercials>());
         entityCommercials.setAdditionalCommercialDetails(new ArrayList<AdditionalCommercialDetails>());
         entityCommercials.getAdditionalCommercialDetails().add(addComm);
         roomDetl.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getAdditionalCommercialDetails() == null)
                  entityComm.setAdditionalCommercialDetails(new ArrayList<AdditionalCommercialDetails>());
               entityComm.getAdditionalCommercialDetails().add(addComm);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setAdditionalCommercialDetails(new ArrayList<AdditionalCommercialDetails>());
            entityCommercials.getAdditionalCommercialDetails().add(addComm);
            roomDetl.getEntityCommercials().add(entityCommercials);
         }

      }
      entyDtls.getEntityStatus().add(CommercialName + "AdditionalCompleted");
   }

   public void CalculateMarkUpCommercial(double MarkUpPercentage, double MarkUpAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetl, double MinSellingPrice)
   {
      MarkUpCommercialDetails markComm = new MarkUpCommercialDetails();
      if (this.fareBreakUp == null)
         FareBreakUpNull(MarkUpPercentage, MarkUpAmount, totalFareTemp, entyDtls.getEntityName(), MinSellingPrice, markComm, Currency);
      else
         MarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, totalFareTemp, entyDtls.getEntityName(), MinSellingPrice, fareBreakUpTemp, markComm);
      /*if (entyDtls.getParentEntityName() == null) {

          if (roomDetl.getFareBreakUp() == null) {
              FareBreakUpNull(MarkUpPercentage, MarkUpAmount, roomDetl.getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, markComm,Currency);

          } else {
              MarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, roomDetl.getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, this.getFareBreakUp(), markComm);

          }
      } else {

          System.out.println("Hi7");
      ArrayList <EntityCommercials> tempEntityCommercials=new ArrayList<EntityCommercials>(roomDetl.getEntityCommercials());
          for (EntityCommercials parentEntity: tempEntityCommercials) {
              if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName())) {

                  if (parentEntity.getMarkUpCommercialDetails().getFareBreakUp() == null) {
                      FareBreakUpNull(MarkUpPercentage, MarkUpAmount, parentEntity.getMarkUpCommercialDetails().getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, markComm,Currency);
                  } else {
                      MarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, parentEntity.getMarkUpCommercialDetails().getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, parentEntity.getMarkUpCommercialDetails().getFareBreakUp(), markComm,Currency);
                  }
              }
          }

      }*/
   }

   public void MarkUpCalculation(double MarkUpPercentage, double MarkUpAmount, String FareComponent, String TaxComponent, String Currency, double totalFare, String entityName, double MinSellingPrice, FareBreakUp fareBreakUp, MarkUpCommercialDetails markComm)
   {
      if (fareBreakUp == null)
         setFareBreakUp(this.fareBreakUp);
      if (totalFare == 0)
         setTotalFare(this.totalFare);
      markComm.setFareBreakUp(new FareBreakUp());
      markComm.getFareBreakUp().setTaxDetails(new ArrayList<TaxDetails>());
      markComm.setCommercialAmount(0.0);
      if (MarkUpPercentage > 0)
      {
         markComm.setCommercialCalculationPercentage(MarkUpPercentage);
         if (TaxComponent == null)
         {
            //List <TaxDetails> taxDetails = new ArrayList<TaxDetails>(fareBreakUp.getTaxDetails());
            //markComm.getFareBreakUp().setTaxDetails(taxDetails);

            for (TaxDetails taxes : fareBreakUp.getTaxDetails())
            {
               TaxDetails td = new TaxDetails();
               td.setTaxName(taxes.getTaxName());
               td.setTaxValue(taxes.getTaxValue());
               markComm.getFareBreakUp().getTaxDetails().add(td);
            }

            if (FareComponent.equals("Total"))
            {
               double commercialAmt = totalFare * MarkUpPercentage / 100;
               markComm.setCommercialAmount(commercialAmt);
               markComm.setCommercialFareComponent(FareComponent);
               markComm.getFareBreakUp().setBaseFare(fareBreakUp.getBaseFare() + (fareBreakUp.getBaseFare() * MarkUpPercentage / 100));
               for (TaxDetails taxDetail : markComm.getFareBreakUp().getTaxDetails())
               {
                  taxDetail.setTaxValue(taxDetail.getTaxValue() + (taxDetail.getTaxValue() * MarkUpPercentage / 100));
               }

            }
            else
            {
               markComm.setCommercialAmount(fareBreakUp.getBaseFare() * MarkUpPercentage / 100);
               markComm.setCommercialFareComponent(FareComponent);
               markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
            }
         }
         else
         {
            markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
            if (!(FareComponent == null))
            {
               markComm.setCommercialAmount(fareBreakUp.getBaseFare() * MarkUpPercentage / 100);
               markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
               markComm.setCommercialFareComponent(FareComponent);
            }
            List<String> tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
            double commercialAmount = 0;
            for (TaxDetails taxes : fareBreakUp.getTaxDetails())
            {
               TaxDetails td = new TaxDetails();
               td.setTaxName(taxes.getTaxName());
               td.setTaxValue(taxes.getTaxValue());
               for (String tempTaxName : tempTaxDetails)
               {
                  if (tempTaxName.equals(taxes.getTaxName()))
                  {
                     double TaxComVal = (taxes.getTaxValue() * MarkUpPercentage / 100);
                     td.setTaxValue(taxes.getTaxValue() + TaxComVal);
                     commercialAmount = commercialAmount + TaxComVal;

                     if (markComm.getCommercialFareComponent() == null)
                        markComm.setCommercialFareComponent(tempTaxName);
                     else
                        markComm.setCommercialFareComponent(markComm.getCommercialFareComponent() + "," + tempTaxName);
                  }
               }
               markComm.getFareBreakUp().getTaxDetails().add(td);
            }
            markComm.setCommercialAmount((markComm.getCommercialAmount() + commercialAmount));

         }
      }
      if (MarkUpAmount > 0)
      {
         markComm.setCommercialAmount(markComm.getCommercialAmount() + MarkUpAmount);
         if (MarkUpPercentage == 0)
         {
            markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
            for (TaxDetails taxes : fareBreakUp.getTaxDetails())
            {
               TaxDetails td = new TaxDetails();
               td.setTaxName(taxes.getTaxName());
               td.setTaxValue(taxes.getTaxValue());
               markComm.getFareBreakUp().getTaxDetails().add(td);

            }
         }
         else
         {
            if (!(FareComponent == null))
               markComm.getFareBreakUp().setBaseFare(markComm.getFareBreakUp().getBaseFare() + MarkUpAmount);
            else
            {
               List<String> tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
               for (TaxDetails taxes : markComm.getFareBreakUp().getTaxDetails())
               {
                  for (String tempTaxName : tempTaxDetails)
                  {
                     if (tempTaxName.equals(taxes.getTaxName()))
                     {
                        taxes.setTaxValue(taxes.getTaxValue() + MarkUpAmount);
                     }
                  }
               }
            }
         }
      }
      markComm.setCommercialCurrency(Currency);
      markComm.setCommercialCalculationAmount(MarkUpAmount);
      markComm.setTotalFare(markComm.getCommercialAmount() + totalFare);

      if (this.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entityName);
         this.setEntityCommercials(new ArrayList<EntityCommercials>());
         entityCommercials.setMarkUpCommercialDetails(markComm);
         this.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entitycommercials : this.getEntityCommercials())
         {
            if (entitycommercials.getEntityName().equals(entityName))
            {
               entitycommercials.setMarkUpCommercialDetails(markComm);
               isEntityPresent = true;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entityName);
            entityCommercials.setMarkUpCommercialDetails(markComm);
            this.getEntityCommercials().add(entityCommercials);
         }
      }
      markComm.setCommercialName("MarkUp");
      if ((markComm.getCommercialAmount() + totalFare) < MinSellingPrice)
      {
         markComm.setTotalFare(MinSellingPrice);
         markComm.getFareBreakUp().setBaseFare(fareBreakUp.getBaseFare() + (MinSellingPrice - totalFare));
         markComm.getFareBreakUp().getTaxDetails().removeAll(markComm.getFareBreakUp().getTaxDetails());
         markComm.getFareBreakUp().getTaxDetails().addAll(this.getFareBreakUp().getTaxDetails());
      }
      if (MarkUpPercentage != 0 || MarkUpAmount != 0)
      {
         fareBreakUpTemp = markComm.getFareBreakUp();
         totalFareTemp = markComm.getTotalFare();
      }
   }

   public void FareBreakUpNull(double MarkUpPercentage, double MarkUpAmount, double totalFare, String entityName, double MinSellingPrice, MarkUpCommercialDetails markComm, String Currency)
   {
      if (totalFare == 0)
         setTotalFare(this.totalFare);
      double markUpTotalFare = 0;
      if (MarkUpPercentage > 0)
      {
         markComm.setTotalFare(totalFare + (totalFare * MarkUpPercentage / 100));
         markUpTotalFare = markComm.getTotalFare();
         markComm.setCommercialCalculationPercentage(MarkUpPercentage);
         markComm.setCommercialAmount(totalFare * MarkUpPercentage / 100);
      }
      if (MarkUpAmount > 0 && markUpTotalFare > 0)
      {
         markComm.setTotalFare(markUpTotalFare + MarkUpAmount);
         markComm.setCommercialCalculationAmount(MarkUpAmount);
         markComm.setCommercialAmount(markComm.getCommercialAmount() + MarkUpAmount);
      }
      else
      {
         markComm.setTotalFare(totalFare + MarkUpAmount);
         markComm.setCommercialAmount(MarkUpAmount);
      }

      markComm.setCommercialFareComponent("Total");
      markComm.setCommercialCurrency(Currency);

      if (this.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entityName);
         this.setEntityCommercials(new ArrayList<EntityCommercials>());
         entityCommercials.setMarkUpCommercialDetails(markComm);
         this.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entitycommercials : this.getEntityCommercials())
         {
            if (entitycommercials.getEntityName().equals(entityName))
            {
               entitycommercials.setMarkUpCommercialDetails(markComm);
               isEntityPresent = true;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entityName);
            entityCommercials.setMarkUpCommercialDetails(markComm);
            this.getEntityCommercials().add(entityCommercials);
         }
      }
      markComm.setCommercialName("MarkUp");
      if ((markComm.getCommercialAmount() + totalFare) < MinSellingPrice)
      {
         System.out.println("Hi4");
         markComm.setTotalFare(MinSellingPrice);
      }
      if (MarkUpPercentage != 0 || MarkUpAmount != 0)
      {
         totalFareTemp = markComm.getTotalFare();
      }

   }

   public RoomDetails()
   {
   }

   public java.lang.String getRoomType()
   {
      return this.roomType;
   }

   public void setRoomType(java.lang.String roomType)
   {
      this.roomType = roomType;
   }

   public java.lang.String getRoomCategory()
   {
      return this.roomCategory;
   }

   public void setRoomCategory(java.lang.String roomCategory)
   {
      this.roomCategory = roomCategory;
   }

   public java.lang.String getPassengerType()
   {
      return this.passengerType;
   }

   public void setPassengerType(java.lang.String passengerType)
   {
      this.passengerType = passengerType;
   }

   public boolean isIsAdvanced()
   {
      return this.isAdvanced;
   }

   public void setIsAdvanced(boolean isAdvanced)
   {
      this.isAdvanced = isAdvanced;
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp getFareBreakUp()
   {
      return this.fareBreakUp;
   }

   public void setFareBreakUp(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp)
   {
      this.fareBreakUp = fareBreakUp;
      fareBreakUpTemp = this.fareBreakUp;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> getCommercialDetails()
   {
      return this.commercialDetails;
   }

   public void setCommercialDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails)
   {
      this.commercialDetails = commercialDetails;
   }

   public double getTotalReceivables()
   {
      return this.totalReceivables;
   }

   public void setTotalReceivables(double totalReceivables)
   {
      this.totalReceivables = totalReceivables;
   }

   public double getTotalPayables()
   {
      return this.totalPayables;
   }

   public void setTotalPayables(double totalPayables)
   {
      this.totalPayables = totalPayables;
   }

   public double getTotalFare()
   {
      return this.totalFare;
   }

   public void setTotalFare(double totalFare)
   {
      this.totalFare = totalFare;
      totalFareTemp = this.totalFare;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> getEntityCommercials()
   {
      return this.entityCommercials;
   }

   public void setEntityCommercials(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials)
   {
      this.entityCommercials = entityCommercials;
   }

   public java.util.List<java.lang.String> getCommercialsApplied()
   {
      return this.commercialsApplied;
   }

   public void setCommercialsApplied(
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.commercialsApplied = commercialsApplied;
   }

   public RoomDetails(
         java.lang.String roomType,
         java.lang.String roomCategory,
         java.lang.String passengerType,
         boolean isAdvanced,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails,
         double totalReceivables,
         double totalPayables,
         double totalFare,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials,
         java.util.List<java.lang.String> commercialsApplied,
         double totalFareTemp)
   {
      this.roomType = roomType;
      this.roomCategory = roomCategory;
      this.passengerType = passengerType;
      this.isAdvanced = isAdvanced;
      this.fareBreakUp = fareBreakUp;
      this.commercialDetails = commercialDetails;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.totalFare = totalFare;
      this.entityCommercials = entityCommercials;
      this.commercialsApplied = commercialsApplied;
      this.totalFareTemp = totalFareTemp;
   }

   public RoomDetails(
         java.lang.String roomType,
         java.lang.String roomCategory,
         java.lang.String passengerType,
         boolean isAdvanced,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails,
         double totalReceivables,
         double totalPayables,
         double totalFare,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials,
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.roomType = roomType;
      this.roomCategory = roomCategory;
      this.passengerType = passengerType;
      this.isAdvanced = isAdvanced;
      this.fareBreakUp = fareBreakUp;
      this.commercialDetails = commercialDetails;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.totalFare = totalFare;
      this.entityCommercials = entityCommercials;
      this.commercialsApplied = commercialsApplied;
   }

   public java.lang.String getStarCategory()
   {
      return this.starCategory;
   }

   public void setStarCategory(java.lang.String starCategory)
   {
      this.starCategory = starCategory;
   }

   public java.lang.String getMealPlan()
   {
      return this.mealPlan;
   }

   public void setMealPlan(java.lang.String mealPlan)
   {
      this.mealPlan = mealPlan;
   }

   public java.lang.Integer getPassengerCount()
   {
      return this.passengerCount;
   }

   public void setPassengerCount(java.lang.Integer passengerCount)
   {
      this.passengerCount = passengerCount;
   }

   public java.lang.Integer getNoOfNights()
   {
      return this.noOfNights;
   }

   public void setNoOfNights(java.lang.Integer noOfNights)
   {
      this.noOfNights = noOfNights;
   }

   public RoomDetails(
         java.lang.String roomType,
         java.lang.String roomCategory,
         java.lang.String passengerType,
         boolean isAdvanced,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails,
         double totalReceivables,
         double totalPayables,
         double totalFare,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials,
         java.util.List<java.lang.String> commercialsApplied,
         double totalFareTemp,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUpTemp,
         java.lang.String starCategory, java.lang.String mealPlan,
         java.lang.Integer passengerCount, java.lang.Integer noOfNights)
   {
      this.roomType = roomType;
      this.roomCategory = roomCategory;
      this.passengerType = passengerType;
      this.isAdvanced = isAdvanced;
      this.fareBreakUp = fareBreakUp;
      this.commercialDetails = commercialDetails;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.totalFare = totalFare;
      this.entityCommercials = entityCommercials;
      this.commercialsApplied = commercialsApplied;
      this.totalFareTemp = totalFareTemp;
      this.fareBreakUpTemp = fareBreakUpTemp;
      this.starCategory = starCategory;
      this.mealPlan = mealPlan;
      this.passengerCount = passengerCount;
      this.noOfNights = noOfNights;
   }

}