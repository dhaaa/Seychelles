package cnk.air_commercialscalculationengine.suppliertransactionalrules;

public class CommissionCommercialCalculation {


	   static final long serialVersionUID = 1L;

	   private java.lang.String selectedRow;

	   public CommissionCommercialCalculation()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public CommissionCommercialCalculation(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }
}
