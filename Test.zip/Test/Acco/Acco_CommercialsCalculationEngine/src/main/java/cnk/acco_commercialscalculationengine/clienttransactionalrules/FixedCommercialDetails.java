package cnk.acco_commercialscalculationengine.clienttransactionalrules;


public class FixedCommercialDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String commercialName;
   private double calculationPercentage;
   private double calculationAmount;
   private double commercialAmount;

   public FixedCommercialDetails()
   {
   }

   public java.lang.String getCommercialName()
   {
      return this.commercialName;
   }

   public void setCommercialName(java.lang.String commercialName)
   {
      this.commercialName = commercialName;
   }

   public double getCalculationPercentage()
   {
      return this.calculationPercentage;
   }

   public void setCalculationPercentage(double calculationPercentage)
   {
      this.calculationPercentage = calculationPercentage;
   }

   public double getCalculationAmount()
   {
      return this.calculationAmount;
   }

   public void setCalculationAmount(double calculationAmount)
   {
      this.calculationAmount = calculationAmount;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

      public FixedCommercialDetails(java.lang.String commercialName,
         double calculationPercentage,
         double calculationAmount, double commercialAmount
         )
   {
      this.commercialName = commercialName;
      this.calculationPercentage = calculationPercentage;
      this.calculationAmount = calculationAmount;
      this.commercialAmount = commercialAmount;
      
   }

}