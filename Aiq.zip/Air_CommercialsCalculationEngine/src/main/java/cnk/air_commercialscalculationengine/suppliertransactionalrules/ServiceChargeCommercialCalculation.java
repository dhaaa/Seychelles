package cnk.air_commercialscalculationengine.suppliertransactionalrules;

public class ServiceChargeCommercialCalculation {


	   static final long serialVersionUID = 1L;

	   private java.lang.String selectedRow;
	   private java.lang.String baseSelectedRow;	   	   

	   public ServiceChargeCommercialCalculation()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }
	   
	   public java.lang.String getBaseSelectedRow()
	   {
	      return this.baseSelectedRow;
	   }

	   public void setBaseSelectedRow(java.lang.String baseSelectedRow)
	   {
	      this.baseSelectedRow = baseSelectedRow;
	   }	   	   

	   public ServiceChargeCommercialCalculation(java.lang.String selectedRow,
		         java.lang.String baseSelectedRow)
			   {
			      this.selectedRow = selectedRow;
			      this.baseSelectedRow = baseSelectedRow;	 
	   }
}
