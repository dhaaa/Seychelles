package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class MSFFee implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String contractType;
   private java.lang.String transactionType;
   private java.lang.String MSFChargeType;
   private java.lang.String paymentType;
   private java.lang.String cardType;
   private double totalFare;
   private double commercialAmount;
   private java.lang.String commercialCurrency;
   private java.lang.String commercialType;
   private boolean isApplicable;

   private boolean serviceTaxApplicable;

   public MSFFee()
   {
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public java.lang.String getTransactionType()
   {
      return this.transactionType;
   }

   public void setTransactionType(java.lang.String transactionType)
   {
      this.transactionType = transactionType;
   }

   public java.lang.String getMSFChargeType()
   {
      return this.MSFChargeType;
   }

   public void setMSFChargeType(java.lang.String MSFChargeType)
   {
      this.MSFChargeType = MSFChargeType;
   }

   public java.lang.String getPaymentType()
   {
      return this.paymentType;
   }

   public void setPaymentType(java.lang.String paymentType)
   {
      this.paymentType = paymentType;
   }

   public java.lang.String getCardType()
   {
      return this.cardType;
   }

   public void setCardType(java.lang.String cardType)
   {
      this.cardType = cardType;
   }

   public double getTotalFare()
   {
      return this.totalFare;
   }

   public void setTotalFare(double totalFare)
   {
      this.totalFare = totalFare;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public java.lang.String getCommercialCurrency()
   {
      return this.commercialCurrency;
   }

   public void setCommercialCurrency(java.lang.String commercialCurrency)
   {
      this.commercialCurrency = commercialCurrency;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public boolean isIsApplicable()
   {
      return this.isApplicable;
   }

   public void setIsApplicable(boolean isApplicable)
   {
      this.isApplicable = isApplicable;
   }

   public boolean isServiceTaxApplicable()
   {
      return this.serviceTaxApplicable;
   }

   public void setServiceTaxApplicable(boolean serviceTaxApplicable)
   {
      this.serviceTaxApplicable = serviceTaxApplicable;
   }

   public MSFFee(java.lang.String contractType, java.lang.String transactionType,
         java.lang.String MSFChargeType, java.lang.String paymentType,
         java.lang.String cardType, double totalFare, double commercialAmount,
         java.lang.String commercialCurrency, java.lang.String commercialType,
         boolean isApplicable, boolean serviceTaxApplicable)
   {
      this.contractType = contractType;
      this.transactionType = transactionType;
      this.MSFChargeType = MSFChargeType;
      this.paymentType = paymentType;
      this.cardType = cardType;
      this.totalFare = totalFare;
      this.commercialAmount = commercialAmount;
      this.commercialCurrency = commercialCurrency;
      this.commercialType = commercialType;
      this.isApplicable = isApplicable;
      this.serviceTaxApplicable = serviceTaxApplicable;
   }

}