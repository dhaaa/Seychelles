package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class OtherFees implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String contractType;
   private double commercialAmount;
   private java.lang.String commercialCurrency;
   private java.lang.String commercialType;
   private boolean isApplicable;
   private java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.FeeDetails> feeDetails;

   private boolean refundable;

   private boolean recurring;

   private java.lang.String applicableProductCategory;

   private java.lang.String applicableProductCategorySubType;

   public OtherFees()
   {
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public java.lang.String getCommercialCurrency()
   {
      return this.commercialCurrency;
   }

   public void setCommercialCurrency(java.lang.String commercialCurrency)
   {
      this.commercialCurrency = commercialCurrency;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public boolean isIsApplicable()
   {
      return this.isApplicable;
   }

   public void setIsApplicable(boolean isApplicable)
   {
      this.isApplicable = isApplicable;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.FeeDetails> getFeeDetails()
   {
      return this.feeDetails;
   }

   public void setFeeDetails(
         java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.FeeDetails> feeDetails)
   {
      this.feeDetails = feeDetails;
   }

   public boolean isRefundable()
   {
      return this.refundable;
   }

   public void setRefundable(boolean refundable)
   {
      this.refundable = refundable;
   }

   public boolean isRecurring()
   {
      return this.recurring;
   }

   public void setRecurring(boolean recurring)
   {
      this.recurring = recurring;
   }

   public java.lang.String getApplicableProductCategory()
   {
      return this.applicableProductCategory;
   }

   public void setApplicableProductCategory(
         java.lang.String applicableProductCategory)
   {
      this.applicableProductCategory = applicableProductCategory;
   }

   public java.lang.String getApplicableProductCategorySubType()
   {
      return this.applicableProductCategorySubType;
   }

   public void setApplicableProductCategorySubType(
         java.lang.String applicableProductCategorySubType)
   {
      this.applicableProductCategorySubType = applicableProductCategorySubType;
   }

   public OtherFees(
         java.lang.String contractType,
         double commercialAmount,
         java.lang.String commercialCurrency,
         java.lang.String commercialType,
         boolean isApplicable,
         java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.FeeDetails> feeDetails,
         boolean refundable, boolean recurring,
         java.lang.String applicableProductCategory,
         java.lang.String applicableProductCategorySubType)
   {
      this.contractType = contractType;
      this.commercialAmount = commercialAmount;
      this.commercialCurrency = commercialCurrency;
      this.commercialType = commercialType;
      this.isApplicable = isApplicable;
      this.feeDetails = feeDetails;
      this.refundable = refundable;
      this.recurring = recurring;
      this.applicableProductCategory = applicableProductCategory;
      this.applicableProductCategorySubType = applicableProductCategorySubType;
   }

}