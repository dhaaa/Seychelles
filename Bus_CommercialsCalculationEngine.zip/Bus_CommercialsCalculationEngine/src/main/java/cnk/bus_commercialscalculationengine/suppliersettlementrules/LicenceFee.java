package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class LicenceFee implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees;

   public LicenceFee()
   {
   }

   public cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees getOtherFees()
   {
      return this.otherFees;
   }

   public void setOtherFees(
         cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

   public LicenceFee(
         cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

}