package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class Ticket implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private int ticketCount;
   private boolean isCompleted;

   public Ticket()
   {
   }

   public int getTicketCount()
   {
      return this.ticketCount;
   }

   public void setTicketCount(int ticketCount)
   {
      this.ticketCount = ticketCount;
   }

   public boolean isIsCompleted()
   {
      return this.isCompleted;
   }

   public void setIsCompleted(boolean isCompleted)
   {
      this.isCompleted = isCompleted;
   }

   public Ticket(int ticketCount, boolean isCompleted)
   {
      this.ticketCount = ticketCount;
      this.isCompleted = isCompleted;
   }

}