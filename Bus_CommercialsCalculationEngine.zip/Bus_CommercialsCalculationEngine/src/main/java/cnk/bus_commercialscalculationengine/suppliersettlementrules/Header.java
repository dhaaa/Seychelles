package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class Header implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String userID;
   private java.lang.String transactionID;
   private java.lang.String sessionID;
   private java.lang.String operationName;
   private java.lang.String status;

   public Header()
   {
   }

   public java.lang.String getUserID()
   {
      return this.userID;
   }

   public void setUserID(java.lang.String userID)
   {
      this.userID = userID;
   }

   public java.lang.String getTransactionID()
   {
      return this.transactionID;
   }

   public void setTransactionID(java.lang.String transactionID)
   {
      this.transactionID = transactionID;
   }

   public java.lang.String getSessionID()
   {
      return this.sessionID;
   }

   public void setSessionID(java.lang.String sessionID)
   {
      this.sessionID = sessionID;
   }

   public java.lang.String getOperationName()
   {
      return this.operationName;
   }

   public void setOperationName(java.lang.String operationName)
   {
      this.operationName = operationName;
   }

   public java.lang.String getStatus()
   {
      return this.status;
   }

   public void setStatus(java.lang.String status)
   {
      this.status = status;
   }

   public Header(java.lang.String userID, java.lang.String transactionID,
         java.lang.String sessionID, java.lang.String operationName,
         java.lang.String status)
   {
      this.userID = userID;
      this.transactionID = transactionID;
      this.sessionID = sessionID;
      this.operationName = operationName;
      this.status = status;
   }

}