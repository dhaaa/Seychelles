package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class FeeDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String commercialName;
   private double commercialAmount;

   public FeeDetails()
   {
   }

   public java.lang.String getCommercialName()
   {
      return this.commercialName;
   }

   public void setCommercialName(java.lang.String commercialName)
   {
      this.commercialName = commercialName;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public FeeDetails(java.lang.String commercialName, double commercialAmount)
   {
      this.commercialName = commercialName;
      this.commercialAmount = commercialAmount;
   }

}