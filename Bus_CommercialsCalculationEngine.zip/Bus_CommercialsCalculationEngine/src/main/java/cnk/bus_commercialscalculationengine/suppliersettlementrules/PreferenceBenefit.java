package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class PreferenceBenefit implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees;

   public PreferenceBenefit()
   {
   }

   public cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees getOtherFees()
   {
      return this.otherFees;
   }

   public void setOtherFees(
         cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

   public PreferenceBenefit(
         cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

}