package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class LookToBook implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String contractType;
   private double numberofLooks;
   private double numberofBooks;
   private double commercialAmount;
   private java.lang.String currency;
   private java.lang.String commercialType;
   private boolean isCumulative;
   private boolean isApplicable;
   private boolean refreshCounter;

   private int cumulativeSequence;

   private double numberofExcessLooks;

   public LookToBook()
   {
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public java.lang.String getCurrency()
   {
      return this.currency;
   }

   public void setCurrency(java.lang.String currency)
   {
      this.currency = currency;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public boolean isIsCumulative()
   {
      return this.isCumulative;
   }

   public void setIsCumulative(boolean isCumulative)
   {
      this.isCumulative = isCumulative;
   }

   public boolean isIsApplicable()
   {
      return this.isApplicable;
   }

   public void setIsApplicable(boolean isApplicable)
   {
      this.isApplicable = isApplicable;
   }

   public boolean isRefreshCounter()
   {
      return this.refreshCounter;
   }

   public void setRefreshCounter(boolean refreshCounter)
   {
      this.refreshCounter = refreshCounter;
   }

   public double getNumberofLooks()
   {
      return this.numberofLooks;
   }

   public void setNumberofLooks(double numberofLooks)
   {
      this.numberofLooks = numberofLooks;
   }

   public double getNumberofBooks()
   {
      return this.numberofBooks;
   }

   public void setNumberofBooks(double numberofBooks)
   {
      this.numberofBooks = numberofBooks;
   }

   public int getCumulativeSequence()
   {
      return this.cumulativeSequence;
   }

   public void setCumulativeSequence(int cumulativeSequence)
   {
      this.cumulativeSequence = cumulativeSequence;
   }

   public double getNumberofExcessLooks()
   {
      return this.numberofExcessLooks;
   }

   public void setNumberofExcessLooks(double numberofExcessLooks)
   {
      this.numberofExcessLooks = numberofExcessLooks;
   }

   public LookToBook(java.lang.String contractType, double numberofLooks,
         double numberofBooks, double commercialAmount,
         java.lang.String currency, java.lang.String commercialType,
         boolean isCumulative, boolean isApplicable, boolean refreshCounter,
         int cumulativeSequence, double numberofExcessLooks)
   {
      this.contractType = contractType;
      this.numberofLooks = numberofLooks;
      this.numberofBooks = numberofBooks;
      this.commercialAmount = commercialAmount;
      this.currency = currency;
      this.commercialType = commercialType;
      this.isCumulative = isCumulative;
      this.isApplicable = isApplicable;
      this.refreshCounter = refreshCounter;
      this.cumulativeSequence = cumulativeSequence;
      this.numberofExcessLooks = numberofExcessLooks;
   }

}