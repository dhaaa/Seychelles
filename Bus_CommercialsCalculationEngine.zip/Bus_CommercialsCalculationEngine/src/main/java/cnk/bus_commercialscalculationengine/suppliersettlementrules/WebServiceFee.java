package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class WebServiceFee implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees;

   public WebServiceFee()
   {
   }

   public cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees getOtherFees()
   {
      return this.otherFees;
   }

   public void setOtherFees(
         cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

   public WebServiceFee(
         cnk.bus_commercialscalculationengine.suppliersettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

}