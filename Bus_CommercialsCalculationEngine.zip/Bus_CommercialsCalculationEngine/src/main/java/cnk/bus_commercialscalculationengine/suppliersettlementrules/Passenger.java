package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class Passenger implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private int passengerCount;
   private boolean isCompleted;
   private java.lang.String passengerType;

   public Passenger()
   {
   }

   public int getPassengerCount()
   {
      return this.passengerCount;
   }

   public void setPassengerCount(int passengerCount)
   {
      this.passengerCount = passengerCount;
   }

   public boolean isIsCompleted()
   {
      return this.isCompleted;
   }

   public void setIsCompleted(boolean isCompleted)
   {
      this.isCompleted = isCompleted;
   }

   public java.lang.String getPassengerType()
   {
      return this.passengerType;
   }

   public void setPassengerType(java.lang.String passengerType)
   {
      this.passengerType = passengerType;
   }

   public Passenger(int passengerCount, boolean isCompleted,
         java.lang.String passengerType)
   {
      this.passengerCount = passengerCount;
      this.isCompleted = isCompleted;
      this.passengerType = passengerType;
   }

}