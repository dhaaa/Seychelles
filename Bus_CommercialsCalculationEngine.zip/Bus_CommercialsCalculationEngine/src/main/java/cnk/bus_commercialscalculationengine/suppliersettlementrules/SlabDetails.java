package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class SlabDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String slabType;
   private double slabTypeValue;
   private boolean isCompleted;
   
   public SlabDetails()
   {
   }

   public java.lang.String getSlabType()
   {
      return this.slabType;
   }

   public void setSlabType(java.lang.String slabType)
   {
      this.slabType = slabType;
   }

   public double getSlabTypeValue()
   {
      return this.slabTypeValue;
   }

   public void setSlabTypeValue(double slabTypeValue)
   {
      this.slabTypeValue = slabTypeValue;
   }

   public boolean isIsCompleted()
   {
      return this.isCompleted;
   }

   public void setIsCompleted(boolean isCompleted)
   {
      this.isCompleted = isCompleted;
   }

   public SlabDetails(java.lang.String slabType, double slabTypeValue,
         boolean isCompleted)
   {
      this.slabType = slabType;
      this.slabTypeValue = slabTypeValue;
      this.isCompleted = isCompleted;
   }

}