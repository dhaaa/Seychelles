package cnk.bus_commercialscalculationengine.suppliersettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class Root implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.bus_commercialscalculationengine.suppliersettlementrules.Header header;
   private java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.BusinessRuleIntake> businessRuleIntake;

   public Root()
   {
   }
   
   public cnk.bus_commercialscalculationengine.suppliersettlementrules.Header getHeader()
   {
      return this.header;
   }

   public void setHeader(cnk.bus_commercialscalculationengine.suppliersettlementrules.Header header)
   {
      this.header = header;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.BusinessRuleIntake> getBusinessRuleIntake()
   {
      return this.businessRuleIntake;
   }

   public void setBusinessRuleIntake(
         java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.BusinessRuleIntake> businessRuleIntake)
   {
      this.businessRuleIntake = businessRuleIntake;
   }

   public Root(
         cnk.bus_commercialscalculationengine.suppliersettlementrules.Header header,
         java.util.List<cnk.bus_commercialscalculationengine.suppliersettlementrules.BusinessRuleIntake> businessRuleIntake)
   {
      this.header = header;
      this.businessRuleIntake = businessRuleIntake;
   }

}