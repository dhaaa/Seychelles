package cnk.bus_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)

public class SlabDetails implements java.io.Serializable
{

   public boolean CheckRange(String configuredInput, double checkingValue)
   {

      String[] configuredInputList = configuredInput.split(";");
      if (configuredInputList[0].equals("LESSTHANEQUALTO"))
      {

         return LESSTHANEQUALTO(Double.parseDouble(configuredInputList[1]), checkingValue);
      }
      else if (configuredInputList[0].equals("GREATERTHANEQUALTO"))
      {

         return GREATERTHANEQUALTO(Double.parseDouble(configuredInputList[1]), checkingValue);
      }
      else if (configuredInputList[0].equals("BETWEEN"))
      {

         return BETWEEN(Double.parseDouble(configuredInputList[1]), Double.parseDouble(configuredInputList[2]), checkingValue);
      }
      else if (configuredInputList[0].equals("EQUALTO"))
      {

         return EQUAL(Double.parseDouble(configuredInputList[1]), checkingValue);
      }
      else if (configuredInputList[0].equals("IN"))
      {

         return IN(configuredInputList[1], checkingValue);
      }

      return false;

   }

   public boolean LESSTHANEQUALTO(double configuredInput, double checkingValue)
   {

      if (checkingValue <= configuredInput)
         return true;

      return false;
   }

   public boolean GREATERTHANEQUALTO(double configuredInput, double checkingValue)
   {

      if (checkingValue >= configuredInput)
         return true;

      return false;
   }

   public boolean BETWEEN(double lowerLimit, double upperLimit, double checkingValue)
   {

      if (GREATERTHANEQUALTO(lowerLimit, checkingValue) && LESSTHANEQUALTO(upperLimit, checkingValue))
         return true;

      return false;
   }

   public boolean EQUAL(double configuredInput, double checkingValue)
   {

      if (checkingValue == configuredInput)
         return true;

      return false;
   }

   public boolean IN(String configuredInput, double checkingValue)
   {

      String[] configuredInputList = configuredInput.split("/");
      for (String tempConfiguredInput : configuredInputList)
      {

         if (EQUAL(Double.parseDouble(tempConfiguredInput), checkingValue))
            return true;
      }

      return false;
   }

   static final long serialVersionUID = 1L;

   private java.lang.String slabType;
   private double slabTypeValue;
   private boolean isCompleted;

   public SlabDetails()
   {
   }

   public java.lang.String getSlabType()
   {
      return this.slabType;
   }

   public void setSlabType(java.lang.String slabType)
   {
      this.slabType = slabType;
   }

   public double getSlabTypeValue()
   {
      return this.slabTypeValue;
   }

   public void setSlabTypeValue(double slabTypeValue)
   {
      this.slabTypeValue = slabTypeValue;
   }

   public boolean isIsCompleted()
   {
      return this.isCompleted;
   }

   public void setIsCompleted(boolean isCompleted)
   {
      this.isCompleted = isCompleted;
   }

   public SlabDetails(java.lang.String slabType, double slabTypeValue,
         boolean isCompleted)
   {
      this.slabType = slabType;
      this.slabTypeValue = slabTypeValue;
      this.isCompleted = isCompleted;
   }

}