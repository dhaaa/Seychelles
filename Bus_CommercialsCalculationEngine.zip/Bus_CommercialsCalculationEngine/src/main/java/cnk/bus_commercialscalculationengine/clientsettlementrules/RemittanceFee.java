package cnk.bus_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class RemittanceFee implements java.io.Serializable
{	
	
   static final long serialVersionUID = 1L;

   private java.lang.String contractType;
   private double totalSettlementAmount;
   private java.lang.String totalSettlementCurrency;
   private double commercialAmount;
   private java.lang.String commercialCurrency;
   private java.lang.String commercialType;
   private boolean isApplicable;

   public RemittanceFee()
   {
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public double getTotalSettlementAmount()
   {
      return this.totalSettlementAmount;
   }

   public void setTotalSettlementAmount(double totalSettlementAmount)
   {
      this.totalSettlementAmount = totalSettlementAmount;
   }

   public java.lang.String getTotalSettlementCurrency()
   {
      return this.totalSettlementCurrency;
   }

   public void setTotalSettlementCurrency(
         java.lang.String totalSettlementCurrency)
   {
      this.totalSettlementCurrency = totalSettlementCurrency;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public java.lang.String getCommercialCurrency()
   {
      return this.commercialCurrency;
   }

   public void setCommercialCurrency(java.lang.String commercialCurrency)
   {
      this.commercialCurrency = commercialCurrency;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public boolean isIsApplicable()
   {
      return this.isApplicable;
   }

   public void setIsApplicable(boolean isApplicable)
   {
      this.isApplicable = isApplicable;
   }

   public RemittanceFee(java.lang.String contractType,
         double totalSettlementAmount,
         java.lang.String totalSettlementCurrency, double commercialAmount,
         java.lang.String commercialCurrency,
         java.lang.String commercialType, boolean isApplicable)
   {
      this.contractType = contractType;
      this.totalSettlementAmount = totalSettlementAmount;
      this.totalSettlementCurrency = totalSettlementCurrency;
      this.commercialAmount = commercialAmount;
      this.commercialCurrency = commercialCurrency;
      this.commercialType = commercialType;
      this.isApplicable = isApplicable;
   }

}