package cnk.bus_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class IntegrationFee implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.bus_commercialscalculationengine.clientsettlementrules.OtherFees otherFees;

   public IntegrationFee()
   {
   }

   public cnk.bus_commercialscalculationengine.clientsettlementrules.OtherFees getOtherFees()
   {
      return this.otherFees;
   }

   public void setOtherFees(
         cnk.bus_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

   public IntegrationFee(
         cnk.bus_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

}