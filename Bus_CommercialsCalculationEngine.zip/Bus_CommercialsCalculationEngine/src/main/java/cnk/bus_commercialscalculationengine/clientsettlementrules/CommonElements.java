package cnk.bus_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class CommonElements implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String supplier;
   private java.lang.String supplierMarket;

   private java.lang.String segment;

   private java.util.Date contractValidity;

   private java.lang.String productName;

   private java.lang.String clientType;

   private java.lang.String clientGroup;

   private java.lang.String clientName;

   private java.lang.String rateType;

   private java.lang.String rateCode;

   private java.lang.String productCategory;

   private java.lang.String productCategorySubType;

   public CommonElements()
   {
   }

   public java.lang.String getSupplier()
   {
      return this.supplier;
   }

   public void setSupplier(java.lang.String supplier)
   {
      this.supplier = supplier;
   }

   public java.lang.String getSupplierMarket()
   {
      return this.supplierMarket;
   }

   public void setSupplierMarket(java.lang.String supplierMarket)
   {
      this.supplierMarket = supplierMarket;
   }

   public java.lang.String getSegment()
   {
      return this.segment;
   }

   public void setSegment(java.lang.String segment)
   {
      this.segment = segment;
   }

   public java.util.Date getContractValidity()
   {
      return this.contractValidity;
   }

   public void setContractValidity(java.util.Date contractValidity)
   {
      this.contractValidity = contractValidity;
   }

   public java.lang.String getProductName()
   {
      return this.productName;
   }

   public void setProductName(java.lang.String productName)
   {
      this.productName = productName;
   }

   public java.lang.String getClientType()
   {
      return this.clientType;
   }

   public void setClientType(java.lang.String clientType)
   {
      this.clientType = clientType;
   }

   public java.lang.String getClientGroup()
   {
      return this.clientGroup;
   }

   public void setClientGroup(java.lang.String clientGroup)
   {
      this.clientGroup = clientGroup;
   }

   public java.lang.String getClientName()
   {
      return this.clientName;
   }

   public void setClientName(java.lang.String clientName)
   {
      this.clientName = clientName;
   }

   public java.lang.String getRateType()
   {
      return this.rateType;
   }

   public void setRateType(java.lang.String rateType)
   {
      this.rateType = rateType;
   }

   public java.lang.String getRateCode()
   {
      return this.rateCode;
   }

   public void setRateCode(java.lang.String rateCode)
   {
      this.rateCode = rateCode;
   }

   public java.lang.String getProductCategory()
   {
      return this.productCategory;
   }

   public void setProductCategory(java.lang.String productCategory)
   {
      this.productCategory = productCategory;
   }

   public java.lang.String getProductCategorySubType()
   {
      return this.productCategorySubType;
   }

   public void setProductCategorySubType(java.lang.String productCategorySubType)
   {
      this.productCategorySubType = productCategorySubType;
   }

   public CommonElements(java.lang.String supplier,
         java.lang.String supplierMarket, java.lang.String segment,
         java.util.Date contractValidity, java.lang.String productName,
         java.lang.String clientType, java.lang.String clientGroup,
         java.lang.String clientName, java.lang.String rateType,
         java.lang.String rateCode, java.lang.String productCategory,
         java.lang.String productCategorySubType)
   {
      this.supplier = supplier;
      this.supplierMarket = supplierMarket;
      this.segment = segment;
      this.contractValidity = contractValidity;
      this.productName = productName;
      this.clientType = clientType;
      this.clientGroup = clientGroup;
      this.clientName = clientName;
      this.rateType = rateType;
      this.rateCode = rateCode;
      this.productCategory = productCategory;
      this.productCategorySubType = productCategorySubType;
   }

}