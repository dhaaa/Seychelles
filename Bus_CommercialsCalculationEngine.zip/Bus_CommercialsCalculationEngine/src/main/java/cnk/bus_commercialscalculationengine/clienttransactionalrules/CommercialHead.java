package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class CommercialHead implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String commercialHeadName;

   @org.kie.api.definition.type.Label("Receivable or Payable")
   private java.lang.String commercialType;

   @org.kie.api.definition.type.Label("Final or Provisional")
   private java.lang.String contractType;

   private java.lang.String status;

   private java.lang.String commercialProperty;

   private boolean advancedDefinitionApplicable;

   public CommercialHead()
   {
   }

   public java.lang.String getCommercialHeadName()
   {
      return this.commercialHeadName;
   }

   public void setCommercialHeadName(java.lang.String commercialHeadName)
   {
      this.commercialHeadName = commercialHeadName;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public java.lang.String getStatus()
   {
      return this.status;
   }

   public void setStatus(java.lang.String status)
   {
      this.status = status;
   }

   public java.lang.String getCommercialProperty()
   {
      return this.commercialProperty;
   }

   public void setCommercialProperty(java.lang.String commercialProperty)
   {
      this.commercialProperty = commercialProperty;
   }

   public boolean isAdvancedDefinitionApplicable()
   {
      return this.advancedDefinitionApplicable;
   }

   public void setAdvancedDefinitionApplicable(boolean advancedDefinitionApplicable)
   {
      this.advancedDefinitionApplicable = advancedDefinitionApplicable;
   }

   public CommercialHead(java.lang.String commercialHeadName,
         java.lang.String commercialType, java.lang.String contractType,
         java.lang.String status, java.lang.String commercialProperty,
         boolean advancedDefinitionApplicable)
   {
      this.commercialHeadName = commercialHeadName;
      this.commercialType = commercialType;
      this.contractType = contractType;
      this.status = status;
      this.commercialProperty = commercialProperty;
      this.advancedDefinitionApplicable = advancedDefinitionApplicable;
   }

}