package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class FareBreakUp implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private double baseFare;
   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.TaxDetails> taxDetails;

   public FareBreakUp()
   {
   }

   public double getBaseFare()
   {
      return this.baseFare;
   }

   public void setBaseFare(double baseFare)
   {
      this.baseFare = baseFare;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.TaxDetails> getTaxDetails()
   {
      return this.taxDetails;
   }

   public void setTaxDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.TaxDetails> taxDetails)
   {
      this.taxDetails = taxDetails;
   }

   public FareBreakUp(
         double baseFare,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.TaxDetails> taxDetails)
   {
      this.baseFare = baseFare;
      this.taxDetails = taxDetails;
   }

}