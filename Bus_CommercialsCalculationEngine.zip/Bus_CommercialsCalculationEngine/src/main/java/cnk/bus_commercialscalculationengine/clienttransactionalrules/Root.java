package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class Root implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.bus_commercialscalculationengine.clienttransactionalrules.Header header;
   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusinessRuleIntake> businessRuleIntake;

   public Root()
   {
   }

   public cnk.bus_commercialscalculationengine.clienttransactionalrules.Header getHeader()
   {
      return this.header;
   }

   public void setHeader(
         cnk.bus_commercialscalculationengine.clienttransactionalrules.Header header)
   {
      this.header = header;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusinessRuleIntake> getBusinessRuleIntake()
   {
      return this.businessRuleIntake;
   }

   public void setBusinessRuleIntake(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusinessRuleIntake> businessRuleIntake)
   {
      this.businessRuleIntake = businessRuleIntake;
   }

   public Root(
         cnk.bus_commercialscalculationengine.clienttransactionalrules.Header header,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusinessRuleIntake> businessRuleIntake)
   {
      this.header = header;
      this.businessRuleIntake = businessRuleIntake;
   }

}