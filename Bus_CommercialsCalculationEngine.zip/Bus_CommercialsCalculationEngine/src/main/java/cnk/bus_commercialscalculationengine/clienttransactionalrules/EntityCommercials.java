package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class EntityCommercials implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String entityName;
   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.RetentionCommercialDetails> retentionCommercialDetails;
   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.FixedCommercialDetails> fixedCommercialDetails;
   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.AdditionalCommercialDetails> additionalCommercialDetails;

   private cnk.bus_commercialscalculationengine.clienttransactionalrules.MarkUpCommercialDetails markUpCommercialDetails;

   public EntityCommercials()
   {
   }

   public java.lang.String getEntityName()
   {
      return this.entityName;
   }

   public void setEntityName(java.lang.String entityName)
   {
      this.entityName = entityName;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.RetentionCommercialDetails> getRetentionCommercialDetails()
   {
      return this.retentionCommercialDetails;
   }

   public void setRetentionCommercialDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.RetentionCommercialDetails> retentionCommercialDetails)
   {
      this.retentionCommercialDetails = retentionCommercialDetails;
   }
   
   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.FixedCommercialDetails> getFixedCommercialDetails()
   {
      return this.fixedCommercialDetails;
   }

   public void setFixedCommercialDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.FixedCommercialDetails> fixedCommercialDetails)
   {
      this.fixedCommercialDetails = fixedCommercialDetails;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.AdditionalCommercialDetails> getAdditionalCommercialDetails()
   {
      return this.additionalCommercialDetails;
   }

   public void setAdditionalCommercialDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.AdditionalCommercialDetails> additionalCommercialDetails)
   {
      this.additionalCommercialDetails = additionalCommercialDetails;
   }

   public cnk.bus_commercialscalculationengine.clienttransactionalrules.MarkUpCommercialDetails getMarkUpCommercialDetails()
   {
      return this.markUpCommercialDetails;
   }

   public void setMarkUpCommercialDetails(
         cnk.bus_commercialscalculationengine.clienttransactionalrules.MarkUpCommercialDetails markUpCommercialDetails)
   {
      this.markUpCommercialDetails = markUpCommercialDetails;
   }

   public EntityCommercials(
         java.lang.String entityName,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.RetentionCommercialDetails> retentionCommercialDetails,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.FixedCommercialDetails> fixedCommercialDetails,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.AdditionalCommercialDetails> additionalCommercialDetails,
         cnk.bus_commercialscalculationengine.clienttransactionalrules.MarkUpCommercialDetails markUpCommercialDetails)
   {
      this.entityName = entityName;
      this.retentionCommercialDetails = retentionCommercialDetails;
      this.fixedCommercialDetails = fixedCommercialDetails;
      this.additionalCommercialDetails = additionalCommercialDetails;
      this.markUpCommercialDetails = markUpCommercialDetails;
   }

}