package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class MarkUpCommercialDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private double commercialAmount;
   private double commercialCalculationPercentage;
   private double commercialCalculationAmount;
   private java.lang.String commercialFareComponent;
   private java.lang.String commercialCurrency;
   private double totalFare;
   private cnk.bus_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp;
   private java.lang.String commercialName;
   
   public MarkUpCommercialDetails()
   {
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public double getCommercialCalculationPercentage()
   {
      return this.commercialCalculationPercentage;
   }

   public void setCommercialCalculationPercentage(
         double commercialCalculationPercentage)
   {
      this.commercialCalculationPercentage = commercialCalculationPercentage;
   }

   public double getCommercialCalculationAmount()
   {
      return this.commercialCalculationAmount;
   }

   public void setCommercialCalculationAmount(
         double commercialCalculationAmount)
   {
      this.commercialCalculationAmount = commercialCalculationAmount;
   }

   public java.lang.String getCommercialFareComponent()
   {
      return this.commercialFareComponent;
   }

   public void setCommercialFareComponent(
         java.lang.String commercialFareComponent)
   {
      this.commercialFareComponent = commercialFareComponent;
   }

   public java.lang.String getCommercialCurrency()
   {
      return this.commercialCurrency;
   }

   public void setCommercialCurrency(java.lang.String commercialCurrency)
   {
      this.commercialCurrency = commercialCurrency;
   }
   
   public double getTotalFare()
   {
      return this.totalFare;
   }

   public void setTotalFare(double totalFare)
   {
      this.totalFare = totalFare;
   }

   public cnk.bus_commercialscalculationengine.clienttransactionalrules.FareBreakUp getFareBreakUp()
   {
      return this.fareBreakUp;
   }

   public void setFareBreakUp(
         cnk.bus_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp)
   {
      this.fareBreakUp = fareBreakUp;
   }

   public java.lang.String getCommercialName()
   {
      return this.commercialName;
   }

   public void setCommercialName(java.lang.String commercialName)
   {
      this.commercialName = commercialName;
   }
   
   public MarkUpCommercialDetails(
		 double commercialAmount,
         double commercialCalculationPercentage,
         double commercialCalculationAmount,
         java.lang.String commercialFareComponent,
         java.lang.String commercialCurrency,
         double totalFare,
         cnk.bus_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.lang.String commercialName)
   {
      this.commercialAmount = commercialAmount;
      this.commercialCalculationPercentage = commercialCalculationPercentage;
      this.commercialCalculationAmount = commercialCalculationAmount;
      this.commercialFareComponent = commercialFareComponent;
      this.commercialCurrency = commercialCurrency;
	  this.totalFare = totalFare;
      this.fareBreakUp = fareBreakUp;
      this.commercialName = commercialName;
   }

}