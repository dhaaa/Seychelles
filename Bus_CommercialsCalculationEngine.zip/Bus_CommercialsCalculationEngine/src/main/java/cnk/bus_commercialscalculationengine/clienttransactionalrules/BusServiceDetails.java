package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@org.codehaus.jackson.map.annotate.JsonSerialize(include = org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL)
public class BusServiceDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private boolean isAdvanced;

   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.PassengerDetails> passengerDetails;

   private int routeId;

   private java.lang.String busType;

   private java.lang.String operatorName;

   private java.lang.String operatorCountry;

   private java.lang.String operatorId;

   public BusServiceDetails()
   {
   }

   public boolean isIsAdvanced()
   {
      return this.isAdvanced;
   }

   public void setIsAdvanced(boolean isAdvanced)
   {
      this.isAdvanced = isAdvanced;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.PassengerDetails> getPassengerDetails()
   {
      return this.passengerDetails;
   }

   public void setPassengerDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.PassengerDetails> passengerDetails)
   {
      this.passengerDetails = passengerDetails;
   }

   public java.lang.String getBusType()
   {
      return this.busType;
   }

   public void setBusType(java.lang.String busType)
   {
      this.busType = busType;
   }

   public java.lang.String getOperatorName()
   {
      return this.operatorName;
   }

   public void setOperatorName(java.lang.String operatorName)
   {
      this.operatorName = operatorName;
   }

   public java.lang.String getOperatorCountry()
   {
      return this.operatorCountry;
   }

   public void setOperatorCountry(java.lang.String operatorCountry)
   {
      this.operatorCountry = operatorCountry;
   }

   public java.lang.String getOperatorId()
   {
      return this.operatorId;
   }

   public void setOperatorId(java.lang.String operatorId)
   {
      this.operatorId = operatorId;
   }

   public int getRouteId()
   {
      return this.routeId;
   }

   public void setRouteId(int routeId)
   {
      this.routeId = routeId;
   }

   public BusServiceDetails(
         boolean isAdvanced,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.PassengerDetails> passengerDetails,
         int routeId, java.lang.String busType, java.lang.String operatorName,
         java.lang.String operatorCountry, java.lang.String operatorId)
   {
      this.isAdvanced = isAdvanced;
      this.passengerDetails = passengerDetails;
      this.routeId = routeId;
      this.busType = busType;
      this.operatorName = operatorName;
      this.operatorCountry = operatorCountry;
      this.operatorId = operatorId;
   }

}