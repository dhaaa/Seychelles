package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class BusinessRuleIntake implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.bus_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition;
   private java.util.List<java.lang.String> commercialStatus;
   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusServiceDetails> busServiceDetails;
   private java.lang.String ruleFlowName;
   private java.lang.String selectedRow;
   private CommonElements commonElements;
   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails;

   private java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails;

   public BusinessRuleIntake()
   {
   }

   public cnk.bus_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition getAdvancedDefinition()
   {
      return this.advancedDefinition;
   }

   public void setAdvancedDefinition(
         cnk.bus_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition)
   {
      this.advancedDefinition = advancedDefinition;
   }

   public java.util.List<java.lang.String> getCommercialStatus()
   {
      return this.commercialStatus;
   }

   public void setCommercialStatus(
         java.util.List<java.lang.String> commercialStatus)
   {
      this.commercialStatus = commercialStatus;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusServiceDetails> getBusServiceDetails()
   {
      return this.busServiceDetails;
   }

   public void setBusServiceDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusServiceDetails> busServiceDetails)
   {
      this.busServiceDetails = busServiceDetails;
   }

   public java.lang.String getRuleFlowName()
   {
      return this.ruleFlowName;
   }

   public void setRuleFlowName(java.lang.String ruleFlowName)
   {
      this.ruleFlowName = ruleFlowName;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.EntityDetails> getEntityDetails()
   {
      return this.entityDetails;
   }

   public void setEntityDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails)
   {
      this.entityDetails = entityDetails;
   }

   public cnk.bus_commercialscalculationengine.clienttransactionalrules.CommonElements getCommonElements()
   {
      return this.commonElements;
   }

   public void setCommonElements(
         cnk.bus_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements)
   {
      this.commonElements = commonElements;
   }

   public java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public BusinessRuleIntake(
         cnk.bus_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition,
         java.util.List<java.lang.String> commercialStatus,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.BusServiceDetails> busServiceDetails,
         java.lang.String ruleFlowName,
         java.lang.String selectedRow,
         cnk.bus_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails,
         java.util.List<cnk.bus_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails)
   {
      this.advancedDefinition = advancedDefinition;
      this.commercialStatus = commercialStatus;
      this.busServiceDetails = busServiceDetails;
      this.ruleFlowName = ruleFlowName;
      this.selectedRow = selectedRow;
      this.commonElements = commonElements;
      this.entityDetails = entityDetails;
      this.slabDetails = slabDetails;
   }

}