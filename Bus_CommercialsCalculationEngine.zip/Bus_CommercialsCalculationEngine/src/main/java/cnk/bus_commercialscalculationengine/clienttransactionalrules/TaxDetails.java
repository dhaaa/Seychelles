package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class TaxDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String taxName;
   private double taxValue;

   public TaxDetails()
   {
   }

   public java.lang.String getTaxName()
   {
      return this.taxName;
   }

   public void setTaxName(java.lang.String taxName)
   {
      this.taxName = taxName;
   }

   public double getTaxValue()
   {
      return this.taxValue;
   }

   public void setTaxValue(double taxValue)
   {
      this.taxValue = taxValue;
   }

   public TaxDetails(java.lang.String taxName, double taxValue)
   {
      this.taxName = taxName;
      this.taxValue = taxValue;
   }

}