package cnk.bus_commercialscalculationengine.clienttransactionalrules;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class AdditionalCommercialDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String commercialName;
   private double commercialAmount;
   private double commercialCalculationPercentage;
   private double commercialCalculationAmount;
   private java.lang.String commercialFareComponent;
   private java.lang.String commercialCurrency;

   public AdditionalCommercialDetails()
   {
   }

   public java.lang.String getCommercialName()
   {
      return this.commercialName;
   }

   public void setCommercialName(java.lang.String commercialName)
   {
      this.commercialName = commercialName;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public double getCommercialCalculationPercentage()
   {
      return this.commercialCalculationPercentage;
   }

   public void setCommercialCalculationPercentage(
         double commercialCalculationPercentage)
   {
      this.commercialCalculationPercentage = commercialCalculationPercentage;
   }

   public double getCommercialCalculationAmount()
   {
      return this.commercialCalculationAmount;
   }

   public void setCommercialCalculationAmount(
         double commercialCalculationAmount)
   {
      this.commercialCalculationAmount = commercialCalculationAmount;
   }

   public java.lang.String getCommercialFareComponent()
   {
      return this.commercialFareComponent;
   }

   public void setCommercialFareComponent(
         java.lang.String commercialFareComponent)
   {
      this.commercialFareComponent = commercialFareComponent;
   }

   public java.lang.String getCommercialCurrency()
   {
      return this.commercialCurrency;
   }

   public void setCommercialCurrency(java.lang.String commercialCurrency)
   {
      this.commercialCurrency = commercialCurrency;
   }

   public AdditionalCommercialDetails(java.lang.String commercialName,
         double commercialAmount, double commercialCalculationPercentage,
         double commercialCalculationAmount,
         java.lang.String commercialFareComponent,
         java.lang.String commercialCurrency)
   {
      this.commercialName = commercialName;
      this.commercialAmount = commercialAmount;
      this.commercialCalculationPercentage = commercialCalculationPercentage;
      this.commercialCalculationAmount = commercialCalculationAmount;
      this.commercialFareComponent = commercialFareComponent;
      this.commercialCurrency = commercialCurrency;
   }

}