package cnk.bus_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include=Inclusion.NON_NULL)
public class RetentionCommercialDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String commercialName;
   private double retentionPercentage;
   private double retentionAmountPercentage;
   private double commercialAmount;
   private double remainingPercentageAmount;
   private double remainingAmount;

   public RetentionCommercialDetails()
   {
   }

   public java.lang.String getCommercialName()
   {
      return this.commercialName;
   }

   public void setCommercialName(java.lang.String commercialName)
   {
      this.commercialName = commercialName;
   }

   public double getRetentionPercentage()
   {
      return this.retentionPercentage;
   }

   public void setRetentionPercentage(double retentionPercentage)
   {
      this.retentionPercentage = retentionPercentage;
   }

   public double getRetentionAmountPercentage()
   {
      return this.retentionAmountPercentage;
   }

   public void setRetentionAmountPercentage(double retentionAmountPercentage)
   {
      this.retentionAmountPercentage = retentionAmountPercentage;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public double getRemainingPercentageAmount()
   {
      return this.remainingPercentageAmount;
   }

   public void setRemainingPercentageAmount(double remainingPercentageAmount)
   {
      this.remainingPercentageAmount = remainingPercentageAmount;
   }

   public double getRemainingAmount()
   {
      return this.remainingAmount;
   }

   public void setRemainingAmount(double remainingAmount)
   {
      this.remainingAmount = remainingAmount;
   }

   public RetentionCommercialDetails(java.lang.String commercialName,
         double retentionPercentage,
         double retentionAmountPercentage, double commercialAmount,
         double remainingPercentageAmount, double remainingAmount)
   {
      this.commercialName = commercialName;
      this.retentionPercentage = retentionPercentage;
      this.retentionAmountPercentage = retentionAmountPercentage;
      this.commercialAmount = commercialAmount;
      this.remainingPercentageAmount = remainingPercentageAmount;
      this.remainingAmount = remainingAmount;
   }

}