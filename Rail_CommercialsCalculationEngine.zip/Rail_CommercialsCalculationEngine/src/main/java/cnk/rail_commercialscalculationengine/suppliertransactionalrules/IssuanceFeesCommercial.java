package cnk.rail_commercialscalculationengine.suppliertransactionalrules;

public class IssuanceFeesCommercial implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees;
   private java.lang.String selectedRow;

   private boolean advancedDefinitionCompleted;

   public IssuanceFeesCommercial()
   {
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial getSectorWiseIncentive()
   {
      return this.sectorWiseIncentive;
   }

   public void setSectorWiseIncentive(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive)
   {
      this.sectorWiseIncentive = sectorWiseIncentive;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial getOverriding()
   {
      return this.overriding;
   }

   public void setOverriding(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding)
   {
      this.overriding = overriding;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial getPlb()
   {
      return this.plb;
   }

   public void setPlb(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb)
   {
      this.plb = plb;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial getSegmentFees()
   {
      return this.segmentFees;
   }

   public void setSegmentFees(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees)
   {
      this.segmentFees = segmentFees;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial getServiceCharge()
   {
      return this.serviceCharge;
   }

   public void setServiceCharge(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge)
   {
      this.serviceCharge = serviceCharge;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial getManagementFees()
   {
      return this.managementFees;
   }

   public void setManagementFees(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees)
   {
      this.managementFees = managementFees;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public IssuanceFeesCommercial(
         java.lang.String selectedRow,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
   }

   public boolean isAdvancedDefinitionCompleted()
   {
      return this.advancedDefinitionCompleted;
   }

   public void setAdvancedDefinitionCompleted(boolean advancedDefinitionCompleted)
   {
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

   public IssuanceFeesCommercial(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees,
         java.lang.String selectedRow, boolean advancedDefinitionCompleted)
   {
      this.sectorWiseIncentive = sectorWiseIncentive;
      this.commercialHead = commercialHead;
      this.overriding = overriding;
      this.plb = plb;
      this.segmentFees = segmentFees;
      this.serviceCharge = serviceCharge;
      this.managementFees = managementFees;
      this.selectedRow = selectedRow;
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

}