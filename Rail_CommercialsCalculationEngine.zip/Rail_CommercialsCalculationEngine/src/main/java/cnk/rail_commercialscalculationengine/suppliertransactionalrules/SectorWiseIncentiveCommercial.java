package cnk.rail_commercialscalculationengine.suppliertransactionalrules;

public class SectorWiseIncentiveCommercial implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String selectedRow;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees;
   private cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees;

   private boolean advancedDefinitionCompleted;

   public SectorWiseIncentiveCommercial()
   {
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial getOverriding()
   {
      return this.overriding;
   }

   public void setOverriding(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding)
   {
      this.overriding = overriding;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial getPlb()
   {
      return this.plb;
   }

   public void setPlb(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb)
   {
      this.plb = plb;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial getSegmentFees()
   {
      return this.segmentFees;
   }

   public void setSegmentFees(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees)
   {
      this.segmentFees = segmentFees;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial getServiceCharge()
   {
      return this.serviceCharge;
   }

   public void setServiceCharge(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge)
   {
      this.serviceCharge = serviceCharge;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial getIssuanceFees()
   {
      return this.issuanceFees;
   }

   public void setIssuanceFees(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees)
   {
      this.issuanceFees = issuanceFees;
   }

   public cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial getManagementFees()
   {
      return this.managementFees;
   }

   public void setManagementFees(
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees)
   {
      this.managementFees = managementFees;
   }

   public SectorWiseIncentiveCommercial(
         java.lang.String selectedRow,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
   }

   public boolean isAdvancedDefinitionCompleted()
   {
      return this.advancedDefinitionCompleted;
   }

   public void setAdvancedDefinitionCompleted(boolean advancedDefinitionCompleted)
   {
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

   public SectorWiseIncentiveCommercial(
         java.lang.String selectedRow,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees,
         cnk.rail_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees,
         boolean advancedDefinitionCompleted)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
      this.overriding = overriding;
      this.plb = plb;
      this.segmentFees = segmentFees;
      this.serviceCharge = serviceCharge;
      this.issuanceFees = issuanceFees;
      this.managementFees = managementFees;
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

}