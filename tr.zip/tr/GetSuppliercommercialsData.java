package test;


import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.commons.io.FileUtils;


public class GetSuppliercommercialsData {
	
	private static void readJSON() throws Exception {
	    File file = new File("D:\\AVAMAR BACKUP\\Vasudha Bijur\\Desktop\\Req.json");
	    File advFile=new File("D:\\AVAMAR BACKUP\\Vasudha Bijur\\Desktop\\tr\\MDM\\advanceCommercial_schema.txt");
	    String content = FileUtils.readFileToString(file, "utf-8");
	    String advcontent = FileUtils.readFileToString(advFile, "utf-8");
	    JSONObject commDefnJson = new JSONObject(); 
	    JSONObject mdmDefn = new JSONObject(content);
	    JSONObject mdmAdvDefn = new JSONObject(advcontent);
 	     
	    JSONObject ipJson = new JSONObject();
	    ipJson.put("commercialName","definition");
	    ipJson.put("type","definition");
	    ipJson.put("supplier", mdmDefn.getJSONObject("commercialDefinition").get("supplierId"));
	    ipJson.put("supplierMarket",mdmDefn.getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
	    ipJson.put("productCategorySubType",mdmDefn.getJSONObject("commercialDefinition").get("productCategorySubType"));
	    
	    //Define Commercial Head Array
	    JSONArray commHead =new JSONArray();
	    
	    //Define Standard Commercial
	    JSONObject stdComm = new JSONObject();
	    
	    if(mdmDefn.has("standardCommercial")){
	    	stdComm.put("commercialHeadName","Standard");
	    	stdComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONObject("standardCommercial").getJSONObject("commercialInformation").has("commercialType")){
	    	stdComm.put("commercialType",mdmDefn.getJSONObject("standardCommercial").getJSONObject("commercialInformation").get("commercialType"));
	    	}
	    	if(mdmDefn.getJSONObject("standardCommercial").has("isSettlementTransactionWise")){
	    	stdComm.put("settlementTransactionWise",mdmDefn.getJSONObject("standardCommercial").get("isSettlementTransactionWise"));
	    	}
	    	stdComm.put("contractType",mdmDefn.getJSONObject("standardCommercial").getJSONObject("commercialInformation").get("isProvisional"));
	    	if(mdmDefn.getJSONObject("standardCommercial").has("isCommisionable")){
	    	stdComm.put("commissionable",mdmDefn.getJSONObject("standardCommercial").get("isCommisionable"));
	    	}
	    	if(mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("applicable")){
	    	stdComm.put("markDownApplicable",mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("applicable"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("clientType")){
	    	stdComm.put("markDownClientApplicable",mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("clientType"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("minimumPercent")){
	    	stdComm.put("minimumMarkUpPercentage",mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("minimumPercent"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("maximumPercent")){
	    		stdComm.put("maximumMarkUpPercentage",mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("maximumPercent"));
		    }
	    	
	    	if(mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").has("clientType")){
	    		stdComm.put("markUpClientType",mdmDefn.getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").get("clientType"));
		    }
	       	stdComm.put("status","");
	 
	    }
	  
	    commHead.put(stdComm);			//Add Standard Commercial to Commercial Head Array
	    
	    
	    //Define Overriding Commercial
	    JSONObject ovrdngComm = new JSONObject();
	    
	    if(mdmAdvDefn.getJSONObject("advanceCommercial").has("overRidingCommission"))
	    	ovrdngComm.put("commercialHeadName","Overriding");
	    
	    commHead.put(ovrdngComm);	
	    
	    ipJson.put("commercialHead", commHead);
	    
	    commDefnJson.put("CommercialDefinitionDT",ipJson);
	    System.out.println(commDefnJson.toString());
	}
	
	public static void main(String args[]){
		GetSuppliercommercialsData t = null;
		try {
			t.readJSON();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
