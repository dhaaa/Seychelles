package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class BusinessRuleIntake implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition;
   private java.util.List<java.lang.String> commercialStatus;
   private java.lang.String ruleFlowName;
   private java.lang.String selectedRow;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails;

   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails;

   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> hotelDetails;

   public static boolean checkDate(String configuredInput, Date conditionValue)
   {

      try
      {
         String[] configuredInputList = configuredInput.split(";");
         DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

         if (configuredInputList[0].equals("LESSTHANEQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return (date.after(conditionValue) || date.equals(conditionValue));

         }
         else if (configuredInputList[0].equals("GREATERTHANEQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return (date.before(conditionValue) || date.equals(conditionValue));

         }
         else if (configuredInputList[0].equals("BETWEEN"))
         {

            Date lowerLimit = format.parse(configuredInputList[1]);
            Date upperLimit = format.parse(configuredInputList[2]);
            return ((lowerLimit.before(conditionValue) || lowerLimit.equals(conditionValue)) && (upperLimit.after(conditionValue) || upperLimit.equals(conditionValue)));

         }
         else if (configuredInputList[0].equals("EQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return date.equals(conditionValue);

         }
         else if (configuredInputList[0].equals("IN"))
         {

            String date = format.format(conditionValue);
            return Arrays.asList(configuredInputList[1].split("/")).contains(date);
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }

      return false;
   }

   public BusinessRuleIntake()
   {
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition getAdvancedDefinition()
   {
      return this.advancedDefinition;
   }

   public void setAdvancedDefinition(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition)
   {
      this.advancedDefinition = advancedDefinition;
   }

   public java.util.List<java.lang.String> getCommercialStatus()
   {
      return this.commercialStatus;
   }

   public void setCommercialStatus(
         java.util.List<java.lang.String> commercialStatus)
   {
      this.commercialStatus = commercialStatus;
   }

   public java.lang.String getRuleFlowName()
   {
      return this.ruleFlowName;
   }

   public void setRuleFlowName(java.lang.String ruleFlowName)
   {
      this.ruleFlowName = ruleFlowName;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements getCommonElements()
   {
      return this.commonElements;
   }

   public void setCommonElements(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements)
   {
      this.commonElements = commonElements;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> getEntityDetails()
   {
      return this.entityDetails;
   }

   public void setEntityDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails)
   {
      this.entityDetails = entityDetails;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> getHotelDetails()
   {
      return this.hotelDetails;
   }

   public void setHotelDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> hotelDetails)
   {
      this.hotelDetails = hotelDetails;
   }

   public BusinessRuleIntake(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition,
         java.util.List<java.lang.String> commercialStatus,
         java.lang.String ruleFlowName,
         java.lang.String selectedRow,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> hotelDetails)
   {
      this.advancedDefinition = advancedDefinition;
      this.commercialStatus = commercialStatus;
      this.ruleFlowName = ruleFlowName;
      this.selectedRow = selectedRow;
      this.commonElements = commonElements;
      this.entityDetails = entityDetails;
      this.slabDetails = slabDetails;
      this.hotelDetails = hotelDetails;
   }

}