package cnk.acco_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)

public class AdvancedDefinition implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private boolean isAdvanceDefinition;
   private java.util.Date travelDate;
   private java.util.Date salesDate;
   private java.lang.String fromContinent;
   private java.lang.String fromCountry;
   private java.lang.String fromState;
   private java.lang.String fromCity;
   private java.lang.String viaContinent;
   private java.lang.String viaCountry;
   private java.lang.String viaState;
   private java.lang.String viaCity;
   private java.lang.String toContinent;
   private java.lang.String toCountry;
   private java.lang.String toState;
   private java.lang.String toCity;

   private java.lang.String roomCategory;

   private java.lang.String roomType;

   private java.lang.String bookingType;

   private java.lang.String connectivitySupplier;

   private java.lang.String connectivitySupplierType;

   private java.lang.String credentialsName;

   private java.lang.String passengerType;

   private java.lang.String travelType;

   private java.lang.String travelProductName;

   private java.lang.String nationality;

   public AdvancedDefinition()
   {
   }

   public boolean isIsAdvanceDefinition()
   {
      return this.isAdvanceDefinition;
   }

   public void setIsAdvanceDefinition(boolean isAdvanceDefinition)
   {
      this.isAdvanceDefinition = isAdvanceDefinition;
   }

   public java.util.Date getTravelDate()
   {
      return this.travelDate;
   }

   public void setTravelDate(java.util.Date travelDate)
   {
      this.travelDate = travelDate;
   }

   public java.util.Date getSalesDate()
   {
      return this.salesDate;
   }

   public void setSalesDate(java.util.Date salesDate)
   {
      this.salesDate = salesDate;
   }

   public java.lang.String getFromContinent()
   {
      return this.fromContinent;
   }

   public void setFromContinent(java.lang.String fromContinent)
   {
      this.fromContinent = fromContinent;
   }

   public java.lang.String getFromCountry()
   {
      return this.fromCountry;
   }

   public void setFromCountry(java.lang.String fromCountry)
   {
      this.fromCountry = fromCountry;
   }

   public java.lang.String getFromState()
   {
      return this.fromState;
   }

   public void setFromState(java.lang.String fromState)
   {
      this.fromState = fromState;
   }

   public java.lang.String getFromCity()
   {
      return this.fromCity;
   }

   public void setFromCity(java.lang.String fromCity)
   {
      this.fromCity = fromCity;
   }

   public java.lang.String getViaContinent()
   {
      return this.viaContinent;
   }

   public void setViaContinent(java.lang.String viaContinent)
   {
      this.viaContinent = viaContinent;
   }

   public java.lang.String getviaCountry()
   {
      return this.viaCountry;
   }

   public void setViaCountry(java.lang.String viaCountry)
   {
      this.viaCountry = viaCountry;
   }

   public java.lang.String getViaState()
   {
      return this.viaState;
   }

   public void setViaState(java.lang.String viaState)
   {
      this.viaState = viaState;
   }

   public java.lang.String getViaCity()
   {
      return this.viaCity;
   }

   public void setViaCity(java.lang.String viaCity)
   {
      this.viaCity = viaCity;
   }

   public java.lang.String getToContinent()
   {
      return this.toContinent;
   }

   public void setToContinent(java.lang.String toContinent)
   {
      this.toContinent = toContinent;
   }

   public java.lang.String getToCountry()
   {
      return this.toCountry;
   }

   public void setToCountry(java.lang.String toCountry)
   {
      this.toCountry = toCountry;
   }

   public java.lang.String getToState()
   {
      return this.toState;
   }

   public void setToState(java.lang.String toState)
   {
      this.toState = toState;
   }

   public java.lang.String getToCity()
   {
      return this.toCity;
   }

   public void setToCity(java.lang.String toCity)
   {
      this.toCity = toCity;
   }

   public java.lang.String getRoomCategory()
   {
      return this.roomCategory;
   }

   public void setRoomCategory(java.lang.String roomCategory)
   {
      this.roomCategory = roomCategory;
   }

   public java.lang.String getRoomType()
   {
      return this.roomType;
   }

   public void setRoomType(java.lang.String roomType)
   {
      this.roomType = roomType;
   }

   public java.lang.String getBookingType()
   {
      return this.bookingType;
   }

   public void setBookingType(java.lang.String bookingType)
   {
      this.bookingType = bookingType;
   }

   public java.lang.String getConnectivitySupplier()
   {
      return this.connectivitySupplier;
   }

   public void setConnectivitySupplier(java.lang.String connectivitySupplier)
   {
      this.connectivitySupplier = connectivitySupplier;
   }

   public java.lang.String getConnectivitySupplierType()
   {
      return this.connectivitySupplierType;
   }

   public void setConnectivitySupplierType(
         java.lang.String connectivitySupplierType)
   {
      this.connectivitySupplierType = connectivitySupplierType;
   }

   public java.lang.String getCredentialsName()
   {
      return this.credentialsName;
   }

   public void setCredentialsName(java.lang.String credentialsName)
   {
      this.credentialsName = credentialsName;
   }

   public java.lang.String getPassengerType()
   {
      return this.passengerType;
   }

   public void setPassengerType(java.lang.String passengerType)
   {
      this.passengerType = passengerType;
   }

   public java.lang.String getTravelType()
   {
      return this.travelType;
   }

   public void setTravelType(java.lang.String travelType)
   {
      this.travelType = travelType;
   }

   public java.lang.String getTravelProductName()
   {
      return this.travelProductName;
   }

   public void setTravelProductName(java.lang.String travelProductName)
   {
      this.travelProductName = travelProductName;
   }

   public java.lang.String getNationality()
   {
      return this.nationality;
   }

   public void setNationality(java.lang.String nationality)
   {
      this.nationality = nationality;
   }

   public AdvancedDefinition(boolean isAdvanceDefinition,
         java.util.Date travelDate, java.util.Date salesDate,
         java.lang.String fromContinent, java.lang.String fromCountry,
         java.lang.String fromState, java.lang.String fromCity,
         java.lang.String viaContinent, java.lang.String viaCountry,
         java.lang.String viaState, java.lang.String viaCity,
         java.lang.String toContinent, java.lang.String toCountry,
         java.lang.String toState, java.lang.String toCity,
         java.lang.String roomCategory, java.lang.String roomType,
         java.lang.String bookingType, java.lang.String connectivitySupplier,
         java.lang.String connectivitySupplierType,
         java.lang.String credentialsName, java.lang.String passengerType,
         java.lang.String travelType, java.lang.String travelProductName,
         java.lang.String nationality)
   {
      this.isAdvanceDefinition = isAdvanceDefinition;
      this.travelDate = travelDate;
      this.salesDate = salesDate;
      this.fromContinent = fromContinent;
      this.fromCountry = fromCountry;
      this.fromState = fromState;
      this.fromCity = fromCity;
      this.viaContinent = viaContinent;
      this.viaCountry = viaCountry;
      this.viaState = viaState;
      this.viaCity = viaCity;
      this.toContinent = toContinent;
      this.toCountry = toCountry;
      this.toState = toState;
      this.toCity = toCity;
      this.roomCategory = roomCategory;
      this.roomType = roomType;
      this.bookingType = bookingType;
      this.connectivitySupplier = connectivitySupplier;
      this.connectivitySupplierType = connectivitySupplierType;
      this.credentialsName = credentialsName;
      this.passengerType = passengerType;
      this.travelType = travelType;
      this.travelProductName = travelProductName;
      this.nationality = nationality;
   }

}