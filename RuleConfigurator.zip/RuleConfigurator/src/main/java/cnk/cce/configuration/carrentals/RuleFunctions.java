package cnk.cce.configuration.carrentals;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.gson.Gson;
import cnk.cce.configuration.MappingConfiguration;
import cnk.cce.maven.MavenInvoker;

public class RuleFunctions {

	//@SuppressWarnings("unchecked")
	public static String insertRule(String DTname, Map<String, Object> map, String packageDir, String productName, String commercialType, String entityType) throws NumberFormatException, IOException{
		if(Configuration.checkValid(map.get("type").toString(),map.get("RuleID").toString())){
			String selectedRow="",settlement="",suppMarketSelectedRow="",entityMarketSelectedRow=""; 
			int commHead=0,inclusion=0,exclusion=0,contractValidity=0,arrList=0,otherFeesPercentage=0,msf=0,slab=0,incentive=0,ltb=0,foc=0,trigger=0,dontEnter=0;
			HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(packageDir+"/"+DTname+".xls")));
			Sheet sheet = wb.getSheetAt(0);
			Row row1 = sheet.createRow(sheet.getLastRowNum()+1);
			String supplier=(String)map.get("supplier");
			if(supplier==null)
				supplier=productName;
			/*if(commercialType.equals("settlement")){
				if(entityType.equals("supplier"))
					suppMarketSelectedRow = Configuration.getSupplierMarket((ArrayList<String>)map.get("supplierMarket"));
				else entityMarketSelectedRow = Configuration.getEntityMarket((ArrayList<String>)map.get("entityMarket"));
			}*/
			for (String name : map.keySet()){
				if(!name.equals("type")){
					if(DTname.equals("MSFFeeDT") && (name.equals("currency") || name.equals("amount") || name.equals("serviceTaxApplicable"))){
						msf=1;
						Configuration.msfFeeInsertion((String)map.get("currency"),Double.parseDouble((String)map.get("amount")),(Boolean)map.get("serviceTaxApplicable"),productName,row1,DTname,commercialType,entityType);
					}
					if(map.get(name) instanceof List){
						JSONArray EntireJsonArr = new JSONObject(map).getJSONArray(name);
						for (int j=0; j < EntireJsonArr.length(); j++){
							if(EntireJsonArr.length()>0){
								if(EntireJsonArr.get(j) instanceof String){																									//value is ArrayList
									arrList=1;
									if(productName.equals("accomodation") && commercialType.equals("transactional") && (name.equals("passengerType") || name.equals("rateType") || name.equals("rateCode")))			//for ACCOMODATION only
										Configuration.insertArrayListValues("inclusionIOTP",name,EntireJsonArr,productName,row1,DTname,commercialType,entityType);
									else Configuration.insertArrayListValues("inclusion",name,EntireJsonArr,productName,row1,DTname,commercialType,entityType);
									break;
								}
								else {
									JSONObject PartJsonObject = (JSONObject)EntireJsonArr.get(j);																			//value is JSONObject
									if(name.equals("commercialHead") || PartJsonObject.has("inclusion") || PartJsonObject.has("exclusion") || PartJsonObject.has("trigger"))
									{
										if(name.equals("commercialHead")){
											commHead = 1;
											if(entityType.equals("supplier")){																								//entityType: SUPPLIER
												if(commercialType.equals("transactional"))
													Configuration.getSupplierTransactionalCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);
												else Configuration.getSupplierSettlementCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);
											}
											else{																															//entityType: CLIENT
												if(commercialType.equals("transactional"))
													Configuration.getClientTransactionalCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);
												else Configuration.getSupplierSettlementCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);	//functionality is same for both client & supplier
											}
										}
										if(PartJsonObject.has("trigger")){
											trigger=1;
											Configuration.setTriggerPayout(EntireJsonArr,productName,row1,DTname,commercialType,entityType,name);
											break;
										}
										if(PartJsonObject.has("inclusion")){
											inclusion=1;
											JSONArray IncJsonArr = PartJsonObject.getJSONArray("inclusion");
											Configuration.setInclusionExclusion("inclusion",IncJsonArr,productName,row1,DTname,commercialType,entityType,name);
										}
										if(PartJsonObject.has("exclusion")){
											exclusion=1;
											JSONArray IncJsonArr = PartJsonObject.getJSONArray("exclusion");
											Configuration.setInclusionExclusion("exclusion",IncJsonArr,productName,row1,DTname,commercialType,entityType,name);
										}
									}
									else{																																	//values other than commHead, inclusion, exclusion, but are JSONObjects
										if(commercialType.equals("settlement")){
											if(name.equals("percentage") || name.equals("returnableCommercialHead")){
												otherFeesPercentage=1;
												Configuration.insertOtherFeesPercentage(EntireJsonArr,productName,row1,DTname,entityType,commercialType);					//OtherFees : commercialPercentage
												break;
											}
										}
									}
								}
							}
						}
					}
					switch(name){
					case "slabDetails": {
						slab=1;
						Configuration.insertSlabDetails(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
					}
					case "contractValidity": {
						contractValidity=1;
						Configuration.setContractValidity(name,new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
					}
					case "totalSettlementAmount": {
						contractValidity=1;
						Configuration.setContractValidity(name,new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
					}
					case "periodForTopUp": {																															//Incentive On Top Up
						incentive=1;
						Configuration.insertIncentiveOnTopUp(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
					}
					case "freeOfCosts": {
						foc=1;
						Configuration.insertFOC(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
					}
					case "lookToBook": {
						ltb=1;
						if(!new JSONObject(new Gson().toJson(map.get(name))).has("lookRate")){																			//Look to Book by Ratio
							if(entityType.equals("supplier"))
								Configuration.insertLTB(new JSONObject(new Gson().toJson(map.get(name))),supplier,suppMarketSelectedRow,null,null,null,productName,row1,DTname,commercialType,entityType);
							else Configuration.insertLTB(new JSONObject(new Gson().toJson(map.get(name))),supplier,null,(String)map.get("entityName"),entityMarketSelectedRow,(String)map.get("entityType"),productName,row1,DTname,commercialType,entityType);
						}
						else Configuration.setLookToBookRate(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType);		//Look to Book by Rate
					}
					}

					if(commHead==0 && exclusion==0 && inclusion==0 && contractValidity==0 && arrList==0 && otherFeesPercentage==0 && msf==0 && slab==0 && incentive==0 && ltb==0 && foc==0 && trigger==0){
						int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
						Cell cell = row1.createCell(columnIndex);
						try{
							double value=Double.parseDouble(map.get(name).toString());
							cell.setCellValue(value);
						}catch(Exception e){
							if(map.get("type").equals("calculation") && (name.equals("fareComponent")||name.equals("currency"))){
								if(name.equals("fareComponent"))
									Configuration.setFareComponent(map,cell,productName,row1,DTname,commercialType,entityType,name);
								else cell.setCellValue(map.get(name).toString());
							}
							else cell.setCellValue('"'+map.get(name).toString()+'"');
						}
					}commHead=0;exclusion=0;inclusion=0;contractValidity=0;arrList=0;otherFeesPercentage=0;msf=0;slab=0;incentive=0;ltb=0;trigger=0;
				}
			}

			if(foc==0){
				int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanCount"));
				for(int count=1;count<=booleanCount;count++)
				{
					int columnIndex=Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_"+count));
					Cell cell = row1.createCell(columnIndex);
					if(commercialType.equals("settlement") && (entityType+"_"+commercialType+"_"+DTname+"_booleanValue_"+count).equals((entityType+"_settlement_SignUpBonusDT_booleanValue_1")) || (entityType+"_"+commercialType+"_"+DTname+"_booleanValue_"+count).equals(entityType+"_settlement_PenaltyFeeDT_booleanValue_1"))
						cell.setCellValue(false);
					else cell.setCellValue(true);
				}
			}foc=0;

			if(Boolean.parseBoolean(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_hardCode")))
			{
				int hardCodeCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_hardCodeCount"));
				for(int count=1;count<=hardCodeCount;count++)
				{
					Cell cell = row1.createCell(Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_hardCodeIndex_"+count)));
					cell.setCellValue(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_hardCodeValue_"+count));
				}
			}

			/*if(entityType.equals("supplier")){
				selectedRow = Configuration.getSelectedRow(productName,supplier,suppMarketSelectedRow,(String)map.get("commercialName"),(String)map.get("type"),commercialType,(String)map.get("productCategorySubType"));
				if(commercialType.equals("settlement")){
					int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_ruleID"));
					Cell cell=row1.createCell(columnIndex);
					settlement=setRuleID(productName,entityType,supplier,suppMarketSelectedRow,null,null,null,cell,DTname);
				}else{
					int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_commercialName"));
					Cell cell = row1.getCell(columnIndex);
					if(cell==null)
						row1.createCell(columnIndex);
					cell.setCellValue(selectedRow);
				}
			}else{
				selectedRow = Configuration.getClientSelectedRow(productName,supplier,(String)map.get("commercialName"),(String)map.get("type"),entityType,commercialType,(String)map.get("entityName"),entityMarketSelectedRow,(String)map.get("entityType"));
				if(commercialType.equals("settlement")){
					int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_ruleID"));
					Cell cell=row1.createCell(columnIndex);
					settlement=setRuleID(productName,entityType,supplier,null,(String)map.get("entityName"),entityMarketSelectedRow,(String)map.get("entityType"),cell,DTname);
				}else{
					if(selectedRow!="ERROR: No entry in CommercialDefinitionDT"){
						int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_commercialName"));
						Cell cell = row1.getCell(columnIndex);
						if(cell==null)
							row1.createCell(columnIndex);
						cell.setCellValue(selectedRow);
					}else dontEnter=1;
				}
			}*/

			/*if(map.get("type").equals("advanced")){
				int columnIndexESR = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_entitySelectedRow"));
				Cell cellESR=row1.createCell(columnIndexESR);
				cellESR.setCellValue((String)map.get("entityName")+"_"+entityMarketSelectedRow+"_"+(String)map.get("entityType")+"_"+supplier);
				int columnIndexES = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_entityStatus"));
				Cell cellES=row1.createCell(columnIndexES);
				cellES.setCellValue(selectedRow);
			}

			if(map.get("type").equals("base"))
			{
				switch(productName){
				case "air": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.airselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "activities": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.activitiesselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "accomodation": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.accomodationselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "bus": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.busselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "rail": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.railselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "cruise": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.cruiseselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "insurance": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.insuranceselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "carrentals": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.selectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "holidays": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.holidaysselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				case "visa": {Configuration.insertIntoSheet("_selectedRow",supplier+"_"+MappingConfiguration.visaselectedRowsST.get(supplier).get(suppMarketSelectedRow).get((String)map.get("productCategorySubType")), productName, entityType, commercialType, DTname, row1);break;}
				}
			}*/

			FileOutputStream fos = new FileOutputStream(packageDir+"/"+DTname+".xls");
			if(dontEnter==0)
				wb.write(fos);

			if(commercialType.equals("settlement") && (DTname.equals("LookToBookDT") || DTname.equals("LookToBookCumulativeDT"))){
				if(entityType.equals("supplier"))
					checkLookToBook(DTname,map,supplier,suppMarketSelectedRow,packageDir,productName,commercialType,entityType,sheet,null,null,null,wb,(String)map.get("productCategorySubType"));
				else checkLookToBook(DTname,map,supplier,null,packageDir,productName,commercialType,entityType,sheet,(String)map.get("entityName"),entityMarketSelectedRow,(String)map.get("entityType"),wb,null);
			}

			FileOutputStream fos1 = new FileOutputStream(packageDir+"/"+DTname+".xls");
			wb.write(fos1);
			fos1.close();  fos.close(); wb.close();

			if(commercialType.equals("settlement"))
				return settlement;
			else{
				if(dontEnter==0)
					return selectedRow;
				else return null;
			}
		}else{
			updateRule(DTname,map,packageDir,productName,commercialType,entityType);
		}

		return null;
	}


	public static String setRuleID(String productName, String entityType, String supplier, String supplierMarket, String entityName, String entityMarket, String clientEntityType, Cell cell, String DTname){
		if(entityType.equals("supplier")){
			String value = supplier+"_"+supplierMarket+"_"+Configuration.getSettlementRuleID(productName,entityType,DTname,supplier,supplierMarket,"entityName","entityMarket","clientEntityType");
			cell.setCellValue(value);
			return value;
		}else {
			String value = entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+Configuration.getSettlementRuleID(productName,entityType,DTname,supplier,"supplierMarket",entityName,entityMarket,clientEntityType);
			cell.setCellValue(value);
			return value;
		}
	}


	//@SuppressWarnings("unchecked")
	public static String updateRule(String DTname, Map<String, Object> map, String packageDir, String productName, String commercialType, String entityType) throws IOException{
		int arrList=0,commHead=0,inclusion=0,exclusion=0,otherFeesPercentage=0,msf=0,slab=0,incentive=0,ltb=0,contractValidity=0,foc=0,fc=0,trigger=0;
		String RuleID="sR",suppMarketSelectedRow="",entityMarketSelectedRow=""; Row row1 = null;
		InputStream inp = new FileInputStream(packageDir+"/"+DTname+".xls");
			HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(inp));
			Sheet sheet = wb.getSheetAt(0);
			RuleID=map.get("RuleID").toString();
			int breakloop=0;
			//outer:
			for (Row row: sheet){
				int count=0;
				for (Cell cell: row){
					if(count<2){
						switch(cell.getCellTypeEnum()){
						case NUMERIC:{
							if (cell.getCellFormula().equals(RuleID.toString())){
								breakloop=1;
								row1=sheet.getRow(row.getRowNum());							//get row number for updation
								break;
							}
							break;
						}
						case BOOLEAN:{
							break;
						}
						default:{
							if (cell.getStringCellValue().equals('"'+RuleID+'"')){
								breakloop=1;
								System.out.println(DTname+": Updated");
								row1=sheet.getRow(row.getRowNum());							//get row number for updation
								break;
							}
							break;
						}
						}
						count++;
					}
				}
				if(breakloop==1)
					break;
			}breakloop=0;
			String supplier=(String)map.get("supplier");
			if(supplier==null)
				supplier=productName;
			/*if(entityType.equals("supplier"))
				suppMarketSelectedRow = Configuration.getSupplierMarket((ArrayList<String>)map.get("supplierMarket"));
			else entityMarketSelectedRow = Configuration.getEntityMarket((ArrayList<String>)map.get("entityMarket"));*/
			if(row1!=null){
				for (String name : map.keySet()){
					if(name.equals("remove")){
						JSONArray removeArr = new JSONObject(map).getJSONArray(name);
						Configuration.removeElements(removeArr,productName,row1,DTname,commercialType,entityType,packageDir,wb);
					}else{
						if(!name.equals("type")){
							if(DTname.equals("MSFFeeDT") && (name.equals("currency") || name.equals("amount") || name.equals("serviceTaxApplicable"))){
								msf=1;
								Configuration.msfFeeInsertion((String)map.get("currency"),Double.parseDouble((String)map.get("amount")),(Boolean)map.get("serviceTaxApplicable"),productName,row1,DTname,commercialType,entityType);
							}
							if(map.get(name) instanceof List){
								JSONArray EntireJsonArr = new JSONObject(map).getJSONArray(name);
								for (int j=0; j < EntireJsonArr.length(); j++){
									if(EntireJsonArr.get(j) instanceof String){																									//value is ArrayList
										arrList = 1;
										Configuration.insertArrayListValues("inclusion",name,EntireJsonArr,productName,row1,DTname,commercialType,entityType);
										break;
									}
									else {
										JSONObject PartJsonObject = (JSONObject)EntireJsonArr.get(j);																			//value is JSONObject
										if(name.equals("commercialHead") || PartJsonObject.has("inclusion") || PartJsonObject.has("exclusion") || PartJsonObject.has("trigger"))
										{
											if(name.equals("commercialHead")){
												commHead = 1;
												if(entityType.equals("supplier")){																								//entityType: SUPPLIER
													if(commercialType.equals("transactional"))
													{	Configuration.getSupplierTransactionalCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);}
													if(commercialType.equals("settlement"))
													{	Configuration.getSupplierSettlementCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);}
												}
												else{																															//entityType: CLIENT
													if(commercialType.equals("transactional"))
													{	Configuration.getClientTransactionalCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);}
													if(commercialType.equals("settlement"))
													{	Configuration.getSupplierSettlementCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);}	//functionality is same for both client & supplier
												}
											}
											if(PartJsonObject.has("trigger")){
												trigger=1;
												Configuration.setTriggerPayout(EntireJsonArr,productName,row1,DTname,commercialType,entityType,name);
												break;
											}
											if(PartJsonObject.has("inclusion")){
												inclusion=1;
												JSONArray IncJsonArr = PartJsonObject.getJSONArray("inclusion");
												Configuration.setInclusionExclusion("inclusion",IncJsonArr,productName,row1,DTname,commercialType,entityType,name);
											}
											if(PartJsonObject.has("exclusion")){
												exclusion=1;
												JSONArray IncJsonArr = PartJsonObject.getJSONArray("exclusion");
												Configuration.setInclusionExclusion("exclusion",IncJsonArr,productName,row1,DTname,commercialType,entityType,name);
											}
										}
										else{																																	//values other than commHead, inclusion, exclusion, but are JSONObjects
											if(commercialType.equals("settlement") && (name.equals("percentage") || name.equals("returnableCommercialHead"))){
												otherFeesPercentage=1;
												Configuration.insertOtherFeesPercentage(EntireJsonArr,productName,row1,DTname,entityType,commercialType);					//OtherFees : commercialPercentage
												break;
											}
										}
									}
								}
							}
							switch(name){
							case "slabDetails": {
								slab=1;
								Configuration.insertSlabDetails(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
							}
							case "contractValidity": {
								contractValidity=1;
								Configuration.setContractValidity(name,new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
							}
							case "totalSettlementAmount": {
								contractValidity=1;
								Configuration.setContractValidity(name,new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
							}
							case "periodForTopUp": {																													//Incentive On Top Up
								incentive=1;
								Configuration.insertIncentiveOnTopUp(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
							}
							case "freeOfCosts": {
								foc=1;
								Configuration.insertFOC(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType); break;
							}
							case "lookToBook": {
								ltb=1;
								if(!new JSONObject(new Gson().toJson(map.get(name))).has("lookRate")){																													//Look to Book by Ratio
									if(entityType.equals("supplier"))
										Configuration.insertLTB(new JSONObject(new Gson().toJson(map.get(name))),supplier,suppMarketSelectedRow,null,null,null,productName,row1,DTname,commercialType,entityType);
									else Configuration.insertLTB(new JSONObject(new Gson().toJson(map.get(name))),supplier,null,(String)map.get("entityName"),entityMarketSelectedRow,(String)map.get("entityType"),productName,row1,DTname,commercialType,entityType);
								}
								else Configuration.setLookToBookRate(new JSONObject(new Gson().toJson(map.get(name))),productName,row1,DTname,commercialType,entityType);												//Look to Book by Rate
								break;
							}
							case "fareComponent": {
								fc=1;
								Configuration.updateFareComponent(map,name,productName,entityType,commercialType,DTname,row1);
							}
							}

							if(commHead==0 && exclusion==0 && inclusion==0 && contractValidity==0 && arrList==0 && otherFeesPercentage==0 && msf==0 && slab==0 && incentive==0 && ltb==0 && foc==0 && fc==0 && trigger==0 && !name.equals("remove")){
								if(commercialType.equals("transactional") && name.equals("currency")){
									int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
									Cell cell = row1.createCell(columnIndex);
									cell.setCellValue((String)map.get(name));
								}else
									Configuration.insertIntoSheet("_"+name, map.get(name).toString(), productName, entityType, commercialType, DTname, row1);
							}commHead=0;exclusion=0;inclusion=0;contractValidity=0;arrList=0;otherFeesPercentage=0;msf=0;slab=0;incentive=0;ltb=0;fc=0;trigger=0;
						}
					}
				}
			}else System.out.println(DTname+": RuleID not found");

			FileOutputStream fos = new FileOutputStream(packageDir+"/"+DTname+".xls");
			wb.write(fos); fos.close();

			if(commercialType.equals("settlement") && (DTname.equals("LookToBookDT") || DTname.equals("LookToBookCumulativeDT"))){
				if(entityType.equals("supplier"))
					checkLookToBook(DTname,map,supplier,suppMarketSelectedRow,packageDir,productName,commercialType,entityType,sheet,"entityName","entityMarket","entityType",wb,(String)map.get("productCategorySubType"));
				else checkLookToBook(DTname,map,supplier,"supplierMarket",packageDir,productName,commercialType,entityType,sheet,(String)map.get("entityName"),entityMarketSelectedRow,(String)map.get("entityType"),wb,"productCategorySubType");
			}

			FileOutputStream fos1 = new FileOutputStream(packageDir+"/"+DTname+".xls");
			wb.write(fos1);
			fos1.close(); wb.close(); inp.close();
		

		return RuleID+" Updated";
	}


	public static void checkLookToBook(String DTname, Map<String, Object> map, String supplier, String supplierMarket, String packageDir, String productName, String commercialType, String entityType, Sheet sheet, String entityname, String entityMarket, String clientEntityType, HSSFWorkbook wb, String productcategorySubType) throws NumberFormatException, IOException{
		switch(productName){
		case "air": {
			lookToBook(Configuration.airclientRefreshCounterRule,Configuration.airrefreshCounterRule,Configuration.airclientChangeRefCount,Configuration.airchangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.airClientRefRuleID,MappingConfiguration.airClientLTB,MappingConfiguration.airSupplierRefRuleID,MappingConfiguration.airLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.airclientRefreshCounterRule=0;Configuration.airrefreshCounterRule=0;Configuration.airclientChangeRefCount=0;Configuration.airchangeRefCount=0; break;
		}
		case "activities": {
			lookToBook(Configuration.activitiesclientRefreshCounterRule,Configuration.activitiesrefreshCounterRule,Configuration.activitiesclientChangeRefCount,Configuration.activitieschangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.activitiesClientRefRuleID,MappingConfiguration.activitiesClientLTB,MappingConfiguration.activitiesSupplierRefRuleID,MappingConfiguration.activitiesLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.activitiesclientRefreshCounterRule=0;Configuration.activitiesrefreshCounterRule=0;Configuration.activitiesclientChangeRefCount=0;Configuration.activitieschangeRefCount=0; break;
		}
		case "accomodation": {
			lookToBook(Configuration.accomodationclientRefreshCounterRule,Configuration.accomodationrefreshCounterRule,Configuration.accomodationclientChangeRefCount,Configuration.accomodationchangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.accomodationClientRefRuleID,MappingConfiguration.accomodationClientLTB,MappingConfiguration.accomodationSupplierRefRuleID,MappingConfiguration.accomodationLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.accomodationclientRefreshCounterRule=0;Configuration.accomodationrefreshCounterRule=0;Configuration.accomodationclientChangeRefCount=0;Configuration.accomodationchangeRefCount=0; break;
		}
		case "bus": {
			lookToBook(Configuration.busclientRefreshCounterRule,Configuration.busrefreshCounterRule,Configuration.busclientChangeRefCount,Configuration.buschangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.busClientRefRuleID,MappingConfiguration.busClientLTB,MappingConfiguration.busSupplierRefRuleID,MappingConfiguration.busLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.busclientRefreshCounterRule=0;Configuration.busrefreshCounterRule=0;Configuration.busclientChangeRefCount=0;Configuration.buschangeRefCount=0; break;
		}
		case "rail": {
			lookToBook(Configuration.railclientRefreshCounterRule,Configuration.railrefreshCounterRule,Configuration.railclientChangeRefCount,Configuration.railchangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.railClientRefRuleID,MappingConfiguration.railClientLTB,MappingConfiguration.railSupplierRefRuleID,MappingConfiguration.railLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.railclientRefreshCounterRule=0;Configuration.railrefreshCounterRule=0;Configuration.railclientChangeRefCount=0;Configuration.railchangeRefCount=0; break;
		}
		case "cruise": {
			lookToBook(Configuration.cruiseclientRefreshCounterRule,Configuration.cruiserefreshCounterRule,Configuration.cruiseclientChangeRefCount,Configuration.cruisechangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.cruiseClientRefRuleID,MappingConfiguration.cruiseClientLTB,MappingConfiguration.cruiseSupplierRefRuleID,MappingConfiguration.cruiseLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.cruiseclientRefreshCounterRule=0;Configuration.cruiserefreshCounterRule=0;Configuration.cruiseclientChangeRefCount=0;Configuration.cruisechangeRefCount=0; break;
		}
		case "insurance": {
			lookToBook(Configuration.insuranceclientRefreshCounterRule,Configuration.insurancerefreshCounterRule,Configuration.insuranceclientChangeRefCount,Configuration.insurancechangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.insuranceClientRefRuleID,MappingConfiguration.insuranceClientLTB,MappingConfiguration.insuranceSupplierRefRuleID,MappingConfiguration.insuranceLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.insuranceclientRefreshCounterRule=0;Configuration.insurancerefreshCounterRule=0;Configuration.insuranceclientChangeRefCount=0;Configuration.insurancechangeRefCount=0; break;
		}
		case "carrentals": {
			lookToBook(Configuration.carclientRefreshCounterRule,Configuration.carrefreshCounterRule,Configuration.carclientChangeRefCount,Configuration.carchangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.carClientRefRuleID,MappingConfiguration.carClientLTB,MappingConfiguration.carSupplierRefRuleID,MappingConfiguration.carLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.carclientRefreshCounterRule=0;Configuration.carrefreshCounterRule=0;Configuration.carclientChangeRefCount=0;Configuration.carchangeRefCount=0; break;
		}
		case "holidays": {
			lookToBook(Configuration.holidaysclientRefreshCounterRule,Configuration.holidaysrefreshCounterRule,Configuration.holidaysclientChangeRefCount,Configuration.holidayschangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.holidaysClientRefRuleID,MappingConfiguration.holidaysClientLTB,MappingConfiguration.holidaysSupplierRefRuleID,MappingConfiguration.holidaysLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.holidaysclientRefreshCounterRule=0;Configuration.holidaysrefreshCounterRule=0;Configuration.holidaysclientChangeRefCount=0;Configuration.holidayschangeRefCount=0; break;
		}
		case "visa": {
			lookToBook(Configuration.visaclientRefreshCounterRule,Configuration.visarefreshCounterRule,Configuration.visaclientChangeRefCount,Configuration.visachangeRefCount,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,commercialType,DTname,productName,MappingConfiguration.visaClientRefRuleID,MappingConfiguration.visaClientLTB,MappingConfiguration.visaSupplierRefRuleID,MappingConfiguration.visaLTB,map,packageDir,sheet,productcategorySubType);
			Configuration.visaclientRefreshCounterRule=0;Configuration.visarefreshCounterRule=0;Configuration.visaclientChangeRefCount=0;Configuration.visachangeRefCount=0; break;
		}
		}

		FileOutputStream fos1 = new FileOutputStream(packageDir+"/"+DTname+".xls");
		wb.write(fos1);
		fos1.close();
	}


	public static void lookToBook(int clientRefreshCounterRule, int refreshCounterRule, int clientChangeRefCount, int changeRefCount, String supplier, String supplierMarket, String entityname, String entityMarket, String clientEntityType, String entityType, String commercialType, String DTname, String productName, Map<String,String> clientRefRuleID, Map<String,Integer> clientLTB, Map<String,String> supplierRefRuleID, Map<String,Integer> ltb, Map<String, Object> map, String packageDir, Sheet sheet, String productcategorySubType) throws NumberFormatException, IOException{
		if(clientRefreshCounterRule==1)
			Configuration.setRefreshCounterRule(DTname,map,supplier,supplierMarket,productName,packageDir,commercialType,entityType,sheet,productcategorySubType);

		if(refreshCounterRule==1)
			Configuration.setRefreshCounterRule(DTname,map,supplier,supplierMarket,productName,packageDir,commercialType,entityType,sheet,productcategorySubType);

		if(clientChangeRefCount==1){	//update refreshCounter Rule [CLIENT]
			List<String> rowNumber = Arrays.asList(clientRefRuleID.get(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier).split("_"));
			Row row=sheet.getRow(Integer.parseInt(rowNumber.get(4)));
			int columnIndexLTB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_refreshCounter"));
			Cell cellLTB = row.getCell(columnIndexLTB);
			if(cellLTB == null)
				cellLTB = row.createCell(columnIndexLTB);
			cellLTB.setCellValue(clientLTB.get(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
		}

		if(changeRefCount==1){			//update refreshCounter Rule [SUPPLIER]
			List<String> rowNumber = Arrays.asList(supplierRefRuleID.get(supplier+"_"+supplierMarket).split("_"));
			Row row=sheet.getRow(Integer.parseInt(rowNumber.get(1)));
			int columnIndexLTB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_refreshCounter"));
			Cell cellLTB = row.getCell(columnIndexLTB);
			if(cellLTB == null)
				cellLTB = row.createCell(columnIndexLTB);
			cellLTB.setCellValue(ltb.get(supplier+"_"+supplierMarket));
			JSONObject JsonObj = new JSONObject(new Gson().toJson(map.get("contractValidity")));
			Configuration.setContractValidity("contractValidity",JsonObj,productName,row,DTname,commercialType,entityType);
		}
	}


	public static String deleteRule(String DTname, Map<String, Object> map, String packageDir, String productName, String commercialType, String entityType) throws IOException{
		String selectedRow="SR";	Row row1 = null;
		InputStream inp = new FileInputStream(packageDir+"/"+DTname+".xls");
			HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(inp));
			Sheet sheet = wb.getSheetAt(0);
			selectedRow=(String)map.get("selectedRow");
			outer:
				for (Row row: sheet){
					int count=0;
					for (Cell cell: row){
						if(count>1)
							continue outer;
						if (cell.getStringCellValue().toString().equals(selectedRow)){
							row1=sheet.getRow(row.getRowNum());							//get row number for updation
							break;
						}
						count++;
					}
				}

			sheet.removeRow(row1);
			sheet.shiftRows(row1.getRowNum() + 1, sheet.getLastRowNum(), -1);

			FileOutputStream fos = new FileOutputStream(packageDir+"/"+DTname+".xls");
			wb.write(fos); fos.close(); wb.close(); inp.close();

		return "SuccessFul";
	}
}
