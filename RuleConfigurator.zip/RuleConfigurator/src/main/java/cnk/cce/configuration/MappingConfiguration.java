package cnk.cce.configuration;

import java.util.HashMap;
import java.util.Map;

public class MappingConfiguration {
	
	public static Map<String,String> _id = new HashMap<String,String>();
	public static Map<String,String> calc_id = new HashMap<String,String>();
	
	public static Map<String,Map<String, Map<String, Integer>>> selectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();//this map will keep record of selectedRows for supplier_transactional [CAR]
	public static Map<String,Map<String, Map<String, Integer>>> selectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();					//this map will keep record of selectedRows for supplier_settlement [CAR]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> selectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [CAR]
	public static Map<String,Integer> selectedRowSCT = new HashMap<String,Integer>();												//this map will keep record of selectedRows supplier_commercialName:counter [CAR]
	public static Map<String,Integer> selectedRowsCS = new HashMap<String, Integer>();												//this map will keep record of selectedRows for client_settlement [CAR]
	public static Map<String,Integer> carLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [CAR_SUPPLIER]
	public static Map<String,Integer> carClientLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [CAR_CLIENT]
	public static Map<String,Integer> carLTBCumSeq = new HashMap<String,Integer>();													//this map will keep record of supplier:cumulativeSequence [CAR_SUPPLIER]
	public static Map<String,Integer> carClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [CAR_CLIENT]
	public static Map<String,String> carSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CAR_SUPPLIER]
	public static Map<String,String> carClientRefRuleID = new HashMap<String,String>();												//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CAR_CLIENT]
	public static Map<String,Integer> carSupplierCount = new HashMap<String,Integer>();												//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> carSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> carClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> airselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_transactional [AIR]
	public static Map<String,Map<String, Map<String, Integer>>> airselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_settlement [AIR]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> airselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [AIR]
	public static Map<String,Integer> airselectedRowSCT = new HashMap<String,Integer>();											//this map will keep record of selectedRows supplier_commercialName:counter [AIR]
	public static Map<String, Integer> airselectedRowsCS = new HashMap<String, Integer>();											//this map will keep record of selectedRows for client_settlement [AIR]
	public static Map<String,Integer> airLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [AIR_SUPPLIER]
	public static Map<String,Integer> airClientLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [AIR_CLIENT]
	public static Map<String,Integer> airLTBCumSeq = new HashMap<String,Integer>();													//this map will keep record of supplier:cumulativeSequence [AIR_SUPPLIER]
	public static Map<String,Integer> airClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [AIR_CLIENT]
	public static Map<String,String> airSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [AIR_SUPPLIER]
	public static Map<String,String> airClientRefRuleID = new HashMap<String,String>();												//this map will keep record of supplier_market:referenceCounterRuleRowNumber [AIR_CLIENT]
	public static Map<String,Integer> airSupplierCount = new HashMap<String,Integer>();												//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> airSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> airClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> activitiesselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();		//this map will keep record of selectedRows for supplier_transactional [ACTIVITIES]
	public static Map<String,Map<String, Map<String, Integer>>> activitiesselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();			//this map will keep record of selectedRows for supplier_settlement [ACTIVITIES]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> activitiesselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [ACTIVITIES]
	public static Map<String,Integer> activitiesselectedRowSCT = new HashMap<String,Integer>();										//this map will keep record of selectedRows supplier_commercialName:counter [ACTIVITIES]
	public static Map<String, Integer> activitiesselectedRowsCS = new HashMap<String, Integer>();									//this map will keep record of selectedRows for client_settlement [ACTIVITIES]
	public static Map<String,Integer> activitiesLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [ACTIVITIES_SUPPLIER]
	public static Map<String,Integer> activitiesClientLTB = new HashMap<String,Integer>();											//this map will keep record of supplier:lowerLimit [ACTIVITIES_CLIENT]
	public static Map<String,Integer> activitiesLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [ACTIVITIES_SUPPLIER]
	public static Map<String,Integer> activitiesClientLTBCumSeq = new HashMap<String,Integer>();									//this map will keep record of supplier:cumulativeSequence [ACTIVITIES_CLIENT]
	public static Map<String,String> activitiesSupplierRefRuleID = new HashMap<String,String>();									//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACTIVITIES_SUPPLIER]
	public static Map<String,String> activitiesClientRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACTIVITIES_CLIENT]
	public static Map<String,Integer> activitiesSupplierCount = new HashMap<String,Integer>();										//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> activitiesSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> activitiesClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> accomodationselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();		//this map will keep record of selectedRows for supplier_transactional [ACCOMODATION]
	public static Map<String,Map<String, Map<String, Integer>>> accomodationselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();		//this map will keep record of selectedRows for supplier_settlement [ACCOMODATION]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> accomodationselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [ACCOMODATION]
	public static Map<String,Integer> accomodationselectedRowSCT = new HashMap<String,Integer>();									//this map will keep record of selectedRows supplier_commercialName:counter [ACCOMODATION]
	public static Map<String, Integer> accomodationselectedRowsCS = new HashMap<String, Integer>();									//this map will keep record of selectedRows for client_settlement [ACCOMODATION]
	public static Map<String,Integer> accomodationLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [ACCOMODATION_SUPPLIER]
	public static Map<String,Integer> accomodationClientLTB = new HashMap<String,Integer>();										//this map will keep record of supplier:lowerLimit [ACCOMODATION_CLIENT]
	public static Map<String,Integer> accomodationLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [ACCOMODATION_SUPPLIER]
	public static Map<String,Integer> accomodationClientLTBCumSeq = new HashMap<String,Integer>();									//this map will keep record of supplier:cumulativeSequence [ACCOMODATION_CLIENT]
	public static Map<String,String> accomodationSupplierRefRuleID = new HashMap<String,String>();									//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACCOMODATION_SUPPLIER]
	public static Map<String,String> accomodationClientRefRuleID = new HashMap<String,String>();									//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACCOMODATION_CLIENT]
	public static Map<String,Integer> accomodationSupplierCount = new HashMap<String,Integer>();									//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> accomodationSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> accomodationClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> busselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_transactional [BUS]
	public static Map<String,Map<String, Map<String, Integer>>> busselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_settlement [BUS]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> busselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [BUS]
	public static Map<String,Integer> busselectedRowSCT = new HashMap<String,Integer>();											//this map will keep record of selectedRows supplier_commercialName:counter [BUS]
	public static Map<String, Integer> busselectedRowsCS = new HashMap<String, Integer>();											//this map will keep record of selectedRows for client_settlement [BUS]
	public static Map<String,Integer> busLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [BUS_SUPPLIER]
	public static Map<String,Integer> busClientLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [BUS_CLIENT]
	public static Map<String,Integer> busLTBCumSeq = new HashMap<String,Integer>();													//this map will keep record of supplier:cumulativeSequence [BUS_SUPPLIER]
	public static Map<String,Integer> busClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [BUS_CLIENT]
	public static Map<String,String> busSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [BUS_SUPPLIER]
	public static Map<String,String> busClientRefRuleID = new HashMap<String,String>();												//this map will keep record of supplier_market:referenceCounterRuleRowNumber [BUS_CLIENT]
	public static Map<String,Integer> busSupplierCount = new HashMap<String,Integer>();												//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> busSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> busClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> railselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_transactional [RAIL]
	public static Map<String,Map<String, Map<String, Integer>>> railselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_settlement [RAIL]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> railselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [RAIL]
	public static Map<String,Integer> railselectedRowSCT = new HashMap<String,Integer>();											//this map will keep record of selectedRows supplier_commercialName:counter [RAIL]
	public static Map<String, Integer> railselectedRowsCS = new HashMap<String, Integer>();											//this map will keep record of selectedRows for client_settlement [RAIL]
	public static Map<String,Integer> railLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [RAIL_SUPPLIER]
	public static Map<String,Integer> railClientLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [RAIL_CLIENT]
	public static Map<String,Integer> railLTBCumSeq = new HashMap<String,Integer>();												//this map will keep record of supplier:cumulativeSequence [RAIL_SUPPLIER]
	public static Map<String,Integer> railClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [RAIL_CLIENT]
	public static Map<String,String> railSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [RAIL_SUPPLIER]
	public static Map<String,String> railClientRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [RAIL_CLIENT]
	public static Map<String,Integer> railSupplierCount = new HashMap<String,Integer>();											//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> railSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> railClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> cruiseselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();			//this map will keep record of selectedRows for supplier_transactional [CRUISE]
	public static Map<String,Map<String, Map<String, Integer>>> cruiseselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_settlement [CRUISE]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> cruiseselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [CRUISE]
	public static Map<String,Integer> cruiseselectedRowSCT = new HashMap<String,Integer>();											//this map will keep record of selectedRows supplier_commercialName:counter [CRUISE]
	public static Map<String, Integer> cruiseselectedRowsCS = new HashMap<String, Integer>();										//this map will keep record of selectedRows for client_settlement [CRUISE]
	public static Map<String,Integer> cruiseLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [CRUISE_SUPPLIER]
	public static Map<String,Integer> cruiseClientLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [CRUISE_CLIENT]
	public static Map<String,Integer> cruiseLTBCumSeq = new HashMap<String,Integer>();												//this map will keep record of supplier:cumulativeSequence [CRUISE_SUPPLIER]
	public static Map<String,Integer> cruiseClientLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [CRUISE_CLIENT]
	public static Map<String,String> cruiseSupplierRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CRUISE_SUPPLIER]
	public static Map<String,String> cruiseClientRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CRUISE_CLIENT]
	public static Map<String,Integer> cruiseSupplierCount = new HashMap<String,Integer>();											//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> cruiseSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> cruiseClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> insuranceselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();			//this map will keep record of selectedRows for supplier_transactional [INSURANCE]
	public static Map<String,Map<String, Map<String, Integer>>> insuranceselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();			//this map will keep record of selectedRows for supplier_settlement [INSURANCE]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> insuranceselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [INSURANCE]
	public static Map<String,Integer> insuranceselectedRowSCT = new HashMap<String,Integer>();										//this map will keep record of selectedRows supplier_commercialName:counter [INSURANCE]
	public static Map<String, Integer> insuranceselectedRowsCS = new HashMap<String, Integer>();									//this map will keep record of selectedRows for client_settlement [INSURANCE]
	public static Map<String,Integer> insuranceLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [INSURANCE_SUPPLIER]
	public static Map<String,Integer> insuranceClientLTB = new HashMap<String,Integer>();											//this map will keep record of supplier:lowerLimit [INSURANCE_CLIENT]
	public static Map<String,Integer> insuranceLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [INSURANCE_SUPPLIER]
	public static Map<String,Integer> insuranceClientLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [INSURANCE_CLIENT]
	public static Map<String,String> insuranceSupplierRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [INSURANCE_SUPPLIER]
	public static Map<String,String> insuranceClientRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [INSURANCE_CLIENT]
	public static Map<String,Integer> insuranceSupplierCount = new HashMap<String,Integer>();										//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> insuranceSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> insuranceClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> holidaysselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();			//this map will keep record of selectedRows for supplier_transactional [HOLIDAYS]
	public static Map<String,Map<String, Map<String, Integer>>> holidaysselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();			//this map will keep record of selectedRows for supplier_settlement [HOLIDAYS]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> holidaysselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [HOLIDAYS]
	public static Map<String,Integer> holidaysselectedRowSCT = new HashMap<String,Integer>();										//this map will keep record of selectedRows supplier_commercialName:counter [HOLIDAYS]
	public static Map<String, Integer> holidaysselectedRowsCS = new HashMap<String, Integer>();										//this map will keep record of selectedRows for client_settlement [HOLIDAYS]
	public static Map<String,Integer> holidaysLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [HOLIDAYS_SUPPLIER]
	public static Map<String,Integer> holidaysClientLTB = new HashMap<String,Integer>();											//this map will keep record of supplier:lowerLimit [HOLIDAYS_CLIENT]
	public static Map<String,Integer> holidaysLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [HOLIDAYS_SUPPLIER]
	public static Map<String,Integer> holidaysClientLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [HOLIDAYS_CLIENT]
	public static Map<String,String> holidaysSupplierRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [HOLIDAYS_SUPPLIER]
	public static Map<String,String> holidaysClientRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [HOLIDAYS_CLIENT]
	public static Map<String,Integer> holidaysSupplierCount = new HashMap<String,Integer>();										//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> holidaysSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> holidaysClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<String,Map<String, Map<String, Integer>>> visaselectedRowsST = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_transactional [VISA]
	public static Map<String,Map<String, Map<String, Integer>>> visaselectedRowsSS = new HashMap<String,Map<String, Map<String, Integer>>>();				//this map will keep record of selectedRows for supplier_settlement [VISA]
	public static Map<String,Map<String,Map<String,Map<String,Integer>>>> visaselectedRowCT = new HashMap<String,Map<String,Map<String,Map<String,Integer>>>>();//this map will keep record of selectedRows for client_transactional [VISA]
	public static Map<String,Integer> visaselectedRowSCT = new HashMap<String,Integer>();											//this map will keep record of selectedRows supplier_commercialName:counter [VISA]
	public static Map<String, Integer> visaselectedRowsCS = new HashMap<String, Integer>();											//this map will keep record of selectedRows for client_settlement [VISA]
	public static Map<String,Integer> visaLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [VISA_SUPPLIER]
	public static Map<String,Integer> visaClientLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [VISA_CLIENT]
	public static Map<String,Integer> visaLTBCumSeq = new HashMap<String,Integer>();												//this map will keep record of supplier:cumulativeSequence [VISA_SUPPLIER]
	public static Map<String,Integer> visaClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [VISA_CLIENT]
	public static Map<String,String> visaSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [VISA_SUPPLIER]
	public static Map<String,String> visaClientRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [VISA_CLIENT]
	public static Map<String,Integer> visaSupplierCount = new HashMap<String,Integer>();											//this map will keep record of supplier:supplierMarketCount [CAR_SUPPLIER]
	public static Map<String,Integer> visaSupplierSettlementRuleID = new HashMap<String,Integer>();
	public static Map<String,Integer> visaClientSettlementRuleID = new HashMap<String,Integer>();
	
	public static Map<Integer,String> clientTransactionalSequence = new HashMap<Integer,String>();									//this map will allow sequential iteration of DTs for client transactional
	public static Map<Integer,String> supplierTransactionalSequence = new HashMap<Integer,String>();								//this map will allow sequential iteration of DTs for supplier transactional
	static{
		supplierTransactionalSequence.put(1,"CommercialDefinitionDT");
		supplierTransactionalSequence.put(2,"StandardCommercialBaseDT");
		supplierTransactionalSequence.put(3,"StandardCommercialCalculationDT");
		supplierTransactionalSequence.put(4,"OverridingCommercialBaseDT");
		supplierTransactionalSequence.put(5,"OverridingCommercialCalculationDT");
		supplierTransactionalSequence.put(6,"PLBCommercialBaseDT");
		supplierTransactionalSequence.put(7,"PLBCommercialCalculationDT");
		supplierTransactionalSequence.put(8,"SectorWiseIncentivesCommercialBaseDT");
		supplierTransactionalSequence.put(9,"SectorWiseIncentivesCommercialCalculationDT");
		supplierTransactionalSequence.put(10,"DestinationIncentivesCommercialBaseDT");
		supplierTransactionalSequence.put(11,"DestinationIncentivesCommercialCalculationDT");
		supplierTransactionalSequence.put(12,"SegmentFeesCommercialBaseDT");
		supplierTransactionalSequence.put(13,"SegmentFeesCommercialCalculationDT");
		supplierTransactionalSequence.put(14,"ManagementFeesCommercialBaseDT");
		supplierTransactionalSequence.put(15,"ManagementFeesCommercialCalculationDT");
		supplierTransactionalSequence.put(16,"ServiceChargeCommercialBaseDT");
		supplierTransactionalSequence.put(17,"ServiceChargeCommercialCalculationDT");
		supplierTransactionalSequence.put(18,"IssuanceFeesCommercialBaseDT");
		supplierTransactionalSequence.put(19,"IssuanceFeesCommercialCalculationDT");
		supplierTransactionalSequence.put(20,"CommissionCommercialBaseDT");
		supplierTransactionalSequence.put(21,"CommissionCommercialCalculationDT");
		clientTransactionalSequence.put(1,"CommercialDefinitionDT");
		clientTransactionalSequence.put(2,"StandardClientCommercialAdvancedDT");
		clientTransactionalSequence.put(3,"StandardClientCommercialCalculationDT");
		clientTransactionalSequence.put(4,"OverridingClientCommercialAdvancedDT");
		clientTransactionalSequence.put(5,"OverridingClientCommercialCalculationDT");
		clientTransactionalSequence.put(6,"PLBClientCommercialAdvancedDT");
		clientTransactionalSequence.put(7,"PLBClientCommercialCalculationDT");
		clientTransactionalSequence.put(8,"SectorWiseIncentiveClientCommercialAdvancedDT");
		clientTransactionalSequence.put(9,"SectorWiseIncentiveClientCommercialCalculationDT");
		clientTransactionalSequence.put(10,"SegmentFeeClientCommercialAdvancedDT");
		clientTransactionalSequence.put(11,"SegmentFeeClientCommercialCalculationDT");
		clientTransactionalSequence.put(12,"ManagementFeeClientCommercialAdvancedDT");
		clientTransactionalSequence.put(13,"ManagementFeeClientCommercialCalculationDT");
		clientTransactionalSequence.put(14,"ServiceChargeClientCommercialAdvancedDT");
		clientTransactionalSequence.put(15,"ServiceChargeClientCommercialCalculationDT");
		clientTransactionalSequence.put(16,"DiscountClientCommercialAdvancedDT");
		clientTransactionalSequence.put(17,"DiscountClientCommercialCalculationDT");
		clientTransactionalSequence.put(18,"MarkUpClientCommercialAdvancedDT");
		clientTransactionalSequence.put(19,"MarkUpClientCommercialCalculationDT");
		clientTransactionalSequence.put(20,"DestinationIncentiveClientCommercialAdvancedDT");
		clientTransactionalSequence.put(21,"DestinationIncentiveClientCommercialCalculationDT");
	}
	
	public MappingConfiguration(){}
	
}
