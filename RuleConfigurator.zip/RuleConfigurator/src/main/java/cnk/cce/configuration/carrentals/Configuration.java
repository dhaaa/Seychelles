package cnk.cce.configuration.carrentals;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.json.JSONArray;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.gson.Gson;
import cnk.cce.configuration.MappingConfiguration;
import cnk.cce.maven.MavenInvoker;

public class Configuration {
	public static int flag=0,carchangeRefCount=0,carrefreshCounterRule=0,carclientRefreshCounterRule=0,carclientChangeRefCount=0,airchangeRefCount=0,airrefreshCounterRule=0,airclientRefreshCounterRule=0,airclientChangeRefCount=0,error=0,visaclientRefreshCounterRule=0,visaclientChangeRefCount=0;
	public static int activitieschangeRefCount=0,activitiesrefreshCounterRule=0,activitiesclientRefreshCounterRule=0,activitiesclientChangeRefCount=0,accomodationchangeRefCount=0,accomodationrefreshCounterRule=0,accomodationclientRefreshCounterRule=0,accomodationclientChangeRefCount=0,cruiseclientChangeRefCount=0;
	public static int buschangeRefCount=0,busrefreshCounterRule=0,busclientRefreshCounterRule=0,busclientChangeRefCount=0,railchangeRefCount=0,railrefreshCounterRule=0,railclientRefreshCounterRule=0,railclientChangeRefCount=0,cruisechangeRefCount=0,cruiserefreshCounterRule=0,cruiseclientRefreshCounterRule=0;
	public static int insurancechangeRefCount=0,insurancerefreshCounterRule=0,insuranceclientRefreshCounterRule=0,insuranceclientChangeRefCount=0,holidayschangeRefCount=0,holidaysrefreshCounterRule=0,holidaysclientRefreshCounterRule=0,holidaysclientChangeRefCount=0,visachangeRefCount=0,visarefreshCounterRule=0;

	public static String getSelectedRow(String productName, String supplier, String supplierMarket, String commercialName, String type, String commercialType, String productCategorySubType) {
		switch(productName){
		case "air": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.airselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.airSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.airselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.airSupplierCount,productCategorySubType);
		}
		case "activities": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.activitiesselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.activitiesSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.activitiesselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.activitiesSupplierCount,productCategorySubType);
		}
		case "accomodation": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.accomodationselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.accomodationSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.accomodationselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.accomodationSupplierCount,productCategorySubType);
		}
		case "bus": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.busselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.busSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.busselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.busSupplierCount,productCategorySubType);
		}
		case "rail": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.railselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.railSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.railselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.railSupplierCount,productCategorySubType);
		}
		case "cruise": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.cruiseselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.cruiseSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.cruiseselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.cruiseSupplierCount,productCategorySubType);
		}
		case "insurance": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.insuranceselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.insuranceSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.insuranceselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.insuranceSupplierCount,productCategorySubType);
		}
		case "carrentals": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.selectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.carSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.selectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.carSupplierCount,productCategorySubType);
		}
		case "holidays": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.holidaysselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.holidaysSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.holidaysselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.holidaysSupplierCount,productCategorySubType);
		}
		case "visa": {
			if(commercialType.equals("transactional"))
				return getSupplierSelectedRow(MappingConfiguration.visaselectedRowsST,null,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.visaSupplierCount,productCategorySubType);
			else return getSupplierSelectedRow(null,MappingConfiguration.visaselectedRowsSS,supplier,supplierMarket,commercialType,commercialName,type,MappingConfiguration.visaSupplierCount,productCategorySubType);
		}
		}
		return "selectedRow2";}

	
	public static String getSupplierSelectedRow(Map<String,Map<String, Map<String, Integer>>> transactionalMap, Map<String,Map<String, Map<String, Integer>>> settlementMap, String supplier, String supplierMarket, String commercialType, String commercialName, String type, Map<String,Integer> supplierCount, String productCategorySubType){
		if (transactionalMap.get(supplier) == null || transactionalMap.get(supplier).isEmpty()) {
			Map<String, Map<String, Integer>> sm = new HashMap<String, Map<String, Integer>>();
			Map<String, Integer> pcst = new HashMap<String, Integer>();
			pcst.put(productCategorySubType, 1);
			sm.put(supplierMarket, pcst);
			if(commercialType.equals("transactional")){
				transactionalMap.put(supplier, sm);
				supplierCount.put(supplier, 1);
			}else settlementMap.put(supplier,sm);
		}
		else{
			if(commercialType.equals("transactional")){
				if (type.equals("definition")) {
					if(transactionalMap.get(supplier).containsKey(supplierMarket)){
						if(!transactionalMap.get(supplier).get(supplierMarket).containsKey(productCategorySubType)){
							int count = supplierCount.get(supplier);
							transactionalMap.get(supplier).get(supplierMarket).put(productCategorySubType, count+1);
							supplierCount.put(supplier, count+1);
						}else System.out.println("ALERT: Same ProductCategorySubType Exists!");
					}else{
						int count = supplierCount.get(supplier);
						Map<String, Integer> pcst = new HashMap<String, Integer>();
						pcst.put(productCategorySubType, count+1);
						transactionalMap.get(supplier).put(supplierMarket, pcst);
						supplierCount.put(supplier, count+1);
					}
				}
				else{
					if (transactionalMap.get(supplier).get(supplierMarket).containsKey(supplier + "_" + transactionalMap.get(supplier).get(supplierMarket).get(productCategorySubType) + "_" + commercialName)) {
						if(!type.equals("calculation"))
						{
							int presentCounter = transactionalMap.get(supplier).get(supplierMarket).get(supplier + "_" + transactionalMap.get(supplier).get(supplierMarket).get(productCategorySubType) + "_" + commercialName);
							transactionalMap.get(supplier).get(supplierMarket).put(supplier + "_" + transactionalMap.get(supplier).get(supplierMarket).get(productCategorySubType) + "_" + commercialName, presentCounter+1);
						}
					}
					else
						transactionalMap.get(supplier).get(supplierMarket).put(supplier + "_" + transactionalMap.get(supplier).get(supplierMarket).get(productCategorySubType) + "_" + commercialName, 1);
				}
			}
			else{
				if(type.equals("definition")){
					if(settlementMap.get(supplier).containsKey(supplierMarket)){
						if(!settlementMap.get(supplier).get(supplierMarket).containsKey(productCategorySubType)){
							settlementMap.get(supplier).get(supplierMarket).put(productCategorySubType, settlementMap.get(supplier).size()+1);
						}else System.out.println("ALERT!: Same ProductCategorySubType exist!");
					}else{
						Map<String, Integer> pcst = new HashMap<String, Integer>();
						pcst.put(productCategorySubType, settlementMap.get(supplier).size()+1);
						settlementMap.get(supplier).put(supplierMarket, pcst);
					}
				}
			}
		}
		if(commercialType.equals("transactional")){
			return commercialName.equals("definition") ? supplier+"_"+transactionalMap.get(supplier).get(supplierMarket).get(productCategorySubType) :  supplier+"_"+transactionalMap.get(supplier).get(supplierMarket).get(productCategorySubType)+"_"+commercialName+"_"+transactionalMap.get(supplier).get(supplierMarket).get(supplier + "_" + transactionalMap.get(supplier).get(supplierMarket).get(productCategorySubType) + "_" + commercialName) ;
		}else return supplier+"_"+settlementMap.get(supplier).get(supplierMarket).get(productCategorySubType);
	} 

	
	public static void getSupplierTransactionalCommercialHead(JSONObject object, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		String commHead=""; int nettOff=0;
		if(!object.has("nettOffCommercialHeadName")){
			if(!object.has("markUpClientType")){
				if(!object.has("markDownClientApplicable"))
					commHead= '"'+object.getString("commercialHeadName").toString()+'"'+",null,"+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+",null,"+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+",null,null";
				else
					commHead= '"'+object.getString("commercialHeadName").toString()+'"'+",null,"+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+","+'"'+object.getString("markDownClientApplicable").toString()+'"'+","+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+",null,null";
			}else{
				if(!object.has("markDownClientApplicable"))
					commHead=	'"'+object.getString("commercialHeadName").toString()+'"'+",null,"+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+",null,"+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+","+'"'+object.getString("markUpClientType").toString()+'"'+",null";
				else
					commHead= '"'+object.getString("commercialHeadName").toString()+'"'+",null,"+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+","+'"'+object.getString("markDownClientApplicable").toString()+'"'+","+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+","+'"'+object.getString("markUpClientType").toString()+'"'+",null";
			}
		}
		else{
			nettOff=1;
			if(!object.has("markUpClientType")){
				if(!object.has("markDownClientApplicable"))
					commHead= '"'+object.getString("commercialHeadName").toString()+'"'+","+'"'+object.getString("nettOffCommercialHeadName").toString()+'"'+","+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+",null,"+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+",null,null";
				else
					commHead= '"'+object.getString("commercialHeadName").toString()+'"'+","+'"'+object.getString("nettOffCommercialHeadName").toString()+'"'+","+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+","+'"'+object.getString("markDownClientApplicable").toString()+'"'+","+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+",null,null";
			}else{
				if(!object.has("markDownClientApplicable"))
					commHead= '"'+object.getString("commercialHeadName").toString()+'"'+","+'"'+object.getString("nettOffCommercialHeadName").toString()+'"'+","+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+",null,"+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+","+'"'+object.getString("markUpClientType").toString()+'"'+",null";
				else
					commHead= '"'+object.getString("commercialHeadName").toString()+'"'+","+'"'+object.getString("nettOffCommercialHeadName").toString()+'"'+","+'"'+object.getString("commercialType").toString()+'"'+","+object.getBoolean("settlementTransactionWise")+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("commissionable")+","+object.getBoolean("markDownApplicable")+","+'"'+object.getString("markDownClientApplicable").toString()+'"'+","+object.getDouble("minimumMarkUpPercentage")+","+object.getDouble("maximumMarkUpPercentage")+","+'"'+object.getString("markUpClientType").toString()+'"'+",null";
			}
		}
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+object.getString("commercialHeadName")));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		cell.setCellValue(commHead);
		if(nettOff==1){
			insertIntoSheet("_"+object.getString("commercialHeadName")+"_NettOff", object.getString("nettOffCommercialHeadName").toString(), productName, entityType, commercialType, DTname, row1);
		}
	}

	
	public static void getSupplierSettlementCommercialHead(JSONObject object, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		String commHead="";
		object.keySet().size();
		if(!object.has("refundable"))
			commHead='"'+object.getString("commercialType").toString()+'"'+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("isApplicable");
		else if(!object.has("plbApplicable"))
			commHead='"'+object.getString("commercialType").toString()+'"'+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("isApplicable")+","+object.getBoolean("refundable")+","+object.getBoolean("recurring");
		else commHead='"'+object.getString("commercialType").toString()+'"'+","+'"'+object.getString("contractType").toString()+'"'+","+object.getBoolean("isApplicable")+","+object.getBoolean("plbApplicable");
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+object.getString("commercialHeadName")));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		cell.setCellValue(commHead);
	}

	
	public static void setInclusionExclusion(String IncExc, JSONArray incJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name) throws NumberFormatException, IOException {
		String value="";int columnIndex,multipleFlag=0;
		for (int i=0; i < incJsonArr.length(); i++){
			if(multipleFlag==0){
				JSONObject IndiJsonObject = (JSONObject)incJsonArr.get(i);
				if(IndiJsonObject.has("operator") || IndiJsonObject.has("to")){										//if the object contains "operator", indicates dates or travel destination 
					if(IndiJsonObject.has("value")){
						value=getOperatorString(IndiJsonObject,i,value);
						if(IncExc.equals("inclusion"))
							insertIntoSheet("_"+name,value,productName,entityType,commercialType,DTname,row1);
						else insertIntoSheet("_"+name+"_exclusion",value,productName,entityType,commercialType,DTname,row1);
					}
					else{
						if(IndiJsonObject.has("operator")){
							if(IndiJsonObject.get("to") instanceof String){											//its a string! The inputs are Date Values
								value=getOperatorString(IndiJsonObject,i,value);
								if(IncExc.equals("inclusion"))
									insertIntoSheet("_"+name,value,productName,entityType,commercialType,DTname,row1);
								else  insertIntoSheet("_"+name+"_exclusion",value,productName,entityType,commercialType,DTname,row1);
							}
						}else{
							insertRepeatingValues(IndiJsonObject.getJSONArray("to"),productName,entityType,commercialType,DTname,row1,IncExc);
							if(IndiJsonObject.has("from"))
								insertRepeatingValues(IndiJsonObject.getJSONArray("from"),productName,entityType,commercialType,DTname,row1,IncExc);
							if(IndiJsonObject.has("via"))
								insertRepeatingValues(IndiJsonObject.getJSONArray("via"),productName,entityType,commercialType,DTname,row1,IncExc);
						}
					}
				}
				else{
					if(IndiJsonObject.has("fareBasis")){															//for AIR specifically
						String fareBasisStringValue='"'+IndiJsonObject.getString("fareBasis")+'"'+","+'"'+IndiJsonObject.getString("fareBasisValue")+'"';
						if(IncExc.equals("inclusion"))
							columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareBasis"));
						else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareBasis_exclusion"));
						Cell cell=null;
						try{
							cell= row1.createCell(columnIndex);
						}catch(Exception e){
							row1.removeCell(row1.getCell(columnIndex));
							cell= row1.createCell(columnIndex);
						}
						cell.setCellValue(fareBasisStringValue);
					}else if(IndiJsonObject.has("continent")||IndiJsonObject.has("country")||IndiJsonObject.has("city")){
						airFTVInsertion(IndiJsonObject,productName,entityType,commercialType,DTname,row1,IncExc);
					}else{																							//without "to", indicates other advanced defn values with inc/exc
						Iterator<String> keys =IndiJsonObject.keys();
						while(keys.hasNext()){
							String key=keys.next();
							if(!(IndiJsonObject.get(key) instanceof List)){
								if(incJsonArr.length()>1){
									multipleFlag=1;
									insertRepeatingValues(incJsonArr,productName,entityType,commercialType,DTname,row1,IncExc);
									break;
								}else{
									if(IncExc.equals("inclusion"))
										insertIntoSheet("_"+key,IndiJsonObject.getString(key),productName,entityType,commercialType,DTname,row1);
									else insertIntoSheet("_"+key+"_exclusion",IndiJsonObject.getString(key),productName,entityType,commercialType,DTname,row1);
								}
							}
							else{																					//Input LIST hai!
								if(IndiJsonObject.has("from") || IndiJsonObject.has("via")){
									if(IndiJsonObject.has("from"))
										insertRepeatingValues(IndiJsonObject.getJSONArray("from"),productName,entityType,commercialType,DTname,row1,IncExc);
									if(IndiJsonObject.has("via"))
										insertRepeatingValues(IndiJsonObject.getJSONArray("via"),productName,entityType,commercialType,DTname,row1,IncExc);
								}else insertArrayListValues(IncExc, key, (JSONArray) IndiJsonObject.get(key), productName, row1, DTname, commercialType, entityType);
							}
						}
					}
				}
			}
		}multipleFlag=0;
	}

	
	private static void airFTVInsertion(JSONObject jsonObject, String productName, String entityType, String commercialType, String DTname, Row row1, String IncExc) {
		String journeyType = jsonObject.getString("journeyType");
		String via = null,continent;String conti = null;//,country,city
		if(jsonObject.has("continent")){
			JSONObject continentObject = jsonObject.getJSONObject("continent");
			if(continentObject.has("via")){
				JSONArray viaArr = continentObject.getJSONArray("via");
				for(int i=0;i<viaArr.length();i++){
					if(i==0)
						via = viaArr.getString(i);
					else via+="|"+viaArr.getString(i);
				}
			}
			JSONArray fromArr = continentObject.getJSONArray("from");
			JSONArray toArr = continentObject.getJSONArray("to");
			for(int i=0;i<fromArr.length();i++){
				conti = fromArr.getString(i)+";"+via;
				String cloneConti = conti;
				for(int j=0;j<toArr.length();j++){
					if((j+1)!=toArr.length()){
						if(j==0)
							conti+=";"+toArr.getString(j)+"/";
						else conti=cloneConti+";"+toArr.getString(j)+"/";

					}else conti=cloneConti+";"+toArr.getString(j);
				}
				if((i+1)!=fromArr.length())
					conti+="/";
			}
			continent=journeyType+";"+conti;
			//insertIntoSheets
			System.out.println("Final String : "+continent);
		}
		if(jsonObject.has("country")){
			
		}
		if(jsonObject.has("city")){
			
		}

	}


	private static void insertRepeatingValues(JSONArray incJsonArr, String productName, String entityType, String commercialType, String DTname, Row row1, String IncExc) throws NumberFormatException, JSONException, IOException {
		JSONObject details = new JSONObject();
		for(int i=0;i<incJsonArr.length();i++){
			JSONObject IndiJsonObject = incJsonArr.getJSONObject(i);
			Iterator<String> keys =IndiJsonObject.keys();
			while(keys.hasNext()){
				String key=keys.next();
				if(i==0){
					if(IndiJsonObject.getString(key).length()!=0){
						JSONArray value = new JSONArray();
						value.put(IndiJsonObject.getString(key));
						details.put(key, value);
					}else{
						JSONArray value = new JSONArray();
						details.put(key, value);
					}
				}else{
					if(!(IndiJsonObject.getString(key).isEmpty()) || !(IndiJsonObject.getString(key)==null)){
						if(details.getJSONArray(key).length()>0){
							for(int j=0;j<details.getJSONArray(key).length();j++){
								if(!(IndiJsonObject.getString(key).equals(details.getJSONArray(key).get(j)))){
									details.getJSONArray(key).put(IndiJsonObject.getString(key));
								}
							}
						}else{
							details.getJSONArray(key).put(IndiJsonObject.getString(key));
						}
					}
				}
			}
		}
		Iterator<String> keys =details.keys();
		while(keys.hasNext()){
			String key=keys.next();
			insertArrayListValues(IncExc,key,details.getJSONArray(key),productName,row1,DTname,commercialType,entityType);
		}
	}
	
	
	public static void setFareComponent(Map<String, Object> map, Cell cell, String productName, Row row1, String DTname, String commercialType, String entityType, String name) throws NumberFormatException, IOException {
		if(!(map.get(name).equals("Total"))){
			if(map.get(name).equals("Basic")){
				cell.setCellValue((String)map.get(name));
			}else{
				List<String> fareComponentList = Arrays.asList(((String) map.get(name)).split(","));
				if(fareComponentList.get(0).equals("Basic")){
					if(fareComponentList.size()>1){
						String fareComponent="",taxComponent="";
						for (int i = 0; i < fareComponentList.size(); i++){
							if(i==0)
								fareComponent=fareComponentList.get(i);
							else if(i==1) taxComponent=fareComponentList.get(i);
							if(i>1){
								taxComponent=taxComponent+";"+fareComponentList.get(i);
							}
						}
						cell.setCellValue((String)fareComponent);
						int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_taxComponent"));
						Cell cell1=null;
						try{
							cell1= row1.createCell(columnIndex);
						}catch(Exception e){
							row1.removeCell(row1.getCell(columnIndex));
							cell1= row1.createCell(columnIndex);
						}
						cell1.setCellValue((String)taxComponent);
					}
				}else{
					List<String> taxComponentList = Arrays.asList(((String) map.get(name)).split(","));
					String taxComponent=taxComponentList.get(0);
					if(taxComponentList.size()>1){
						for (int i = 1; i < taxComponentList.size(); i++){
							taxComponent=taxComponent+";"+taxComponentList.get(i);
						}
					}
					int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_taxComponent"));
					Cell cell1=null;
					try{
						cell1= row1.createCell(columnIndex);
					}catch(Exception e){
						row1.removeCell(row1.getCell(columnIndex));
						cell1= row1.createCell(columnIndex);
					}
					cell1.setCellValue(taxComponent);
				}
			}
		}else cell.setCellValue((String)map.get(name));
	}
	
	
	public static void setContractValidity(String name, JSONObject jsonObj, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		cell.setCellValue('"'+getOperatorString(jsonObj,0,"")+'"');
	}
	
	
	public static String getOperatorString(JSONObject jsonObj, int indicator,String value){
		if(jsonObj.getString("operator").equals("BETWEEN")){
			if(value=="" && indicator==0)
				value=jsonObj.getString("operator")+";"+jsonObj.getString("from")+";"+jsonObj.getString("to");
			else value= value+";"+jsonObj.getString("from")+";"+jsonObj.getString("to");
		}
		if(jsonObj.getString("operator").equals("IN")){
			if(value=="" && indicator==0)
				value=jsonObj.getString("operator")+"/"+jsonObj.getString("value");
			else value= value+"/"+jsonObj.getString("value");
		}
		if(!(jsonObj.getString("operator").equals("BETWEEN") || jsonObj.getString("operator").equals("IN")) && indicator==0){
			value=jsonObj.getString("operator")+";"+jsonObj.getString("value");
		}
		return value;
	}
	
	
	public static void insertArrayListValues(String incExc, String name, JSONArray entireJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		String value=""; int columnIndex;
		if(!(name.equals("supplierMarket") && entireJsonArr.getString(0).equals("All Markets"))){
			for (int j=0; j < entireJsonArr.length(); j++){
				if(j==0){
					if(incExc.equals("inclusionIOTP"))
						value=entireJsonArr.getString(j);
					else value='"'+entireJsonArr.getString(j)+'"';
				}
				else{
					if(incExc.equals("inclusionIOTP"))
						value+=";"+entireJsonArr.getString(j);
					else value+=","+'"'+entireJsonArr.getString(j)+'"';
				}
			}
			if(incExc.equals("inclusion") || incExc.equals("inclusionIOTP"))
				columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
			else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_exclusion"));
			Cell cell=null;
			try{
				cell= row1.createCell(columnIndex);
			}catch(Exception e){
				row1.removeCell(row1.getCell(columnIndex));
				cell= row1.createCell(columnIndex);
			}
			if(incExc.equals("inclusionIOTP")){
				if(name.equals("dayOfWeek") && entireJsonArr.getString(0).equals("All")){
					String dayOfWeekAll="Sunday;Monday;Tuesday;Wednesday;Thursday;Friday;Saturday";
					cell.setCellValue('"'+dayOfWeekAll+'"');
				}
				else cell.setCellValue('"'+value+'"');
			}else cell.setCellValue(value);
		}
	}
	

	public static void insertOtherFeesPercentage(JSONArray EntireJsonArr, String productName, Row row1, String DTname, String entityType, String commercialType) throws NumberFormatException, IOException {
		String commercialName="",percentage="";
		for (int j=0; j < EntireJsonArr.length(); j++){
			JSONObject PartJsonObject = (JSONObject)EntireJsonArr.get(j);
			if(j==0){
				commercialName=PartJsonObject.getString("commercialName");
				percentage=PartJsonObject.getString("commercialPercentage");
			}else{
				commercialName+=";"+PartJsonObject.getString("commercialName");
				percentage+=";"+PartJsonObject.getString("commercialPercentage");
			}
		}
		insertIntoSheet("_applicableCommercialName", commercialName, productName, entityType, commercialType, DTname, row1);
		insertIntoSheet("_applicableCommercialPercentage", percentage, productName, entityType, commercialType, DTname, row1);
	}
	
	
	public static void msfFeeInsertion(String currency, Double amount, Boolean serviceTaxApplicable, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_currency,amount"));
		int columnIndexSTA = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_serviceTaxApplicable"));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		Cell cellSTA=null;
		try{
			cellSTA= row1.createCell(columnIndexSTA);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndexSTA));
			cellSTA= row1.createCell(columnIndexSTA);
		}
		cell.setCellValue('"'+currency+'"'+","+amount);
		cellSTA.setCellValue(serviceTaxApplicable);
	}
	
	
	public static void insertSlabDetails(JSONObject SlabJSONObject, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		String slabTypeValue=""; JSONObject JSONObj = null; JSONArray JsonArr;
		if(SlabJSONObject.get("slabTypeValue") instanceof JSONArray){
			JsonArr = (JSONArray) SlabJSONObject.get("slabTypeValue");
			JSONObj = new JSONObject(JsonArr.get(0).toString());
			if(JSONObj.has("operator")){								//slabTypeValue given directly
				for (int j=0; j < JsonArr.length(); j++)
				{	slabTypeValue=getOperatorString((JSONObject) JsonArr.get(j),j,slabTypeValue);	}
			}
		} 
		else {	slabTypeValue=(String)SlabJSONObject.get("slabTypeValue");	}
		insertIntoSheet("_slabType", (String)SlabJSONObject.get("slabType"), productName, entityType, commercialType, DTname, row1);
		if(JSONObj.has("operator"))										//slabTypeValue given directly
			insertIntoSheet("_slabTypeValue",slabTypeValue,productName,entityType,commercialType,DTname,row1);
		else{															//slabTypeValue given as minimumToAchieve and maximumToAchieve with matchingSlab
			int columnIndexMTA = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_minimumToAchieve"));
			Cell cellMTA=null;
			try{
				cellMTA= row1.createCell(columnIndexMTA);
			}catch(Exception e){
				row1.removeCell(row1.getCell(columnIndexMTA));
				cellMTA= row1.createCell(columnIndexMTA);
			}
			cellMTA.setCellValue((String)JSONObj.get("minimumToAchieve"));
			int columnIndexMaxTA = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_maximumToAchieve"));
			Cell cellMaxTA=null;
			try{
				cellMaxTA= row1.createCell(columnIndexMaxTA);
			}catch(Exception e){
				row1.removeCell(row1.getCell(columnIndexMaxTA));
				cellMaxTA= row1.createCell(columnIndexMaxTA);
			}
			cellMaxTA.setCellValue((String)JSONObj.get("maximumToAchieve"));
			if(JSONObj.has("matchingSlabType")){
				insertIntoSheet("_matchingSlabType", (String)JSONObj.get("matchingSlabType"), productName, entityType, commercialType, DTname, row1);
			}
		}
	}
	
	
	public static void insertIncentiveOnTopUp(JSONObject JsonObj, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		Iterator<String> keys =JsonObj.keys();
		while(keys.hasNext()){
			String key=keys.next();
			if(key.equals("daily")){														//direct String value
				JSONObject json = new JSONObject(JsonObj.get("daily").toString());
				insertIntoSheet("_hours", json.getString("hours"), productName, entityType, commercialType, DTname, row1);
				insertIntoSheet("_minutes", json.getString("minutes"), productName, entityType, commercialType, DTname, row1);
			}
			else{
				JSONObject json = new JSONObject(JsonObj.get(key).toString());
				Iterator<String> jsonkeys =json.keys();
				while(jsonkeys.hasNext()){
					String jsonkey=jsonkeys.next();
					insertArrayListValues("inclusionIOTP", jsonkey, (JSONArray) json.getJSONArray(jsonkey), productName, row1, DTname, commercialType, entityType);
				}
			}
		}
	}
	
	
	public static void setRefreshCounterRule(String DTname, Map<String, Object> map, String supplier, String supplierMarket, String productName, String packageDir, String commercialType, String entityType, Sheet sheet, String productCategorySubType) throws NumberFormatException, IOException {
		String selectedRow="";
		Row row = sheet.createRow(sheet.getLastRowNum()+1);
		for (String name : map.keySet()){
			if(name.equals("contractValidity"))
				setContractValidity("contractValidity",new JSONObject(new Gson().toJson(map.get(name))),productName,row,DTname,commercialType,entityType);
			else if(!name.equals("lookToBook"))
				insertIntoSheet("_"+name, (String)map.get(name), productName, entityType, commercialType, DTname, row);
		}
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_refreshCounter"));
		Cell cell=null;
		try{
			cell= row.createCell(columnIndex);
		}catch(Exception e){
			row.removeCell(row.getCell(columnIndex));
			cell= row.createCell(columnIndex);
		}
		if(entityType.equals("supplier"))
			setRefreshCounterValue(productName,entityType,(String)map.get("supplier"),(String)map.get("supplierMarket"),"entityName","entityMarket",cell,"entityType");
		else setRefreshCounterValue(productName,entityType,(String)map.get("supplier"),"supplierMarket",(String)map.get("entityName"),(String)map.get("entityMarket"),cell,(String)map.get("entityType"));

		int columnIndexRCV = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_refreshCounterValue"));
		Cell cellRCV=null;
		try{
			cellRCV= row.createCell(columnIndexRCV);
		}catch(Exception e){
			row.removeCell(row.getCell(columnIndexRCV));
			cellRCV= row.createCell(columnIndexRCV);
		}
		cellRCV.setCellValue(true);
		insertIntoSheet("_priority", "-1", productName, entityType, commercialType, DTname, row);

		int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanCount"));
		for(int count=1;count<=booleanCount;count++)
		{
			int columnIndexBC=Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_"+count));
			Cell cellBC=null;
			try{
				cellBC= row.createCell(columnIndexBC);
			}catch(Exception e){
				row.removeCell(row.getCell(columnIndexBC));
				cellBC= row.createCell(columnIndexBC);
			}
			cellBC.setCellValue(true);
		}
		if(entityType.equals("supplier"))
			selectedRow = Configuration.getSelectedRow(productName,(String)map.get("supplier"),(String)map.get("supplierMarket"),(String)map.get("commercialName"),(String)map.get("type"),commercialType,productCategorySubType);
		else selectedRow = Configuration.getClientSelectedRow(productName,(String)map.get("supplier"),(String)map.get("commercialName"),(String)map.get("type"),entityType,commercialType,(String)map.get("entityName"),(String)map.get("entityMarket"),(String)map.get("entityType"));

		int columnIndexSR = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_commercialName"));
		Cell cellSR=null;
		try{
			cellSR= row.createCell(columnIndexSR);
		}catch(Exception e){
			row.removeCell(row.getCell(columnIndexSR));
			cellSR= row.createCell(columnIndexSR);
		}
		cellSR.setCellValue(selectedRow);

		if(entityType.equals("supplier"))
			supplierRefRuleID(productName,entityType,(String)map.get("supplier"),(String)map.get("supplierMarket"),"entityName","entityMarket","entityType",row);
		else supplierRefRuleID(productName,entityType,(String)map.get("supplier"),"supplierMarket",(String)map.get("entityName"),(String)map.get("entityMarket"),(String)map.get("entityType"),row);
	}
	
	
	public static void setRefreshCounterValue(String productName, String entityType, String supplier, String supplierMarket, String entityName, String entityMarket, Cell cell, String clientEntityType){
		switch(productName){
		case "air": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.airLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.airClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "activities": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.activitiesLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.activitiesClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "accomodation": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.accomodationLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.accomodationClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "bus": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.busLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.busClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "rail": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.railLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.railClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "cruise": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.cruiseLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.cruiseClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "insurance": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.insuranceLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.insuranceClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "carrentals": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.carLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.carClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "holidays": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.holidaysLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.holidaysClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		case "visa": {
			if(entityType.equals("supplier"))
				cell.setCellValue(MappingConfiguration.visaLTB.get(supplier+"_"+supplierMarket));
			else cell.setCellValue(MappingConfiguration.visaClientLTB.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier));
			break;
		}
		}

	}
		

	public static void insertLTB(JSONObject ltbjson, String supplier, String supplierMarket, String entityName, String entityMarket, String clientEntityType, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		int refcount=0;
		Iterator<String> keys =ltbjson.keys();
		while(keys.hasNext()){
			String key=keys.next();
			if(key.equals("lookRatio")){
				JSONObject jsonLR = new JSONObject(ltbjson.get(key).toString());
				refcount = Integer.parseInt(jsonLR.get("from").toString());
				setContractValidity(key,jsonLR,productName,row1,DTname,commercialType,entityType);
			}
			else insertIntoSheet("_"+key,(String)ltbjson.get(key),productName,entityType,commercialType,DTname,row1);
		}
		if(DTname.equals("LookToBookDT"))
			refreshCounter(supplier,supplierMarket,entityName,entityMarket,clientEntityType,refcount,entityType,productName);
		else cumulativeSequence(productName, supplier, supplierMarket, entityType, commercialType, DTname, entityName, entityMarket, clientEntityType, row1);
	}
	


	public static void setLookToBookRate(JSONObject ltbjson, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		String rate="";
		JSONObject lookjson = new JSONObject(ltbjson.get("lookRate").toString());
		rate=lookjson.get("amount").toString();
		JSONObject bookjson = new JSONObject(ltbjson.get("bookRate").toString());
		rate=rate+","+bookjson.get("amount").toString();
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_rate"));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		cell.setCellValue(rate);
		insertIntoSheet("_currency",lookjson.get("currency").toString(), productName, entityType, commercialType, DTname, row1);
	}
	
	
	public static void getClientTransactionalCommercialHead(JSONObject object, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		String commHead="";
		commHead='"'+object.getString("commercialHeadName")+'"'+","+'"'+object.getString("commercialType")+'"'+","+'"'+object.getString("commercialProperty")+'"'+","+object.getBoolean("advancedDefinitionApplicable");
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+object.getString("commercialHeadName")));
		Cell cellB=null;
		try{
			cellB= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cellB= row1.createCell(columnIndex);
		}
		cellB.setCellValue(commHead);
	}
	
	
	public static String getClientSelectedRow(String productName, String supplier, String commercialName, String type, String entityType, String commercialType, String entityName, String entityMarket, String clientEntityType) {
		switch(productName){
		case "air": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.airselectedRowCT,MappingConfiguration.airselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.airselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "activities": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.activitiesselectedRowCT,MappingConfiguration.activitiesselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.activitiesselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "accomodation": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.accomodationselectedRowCT,MappingConfiguration.accomodationselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.accomodationselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "bus": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.busselectedRowCT,MappingConfiguration.busselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.busselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "rail": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.railselectedRowCT,MappingConfiguration.railselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.railselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "cruise": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.cruiseselectedRowCT,MappingConfiguration.cruiseselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.cruiseselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "insurance": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.insuranceselectedRowCT,MappingConfiguration.insuranceselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.insuranceselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "carrentals": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.selectedRowCT,MappingConfiguration.selectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.selectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "holidays": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.holidaysselectedRowCT,MappingConfiguration.holidaysselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.holidaysselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		case "visa": {
			if(commercialType.equals("transactional"))
				return getClientSelectedRow(MappingConfiguration.visaselectedRowCT,MappingConfiguration.visaselectedRowSCT,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
			else return getClientSelectedRow(null,MappingConfiguration.visaselectedRowsCS,supplier,commercialType,commercialName,entityName,entityMarket,clientEntityType,type);
		}
		}
		return null;
	}
	

	public static String getClientSelectedRow(Map<String,Map<String,Map<String,Map<String,Integer>>>> map, Map<String,Integer> map2, String supplier, String commercialType, String commercialName, String entityName, String entityMarket, String clientEntityType, String type){
		if (map.get(entityName) == null || map.get(entityName).isEmpty()) {																		//entityName does not exist
			if(commercialType.equals("transactional")){
				Map<String,Integer> value1 = new HashMap<String,Integer>();
				value1.put(supplier, 1);
				Map<String,Map<String,Integer>> value = new HashMap<String,Map<String,Integer>>();
				value.put(clientEntityType, value1);
				Map<String,Map<String,Map<String,Integer>>> value2 = new HashMap<String,Map<String,Map<String,Integer>>>();
				value2.put(entityMarket,value);
				map.put(entityName, value2);
			}else{
				if(map2.isEmpty() || map2 == null){
					map2.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier, 1);
				}
			}
		}
		else{
			if(commercialType.equals("transactional")){
				if (commercialName.equals("definition")){																						//inserting new supplier in commercial definition DT
					if(map.get(entityName).containsKey(entityMarket)){																			//entityName exist, checking for existence of entityMarket
						if(map.get(entityName).get(entityMarket).containsKey(clientEntityType)){												//entityMarket exist, checking for existence of entityType
							if(map.get(entityName).get(entityMarket).get(clientEntityType).containsKey(supplier)){								//entityType exist, checking for existence of supplier
								error=1;
								System.out.println("ALERT: Duplicate entry in Commercial Definition DT!");
							}else{
								map.get(entityName).get(entityMarket).get(clientEntityType).put(supplier, 1);
							}
						}else {
							Map<String,Integer> value= new HashMap<String,Integer>();
							value.put(supplier, 1);
							map.get(entityName).get(entityMarket).put(clientEntityType,value);
						}
					}else{
						Map<String,Integer> value1 = new HashMap<String,Integer>();
						value1.put(supplier, 1);
						Map<String,Map<String,Integer>> value = new HashMap<String,Map<String,Integer>>();
						value.put(clientEntityType, value1);
						map.get(entityName).put(entityMarket, value);
					}
				}
				else{																															//selected row exist! (advanced | calculation DT)
					if (!map.get(entityName).get(entityMarket).get(clientEntityType).containsKey(supplier)){
						error=1;
						System.out.println("ERROR: Direct entry in Advanced | Calculation DT, NOT ALLOWED!");									//indicates there is no entry in commercial definition
					}else if(map2.containsKey(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+commercialName)){
						if(!type.equals("calculation")){
							int counter=map2.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+commercialName);
							map2.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+commercialName, counter+1);
						}
					}else{
						map2.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+commercialName, 1);
					}
				}
			}
			else{																																//settlement
				if (commercialName.equals("definition")){
					if(!map2.containsKey(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier)){
						map2.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier, 1);
					}else System.out.println("ALERT: Duplicate entry in Commercial Definition DT!");
				}else{
					if(!map2.containsKey(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier))
						error=1;
					else{
						int count = map2.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier);
						map2.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier, count+1);
					}
				}
			}
		}

		if(commercialType.equals("transactional") && error==0)
			return commercialName.equals("definition") ? entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier : entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+commercialName+"_"+map2.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+commercialName);
		if(commercialType.equals("settlement") && error==0)
			return entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier;
		else {error=0; return "ERROR: No entry in CommercialDefinitionDT";}
	}
	
	
	public static void insertFOC(JSONObject focJSONObject, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		if(focJSONObject.has("every")){															//FOC Every
			if(focJSONObject.has("focUpgrades")){												//FOC Every_Upgrades
				int columnIndexB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_4"));
				Cell cellB=null;
				try{
					cellB= row1.createCell(columnIndexB);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndexB));
					cellB= row1.createCell(columnIndexB);
				}
				cellB.setCellValue(true);
				JSONObject jsonUpgrades = new JSONObject(focJSONObject.get("focUpgrades").toString());
				Iterator<String> keys =jsonUpgrades.keys();
				while(keys.hasNext()){
					String key=keys.next();
					insertIntoSheet("_focUpgrades_"+key, (String)jsonUpgrades.get(key), productName, entityType, commercialType, DTname, row1);
				}
				JSONObject jsonEvery = new JSONObject(focJSONObject.get("every").toString());
				if(jsonEvery.get("type").equals("numberOfRooms")){
					insertIntoSheet("_focUpgrades_everynumberOfRooms", (String)jsonEvery.get("every"), productName, entityType, commercialType, DTname, row1);
				}else if(jsonEvery.get("type").equals("numberOfPassengers")){
					insertIntoSheet("_focUpgrades_everynumberOfPassengers", (String)jsonEvery.get("every"), productName, entityType, commercialType, DTname, row1);
				}else if(jsonEvery.get("type").equals("numberOfTickets")){
					insertIntoSheet("_focUpgrades_everynumberOfTickets", (String)jsonEvery.get("every"), productName, entityType, commercialType, DTname, row1);
				}
				//if type is other than numberOfRooms,numberOfPassengers or numberOfTickets, ADD HERE
			}else if(focJSONObject.has("focRooms")){											//FOC Every_Rooms
				int columnIndexB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_3"));
				Cell cellB=null;
				try{
					cellB= row1.createCell(columnIndexB);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndexB));
					cellB= row1.createCell(columnIndexB);
				}
				cellB.setCellValue(true);
				JSONObject jsonUpgrades = new JSONObject(focJSONObject.get("focRooms").toString());
				Iterator<String> keys =jsonUpgrades.keys();
				while(keys.hasNext()){
					String key=keys.next();
					insertIntoSheet("_focRooms_"+key, (String)jsonUpgrades.get(key), productName, entityType, commercialType, DTname, row1);
				}
				JSONObject jsonEvery = new JSONObject(focJSONObject.get("every").toString());
				if(jsonEvery.get("type").equals("numberOfRooms")){
					insertIntoSheet("_focRooms_everynumberOfRooms", (String)jsonEvery.get("every"), productName, entityType, commercialType, DTname, row1);
				}else if(jsonEvery.get("type").equals("numberOfPassengers")){
					insertIntoSheet("_focRooms_everynumberOfPassengers", (String)jsonEvery.get("every"), productName, entityType, commercialType, DTname, row1);
				}
				//if type is other than numberOfRooms or numberOfPassengers, ADD HERE
			}else if(focJSONObject.has("focTickets")){											//FOC Every_Tickets
				int columnIndexB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_3"));
				Cell cellB=null;
				try{
					cellB= row1.createCell(columnIndexB);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndexB));
					cellB= row1.createCell(columnIndexB);
				}
				cellB.setCellValue(true);
				JSONObject jsonUpgrades = new JSONObject(focJSONObject.get("focTickets").toString());
				Iterator<String> keys =jsonUpgrades.keys();
				while(keys.hasNext()){
					String key=keys.next();
					insertIntoSheet("_focTickets_"+key, (String)jsonUpgrades.get(key), productName, entityType, commercialType, DTname, row1);
				}
				JSONObject jsonEvery = new JSONObject(focJSONObject.get("every").toString());
				if(jsonEvery.get("type").equals("numberOfPassengers")){
					insertIntoSheet("_focTickets_everynumberOfPassengers", (String)jsonEvery.get("every"), productName, entityType, commercialType, DTname, row1);
				}else if(jsonEvery.get("type").equals("numberOfTickets")){
					insertIntoSheet("_focTickets_everynumberOfTickets", (String)jsonEvery.get("every"), productName, entityType, commercialType, DTname, row1);
				}
				//if type is other than numberOfTickets or numberOfPassengers, ADD HERE
			}
			//other boolean values
			int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanCount"));
			for(int count=1;count<=booleanCount;count++)
			{
				if(count<3 || count>4){
					int columnIndex=Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_"+count));
					Cell cell=null;
					try{
						cell= row1.createCell(columnIndex);
					}catch(Exception e){
						row1.removeCell(row1.getCell(columnIndex));
						cell= row1.createCell(columnIndex);
					}
					cell.setCellValue(false);
					if(count==5)
						cell.setCellValue(true);
				}
			}
		}else{																					//FOC Slab
			JSONObject jsonEvery = new JSONObject(focJSONObject.get("slab").toString());
			insertSlabDetails(jsonEvery, productName, row1, DTname, commercialType, entityType);
			if(focJSONObject.has("focUpgrades")){												//FOC Slab_Upgrades
				int columnIndexB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_3"));
				Cell cellB=null;
				try{
					cellB= row1.createCell(columnIndexB);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndexB));
					cellB= row1.createCell(columnIndexB);
				}
				cellB.setCellValue(true);
				JSONObject jsonUpgrades = new JSONObject(focJSONObject.get("focUpgrades").toString());
				Iterator<String> keys =jsonUpgrades.keys();
				while(keys.hasNext()){
					String key=keys.next();
					insertIntoSheet("_focUpgrades_"+key, (String)jsonUpgrades.get(key), productName, entityType, commercialType, DTname, row1);
				}
			}else if(focJSONObject.has("focRooms")){											//FOC Slab_Rooms
				int columnIndexB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_2"));
				Cell cellB=null;
				try{
					cellB= row1.createCell(columnIndexB);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndexB));
					cellB= row1.createCell(columnIndexB);
				}
				cellB.setCellValue(true);
				JSONObject jsonUpgrades = new JSONObject(focJSONObject.get("focRooms").toString());
				Iterator<String> keys =jsonUpgrades.keys();
				while(keys.hasNext()){
					String key=keys.next();
					insertIntoSheet("_focRooms_"+key, (String)jsonUpgrades.get(key), productName, entityType, commercialType, DTname, row1);
				}
			}else if(focJSONObject.has("focTickets")){											//FOC Slab_Tickets
				int columnIndexB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_2"));
				Cell cellB=null;
				try{
					cellB= row1.createCell(columnIndexB);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndexB));
					cellB= row1.createCell(columnIndexB);
				}
				cellB.setCellValue(true);
				JSONObject jsonUpgrades = new JSONObject(focJSONObject.get("focTickets").toString());
				Iterator<String> keys =jsonUpgrades.keys();
				while(keys.hasNext()){
					String key=keys.next();
					insertIntoSheet("_focTickets_"+key, (String)jsonUpgrades.get(key), productName, entityType, commercialType, DTname, row1);
				}
			}
			//other boolean values
			int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanCount"));
			for(int count=1;count<=booleanCount;count++)
			{
				if(count<2 || count>3){
					int columnIndex=Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_booleanValue_"+count));
					Cell cell=null;
					try{
						cell= row1.createCell(columnIndex);
					}catch(Exception e){
						row1.removeCell(row1.getCell(columnIndex));
						cell= row1.createCell(columnIndex);
					}
					if(count==1)
						cell.setCellValue(false);
					else cell.setCellValue(true);
				}
			}
		}
		JSONObject jsonUtilise = new JSONObject(focJSONObject.get("focUtilisation").toString());//FOC Utilisation
		Iterator<String> keys =jsonUtilise.keys();
		while(keys.hasNext()){
			String key=keys.next();
			insertIntoSheet("_focUtilisation_"+key, (String)jsonUtilise.get(key), productName, entityType, commercialType, DTname, row1);
		}
	}
	
	
	public static void insertIntoSheet(String name, String value, String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException{
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+name));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		try{
			double value1=Double.parseDouble(value);
			cell.setCellValue(value1);
		}catch(Exception e){
			cell.setCellValue('"'+value+'"');
		}
		/*if(row1.getCell(columnIndex) != null){
			try{
				double value1=Double.parseDouble(value);
				Cell cell = row1.createCell(columnIndex);
				cell.setCellType(CellType.NUMERIC);
				cell.setCellValue(value1);
			}catch(Exception e){
				Cell cell = row1.createCell(columnIndex);
				cell.setCellType(CellType.STRING);
				cell.setCellValue('"'+value+'"');
			}
			
		}*/
		
	}
	
	
	public static void cumulativeSequence(String productName, String supplier, String supplierMarket, String entityType, String commercialType, String DTname, String entityname, String entityMarket, String clientEntityType, Row row1) throws NumberFormatException, IOException{
		switch(productName){
		case "air": {checkCumulativeSequence(MappingConfiguration.airLTBCumSeq,MappingConfiguration.airClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "activities": {checkCumulativeSequence(MappingConfiguration.activitiesLTBCumSeq,MappingConfiguration.activitiesClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "accomodation": {checkCumulativeSequence(MappingConfiguration.accomodationLTBCumSeq,MappingConfiguration.accomodationClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "bus": {checkCumulativeSequence(MappingConfiguration.busLTBCumSeq,MappingConfiguration.busClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "rail": {checkCumulativeSequence(MappingConfiguration.railLTBCumSeq,MappingConfiguration.railClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "cruise": {checkCumulativeSequence(MappingConfiguration.cruiseLTBCumSeq,MappingConfiguration.cruiseClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "insurance": {checkCumulativeSequence(MappingConfiguration.insuranceLTBCumSeq,MappingConfiguration.insuranceClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "carrentals": {checkCumulativeSequence(MappingConfiguration.carLTBCumSeq,MappingConfiguration.carClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "holidays": {checkCumulativeSequence(MappingConfiguration.holidaysLTBCumSeq,MappingConfiguration.holidaysClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		case "visa": {checkCumulativeSequence(MappingConfiguration.visaLTBCumSeq,MappingConfiguration.visaClientLTBCumSeq,supplier,supplierMarket,entityname,entityMarket,clientEntityType,productName,entityType,commercialType,DTname,row1); break;}
		}
	}
	
	
	public static void checkCumulativeSequence(Map<String,Integer> ltbCumSeq, Map<String,Integer> clientLtbCumSeq, String supplier, String supplierMarket, String entityname, String entityMarket, String clientEntityType, String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException{
		if(entityType.equals("supplier")){				//for SUPPLIER
			if(ltbCumSeq.isEmpty() || ltbCumSeq == null){
				ltbCumSeq.put(supplier+"_"+supplierMarket,0);	
			}else{
				if(ltbCumSeq.containsKey(supplier+"_"+supplierMarket)){
					ltbCumSeq.put(supplier+"_"+supplierMarket,ltbCumSeq.get(supplier+"_"+supplierMarket)+1);
				}
				else{
					ltbCumSeq.put(supplier+"_"+supplierMarket,0);
				}	
			}
			insertIntoSheet("_cumulativeSequence",ltbCumSeq.get(supplier+"_"+supplierMarket).toString(), productName, entityType, commercialType, DTname, row1);
		}else{											//for CLIENT
			if(clientLtbCumSeq.isEmpty() || clientLtbCumSeq == null){
				clientLtbCumSeq.put(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier,0);	
			}else{
				if(clientLtbCumSeq.containsKey(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier)){
					clientLtbCumSeq.put(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier,clientLtbCumSeq.get(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier)+1);
				}
				else{
					clientLtbCumSeq.put(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier,0);
				}	
			}
			insertIntoSheet("_cumulativeSequence", clientLtbCumSeq.get(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier).toString(), productName, entityType, commercialType, DTname, row1);
		}
	}
	
	
	public static void supplierRefRuleID(String productName, String entityType, String supplier, String supplierMarket, String entityname, String entityMarket, String clientEntityType, Row row){
		switch(productName){
		case "air": {setSupplierRefRuleID(MappingConfiguration.airSupplierRefRuleID, MappingConfiguration.airClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "activities": {setSupplierRefRuleID(MappingConfiguration.activitiesSupplierRefRuleID, MappingConfiguration.activitiesClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "accomodation": {setSupplierRefRuleID(MappingConfiguration.accomodationSupplierRefRuleID, MappingConfiguration.accomodationClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "bus": {setSupplierRefRuleID(MappingConfiguration.busSupplierRefRuleID, MappingConfiguration.busClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "rail": {setSupplierRefRuleID(MappingConfiguration.railSupplierRefRuleID, MappingConfiguration.railClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "cruise": {setSupplierRefRuleID(MappingConfiguration.cruiseSupplierRefRuleID, MappingConfiguration.cruiseClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "insurance": {setSupplierRefRuleID(MappingConfiguration.insuranceSupplierRefRuleID, MappingConfiguration.insuranceClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "carrentals": {setSupplierRefRuleID(MappingConfiguration.carSupplierRefRuleID, MappingConfiguration.carClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "holidays": {setSupplierRefRuleID(MappingConfiguration.holidaysSupplierRefRuleID, MappingConfiguration.holidaysClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		case "visa": {setSupplierRefRuleID(MappingConfiguration.visaSupplierRefRuleID, MappingConfiguration.visaClientRefRuleID,supplier,supplierMarket,entityname,entityMarket,clientEntityType,entityType,row); break;}
		}
	}
	
	
	public static void setSupplierRefRuleID(Map<String,String> suppMap, Map<String,String> clMap, String supplier, String supplierMarket, String entityname, String entityMarket, String clientEntityType, String entityType, Row row){
		if(entityType.equals("supplier"))
			suppMap.put(supplier+"_"+supplierMarket, supplier+"_"+row.getRowNum());
		else clMap.put(entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier, entityname+"_"+entityMarket+"_"+clientEntityType+"_"+supplier+"_"+row.getRowNum());
	}
	
	
	public static void refreshCounter(String supplier, String supplierMarket, String entityName, String entityMarket, String clientEntityType, int refcount, String entityType, String productName){
		switch(productName){
		case "air": {refreshCounter(MappingConfiguration.airLTB,MappingConfiguration.airClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "activities": {refreshCounter(MappingConfiguration.activitiesLTB,MappingConfiguration.activitiesClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "accomodation": {refreshCounter(MappingConfiguration.accomodationLTB,MappingConfiguration.accomodationClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "bus": {refreshCounter(MappingConfiguration.busLTB,MappingConfiguration.busClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "rail": {refreshCounter(MappingConfiguration.railLTB,MappingConfiguration.railClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "cruise": {refreshCounter(MappingConfiguration.cruiseLTB,MappingConfiguration.cruiseClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "insurance": {refreshCounter(MappingConfiguration.insuranceLTB,MappingConfiguration.insuranceClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "carrentals": {refreshCounter(MappingConfiguration.carLTB,MappingConfiguration.carClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "holidays": {refreshCounter(MappingConfiguration.holidaysLTB,MappingConfiguration.holidaysClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		case "visa": {refreshCounter(MappingConfiguration.visaLTB,MappingConfiguration.visaClientLTB,supplier,supplierMarket,entityName,entityMarket,clientEntityType,entityType,refcount,productName); break;}
		}
	}
	
	
	public static void refreshCounter(Map<String,Integer> mapSupp, Map<String,Integer> mapClient, String supplier, String supplierMarket, String entityName, String entityMarket, String clientEntityType, String entityType, int refcount, String productName){
		if(entityType.equals("supplier")){																											//for SUPPLIER
			if(mapSupp == null || mapSupp.isEmpty()){
				mapSupp.put(supplier+"_"+supplierMarket,refcount);
				setSupplierRefreshCounter(productName);																								//insert refresh counter RULE
			}else if(mapSupp.containsKey(supplier+"_"+supplierMarket)){
				if(refcount<mapSupp.get(supplier+"_"+supplierMarket)){
					setSupplierChangeRefreshCounter(productName);																					//call UPDATE Function
					mapSupp.put(supplier+"_"+supplierMarket,refcount);
				}
			}else {
				setSupplierRefreshCounter(productName);
				mapSupp.put(supplier+"_"+supplierMarket,refcount);
			}
		}else{																																		//for CLIENT
			if(mapClient == null || mapClient.isEmpty()){
				mapClient.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier,refcount);
				setClientRefreshCounter(productName);																								//insert refresh counter RULE
			}else if(mapClient.containsKey(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier)){
				if(refcount<mapClient.get(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier)){
					setClientChangeRefreshCounter(productName);																						//call UPDATE Function
					mapClient.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier,refcount);
				}
			} else {
				setClientRefreshCounter(productName);
				mapClient.put(entityName+"_"+entityMarket+"_"+clientEntityType+"_"+supplier,refcount);
			}
		}
	}
	
	
	public static void setSupplierRefreshCounter(String productName){
		switch(productName){
		case "air": {airrefreshCounterRule=1; break;}
		case "activities": {activitiesrefreshCounterRule=1; break;}
		case "accomodation": {accomodationrefreshCounterRule=1; break;}
		case "bus": {busrefreshCounterRule=1; break;}
		case "rail": {railrefreshCounterRule=1; break;}
		case "cruise": {cruiserefreshCounterRule=1; break;}
		case "insurance": {insurancerefreshCounterRule=1; break;}
		case "carrentals": {carrefreshCounterRule=1; break;}
		case "holidays": {holidaysrefreshCounterRule=1; break;}
		case "visa": {visarefreshCounterRule=1; break;}
		}
	}
	
	
	public static void setClientRefreshCounter(String productName){
		switch(productName){
		case "air": {airclientRefreshCounterRule=1; break;}
		case "activities": {activitiesclientRefreshCounterRule=1; break;}
		case "accomodation": {accomodationclientRefreshCounterRule=1; break;}
		case "bus": {busclientRefreshCounterRule=1; break;}
		case "rail": {railclientRefreshCounterRule=1; break;}
		case "cruise": {cruiseclientRefreshCounterRule=1; break;}
		case "insurance": {insuranceclientRefreshCounterRule=1; break;}
		case "carrentals": {carclientRefreshCounterRule=1; break;}
		case "holidays": {holidaysclientRefreshCounterRule=1; break;}
		case "visa": {visaclientRefreshCounterRule=1; break;}
		}
	}
	
	
	public static void setSupplierChangeRefreshCounter(String productName){
		switch(productName){
		case "air": {airchangeRefCount=1; break;}
		case "activities": {activitieschangeRefCount=1; break;}
		case "accomodation": {accomodationchangeRefCount=1; break;}
		case "bus": {buschangeRefCount=1; break;}
		case "rail": {railchangeRefCount=1; break;}
		case "cruise": {cruisechangeRefCount=1; break;}
		case "insurance": {insurancechangeRefCount=1; break;}
		case "carrentals": {carchangeRefCount=1; break;}
		case "holidays": {holidayschangeRefCount=1; break;}
		case "visa": {visachangeRefCount=1; break;}
		}
	}
	
	
	public static void setClientChangeRefreshCounter(String productName){
		switch(productName){
		case "air": {airclientChangeRefCount=1; break;}
		case "activities": {activitiesclientChangeRefCount=1; break;}
		case "accomodation": {accomodationclientChangeRefCount=1; break;}
		case "bus": {busclientChangeRefCount=1; break;}
		case "rail": {railclientChangeRefCount=1; break;}
		case "cruise": {cruiseclientChangeRefCount=1; break;}
		case "insurance": {insuranceclientChangeRefCount=1; break;}
		case "carrentals": {carclientChangeRefCount=1; break;}
		case "holidays": {holidaysclientChangeRefCount=1; break;}
		case "visa": {visaclientChangeRefCount=1; break;}
		}
	}
	
	
	public static void updateFareComponent(Map<String, Object> map, String name, String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException {
		if(!(map.get(name).equals("Total"))){
			if(map.get(name).equals("Basic")){
				int columnIndextc = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_taxComponent"));
				Cell celltc = row1.getCell(columnIndextc);
				if(celltc != null){
					row1.removeCell(celltc);
				}
				int columnIndexf = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareComponent"));
				Cell cell=null;
				try{
					cell= row1.createCell(columnIndexf);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndexf));
					cell= row1.createCell(columnIndexf);
				}
				cell.setCellValue((String)map.get(name));
			}else{
				List<String> fareComponentList = Arrays.asList(((String) map.get(name)).split(","));
				if(fareComponentList.get(0).equals("Basic")){
					if(fareComponentList.size()>1){
						String fareComponent="",taxComponent="";
						for (int i = 0; i < fareComponentList.size(); i++){
							switch(i){
							case 0: fareComponent=fareComponentList.get(i); break;
							case 1: taxComponent=fareComponentList.get(i); break;
							default: taxComponent=taxComponent+";"+fareComponentList.get(i);
							}
						}
						int columnIndexf = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareComponent"));
						Cell cell=null;
						try{
							cell= row1.createCell(columnIndexf);
						}catch(Exception e){
							row1.removeCell(row1.getCell(columnIndexf));
							cell= row1.createCell(columnIndexf);
						}
						cell.setCellValue((String)fareComponent);
						int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_taxComponent"));
						Cell cell1=null;
						try{
							cell1= row1.createCell(columnIndex);
						}catch(Exception e){
							row1.removeCell(row1.getCell(columnIndex));
							cell1= row1.createCell(columnIndex);
						}
						cell1.setCellValue((String)taxComponent);
					}
					else {
						int columnIndexf = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareComponent"));
						Cell cell=null;
						try{
							cell= row1.createCell(columnIndexf);
						}catch(Exception e){
							row1.removeCell(row1.getCell(columnIndexf));
							cell= row1.createCell(columnIndexf);
						}
						cell.setCellValue((String)map.get(name));
					}
				}else{											//only tax components
					int columnIndexf = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareComponent"));
					Cell cell=null;
					try{
						cell= row1.createCell(columnIndexf);
					}catch(Exception e){
						row1.removeCell(row1.getCell(columnIndexf));
						cell= row1.createCell(columnIndexf);
					}
					row1.removeCell(cell);
					List<String> taxComponentList = Arrays.asList(((String) map.get(name)).split(","));
					String taxComponent=taxComponentList.get(0);
					if(taxComponentList.size()>1){
						for (int i = 1; i < taxComponentList.size(); i++){
							taxComponent=taxComponent+";"+taxComponentList.get(i);
						}
					}
					int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_taxComponent"));
					Cell cell1=null;
					try{
						cell1= row1.createCell(columnIndex);
					}catch(Exception e){
						row1.removeCell(row1.getCell(columnIndex));
						cell1= row1.createCell(columnIndex);
					}
					cell1.setCellValue(taxComponent);
				}
			}
		}else{
			int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareComponent"));
			Cell cell1=null;
			try{
				cell1= row1.createCell(columnIndex);
			}catch(Exception e){
				if(row1.getCell(columnIndex)!=null)
					row1.removeCell(row1.getCell(columnIndex));
				cell1= row1.createCell(columnIndex);
			}
			if(cell1!=null)
				row1.removeCell(cell1);
			cell1.setCellValue("Total");
			int columnIndextc = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_taxComponent"));
			if(row1.getCell(columnIndextc)!=null)
				row1.removeCell(row1.getCell(columnIndextc));
		}
	}
	
	
	public static void setTriggerPayout(JSONArray trigPayJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name) throws NumberFormatException, IOException {
		Boolean trigger = null,payout = null;
		for(int i=0;i<trigPayJsonArr.length();i++){
			JSONObject json = new JSONObject(trigPayJsonArr.get(i).toString());
			if(i==0){
				trigger = json.getBoolean("trigger");
				payout = json.getBoolean("payout");
			}else{
				if(json.has("inclusion")){
					JSONArray IncJsonArr = json.getJSONArray("inclusion");
					Configuration.setTriggerPayoutInclusionExclusion("inclusion",IncJsonArr,productName,row1,DTname,commercialType,entityType,name,trigger,payout);
				}else if(json.has("exclusion")){
					JSONArray IncJsonArr = json.getJSONArray("exclusion");
					Configuration.setTriggerPayoutInclusionExclusion("exclusion",IncJsonArr,productName,row1,DTname,commercialType,entityType,name,trigger,payout);
				}else{																																				//other advDef values
					Iterator<String> keys =json.keys();
					while(keys.hasNext()){
						String key=keys.next();
						if(json.get(key) instanceof String){
							int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
							Cell cell1=null;
							try{
								cell1= row1.createCell(columnIndex);
							}catch(Exception e){
								row1.removeCell(row1.getCell(columnIndex));
								cell1= row1.createCell(columnIndex);
							}
							cell1.setCellValue('"'+(String)json.get(key)+'"'+","+trigger+","+payout);
						}
						else{																																		//IndiJsonObject.get(key) LIST hai!
							if(productName.equals("accomodation") && commercialType.equals("transactional") && (name.equals("passengerType") || name.equals("rateType") || name.equals("rateCode")))			//for ACCOMODATION only
								insertTriggerPayoutArrayListValues("inclusion",(JSONArray) json.get(key),productName,row1,DTname,commercialType,entityType,key,trigger,payout);
							else insertTriggerPayoutArrayListValues("inclusion", (JSONArray) json.get(key), productName, row1, DTname, commercialType, entityType,key,trigger,payout);
						}
					}
				}
			}
		}
	}
	

	private static void insertTriggerPayoutArrayListValues(String incExc,JSONArray entireJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name, boolean trigger, boolean payout) throws NumberFormatException, IOException {
		String value=""; int columnIndex;
		for (int j=0; j < entireJsonArr.length(); j++){
			if(j==0)
				value=(String) entireJsonArr.get(j).toString();
			else value+=";"+(String) entireJsonArr.get(j).toString();
		}
		if(incExc.equals("inclusion"))
			columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
		else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_exclusion"));
		Cell cell1=null;
		try{
			cell1= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell1= row1.createCell(columnIndex);
		}
		cell1.setCellValue('"'+value+'"'+","+trigger+","+payout);
	}
	

	private static void setTriggerPayoutInclusionExclusion(String IncExc, JSONArray incJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name, boolean trigger, boolean payout) throws NumberFormatException, IOException {
		String value="";int columnIndex;
		for (int i=0; i < incJsonArr.length(); i++){
			JSONObject IndiJsonObject = (JSONObject)incJsonArr.get(i);
			if(IndiJsonObject.has("operator") || IndiJsonObject.has("to"))																							//if the object contains "operator", indicates dates or travel destination 
			{
				if(IndiJsonObject.has("value")){
					value=getOperatorString(IndiJsonObject,i,value);
					if(IncExc.equals("inclusion"))
						columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
					else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_exclusion"));
					Cell cell1=null;
					try{
						cell1= row1.createCell(columnIndex);
					}catch(Exception e){
						row1.removeCell(row1.getCell(columnIndex));
						cell1= row1.createCell(columnIndex);
					}
					cell1.setCellValue('"'+value+'"'+","+trigger+","+payout);
				}
				else
				{
					if(!(IndiJsonObject.get("to") instanceof JSONObject)){																							//if it's not a JSONObject, then its a List! The inputs are Date Values
						value=getOperatorString(IndiJsonObject,i,value);
						if(IncExc.equals("inclusion"))
							columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
						else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_exclusion"));
						Cell cell1=null;
						try{
							cell1= row1.createCell(columnIndex);
						}catch(Exception e){
							row1.removeCell(row1.getCell(columnIndex));
							cell1= row1.createCell(columnIndex);
						}
						cell1.setCellValue('"'+value+'"'+","+trigger+","+payout);
					}
					else{																																			//It's a normal JSONObject
						Iterator<String> keys =IndiJsonObject.keys();
						while(keys.hasNext()){
							String key=keys.next();
							if(key.equals("to")||key.equals("via")||key.equals("from")){																			//values insertion for to,via,from
								JSONObject ToJsonObject = IndiJsonObject.getJSONObject(key);
								insertTriggerPayoutFTVValues(IncExc,key,ToJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
							}
							else
							{																																		//values insertion other than to,via,from in same JSONObject
								if(IncExc.equals("inclusion"))
									columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
								else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+"_exclusion"));
								Cell cell1=null;
								try{
									cell1= row1.createCell(columnIndex);
								}catch(Exception e){
									row1.removeCell(row1.getCell(columnIndex));
									cell1= row1.createCell(columnIndex);
								}
								cell1.setCellValue('"'+(String)IndiJsonObject.get(key)+'"'+","+trigger+","+payout);
							}
						}
					}
				}
			}
			else{
				if(IndiJsonObject.has("fareBasis")){																												//for AIR specifically
					String fareBasisStringValue='"'+IndiJsonObject.getString("fareBasis")+'"'+","+'"'+IndiJsonObject.getString("fareBasisValue")+'"';
					if(IncExc.equals("inclusion"))
						columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareBasis"));
					else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_fareBasis_exclusion"));
					Cell cell1=null;
					try{
						cell1= row1.createCell(columnIndex);
					}catch(Exception e){
						row1.removeCell(row1.getCell(columnIndex));
						cell1= row1.createCell(columnIndex);
					}
					cell1.setCellValue(fareBasisStringValue+","+trigger+","+payout);
				}else{																																				//without "to", indicates other advanced defn values with inc/exc
					Iterator<String> keys =IndiJsonObject.keys();
					while(keys.hasNext()){
						String key=keys.next();
						if(IndiJsonObject.get(key) instanceof String){
							if(IncExc.equals("inclusion"))
								columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
							else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+"_exclusion"));
							Cell cell1=null;
							try{
								cell1= row1.createCell(columnIndex);
							}catch(Exception e){
								row1.removeCell(row1.getCell(columnIndex));
								cell1= row1.createCell(columnIndex);
							}
							cell1.setCellValue('"'+(String)IndiJsonObject.get(key)+'"'+","+trigger+","+payout);
						}
						else{																																		//IndiJsonObject.get(key) LIST hai!
							if(productName.equals("accomodation") && commercialType.equals("transactional") && (name.equals("passengerType") || name.equals("rateType") || name.equals("rateCode")))			//for ACCOMODATION only
								insertTriggerPayoutArrayListValues("inclusion",(JSONArray) IndiJsonObject.get(key),productName,row1,DTname,commercialType,entityType,key,trigger,payout);
							else insertTriggerPayoutArrayListValues(IncExc, (JSONArray) IndiJsonObject.get(key), productName, row1, DTname, commercialType, entityType,key,trigger,payout);
						}
					}
				}
			}
		}

	}
	
	
	private static void insertTriggerPayoutFTVValues(String IncExc, String key, JSONObject toJsonObject, Row row1, String DTname, String commercialType, String entityType, String productName, boolean trigger, boolean payout) throws NumberFormatException, IOException {
		if(toJsonObject.has("continent"))
			TriggerPayoutftvInsertion("continent",IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
		if(toJsonObject.has("country"))
			TriggerPayoutftvInsertion("country",IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
		if(toJsonObject.has("state"))
			TriggerPayoutftvInsertion("state",IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
		if(toJsonObject.has("city"))
			TriggerPayoutftvInsertion("city",IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
	}
	
	
	private static void TriggerPayoutftvInsertion(String value, String IncExc, String key, JSONObject toJsonObject, Row row1, String DTname, String commercialType, String entityType, String productName, boolean trigger, boolean payout) throws NumberFormatException, IOException {
		int columnIndex;
		if(IncExc.equals("inclusion"))
			columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+value));
		else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+value+"_exclusion"));
		Cell cell1=null;
		try{
			cell1= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell1= row1.createCell(columnIndex);
		}
		cell1.setCellValue('"'+(String)toJsonObject.get(value)+'"'+","+trigger+","+payout);
	}
	
	
	public static void removeElements(JSONArray removeArr, String productName, Row row1, String DTname, String commercialType, String entityType, String packageDir, HSSFWorkbook wb) throws NumberFormatException, JSONException, IOException {
		for (int j=0; j < removeArr.length(); j++){
			int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+removeArr.get(j).toString()));
			Cell cell = row1.getCell(columnIndex);
			if(cell != null)
				row1.removeCell(cell);
		}

		FileOutputStream fos = new FileOutputStream(packageDir+"/"+DTname+".xls");
		wb.write(fos); fos.close();
	}
	
	
	public static int getSettlementRuleID(String productName, String entityType, String DTname, String supplier, String supplierMarket, String entityName, String entityMarket, String clientEntityType){
		switch(productName){
		case "air": {return settlementRuleID(MappingConfiguration.airSupplierSettlementRuleID,MappingConfiguration.airClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "activities": {return settlementRuleID(MappingConfiguration.activitiesSupplierSettlementRuleID,MappingConfiguration.activitiesClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "accomodation": {return settlementRuleID(MappingConfiguration.accomodationSupplierSettlementRuleID,MappingConfiguration.accomodationClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "bus": {return settlementRuleID(MappingConfiguration.busSupplierSettlementRuleID,MappingConfiguration.busClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "rail": {return settlementRuleID(MappingConfiguration.railSupplierSettlementRuleID,MappingConfiguration.railClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "cruise": {return settlementRuleID(MappingConfiguration.cruiseSupplierSettlementRuleID,MappingConfiguration.cruiseClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "insurance": {return settlementRuleID(MappingConfiguration.insuranceSupplierSettlementRuleID,MappingConfiguration.insuranceClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "carrentals": {return settlementRuleID(MappingConfiguration.carSupplierSettlementRuleID,MappingConfiguration.carClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "holidays": {return settlementRuleID(MappingConfiguration.holidaysSupplierSettlementRuleID,MappingConfiguration.holidaysClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		case "visa": {return settlementRuleID(MappingConfiguration.visaSupplierSettlementRuleID,MappingConfiguration.visaClientSettlementRuleID,productName,entityType,DTname,supplier,supplierMarket,entityName,entityMarket,clientEntityType);}
		}
		return 0;
	}
	
	
	public static int settlementRuleID(Map<String,Integer> mapSupp, Map<String,Integer> mapClient, String productName, String entityType, String DTname, String supplier, String supplierMarket, String entityName, String entityMarket, String clientEntityType){
		if(entityType.equals("supplier")){
			if(mapSupp.containsKey(productName+entityType+DTname+supplier+supplierMarket)){
				int count = mapSupp.get(productName+entityType+DTname+supplier+supplierMarket);
				mapSupp.put(productName+entityType+DTname+supplier+supplierMarket,count+1);
				return count+1;
			}else{
				mapSupp.put(productName+entityType+DTname+supplier+supplierMarket,1);
				return 1;
			}
		}else{
			if(mapClient.containsKey(productName+entityType+DTname+supplier+entityName+entityMarket+clientEntityType)){
				int count = mapClient.get(productName+entityType+DTname+supplier+entityName+entityMarket+clientEntityType);
				mapClient.put(productName+entityType+DTname+supplier+entityName+entityMarket+clientEntityType,count+1);
				return count+1;
			}else{
				mapClient.put(productName+entityType+DTname+supplier+entityName+entityMarket+clientEntityType,1);
				return 1;
			}
		}
	}
	

	public static String getSupplierMarket(ArrayList<String> supplierMarket) {
		String suppMarket = null;
		for(int i=0;i<supplierMarket.size();i++){
			if(i==0)
				suppMarket = supplierMarket.get(i);
			else suppMarket+=";"+supplierMarket.get(i);
		}
		return suppMarket;
	}
	
	
	public static String getEntityMarket(ArrayList<String> object) {
		String entityMar = null;
		for(int i=0;i<object.size();i++){
			if(i==0)
				entityMar = object.get(i);
			else entityMar+=";"+object.get(i);
		}
		return entityMar;
	}


	public static boolean checkValid(String type, String RuleID) {
		if(type.equals("definition")||type.equals("advanced")||type.equals("base")){
			if(MappingConfiguration._id.isEmpty()||MappingConfiguration._id == null){
				MappingConfiguration._id.put(RuleID, RuleID);
				return true;
			}else{
				if(MappingConfiguration._id.containsKey(RuleID))
					return false;
				else{
					MappingConfiguration._id.put(RuleID, RuleID);
					return true;
				}
			}
		}else{
			if(MappingConfiguration.calc_id.isEmpty()||MappingConfiguration.calc_id == null){
				MappingConfiguration.calc_id.put(RuleID, RuleID);
				return true;
			}else{
				if(MappingConfiguration.calc_id.containsKey(RuleID))
					return false;
				else{
					MappingConfiguration.calc_id.put(RuleID, RuleID);
					return true;
				}
			}
		}
		
	}
	
	
	
	
	
	
	
}
		
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
