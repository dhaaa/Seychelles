package cnk.cce.configuration;

import cnk.cce.configuration.carrentals.CarRentalsRuleGenerator;

public class RuleFactory {

	public static Rule getRule(String productName) {

		if (productName.equalsIgnoreCase("air")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("activities")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("accomodation")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("bus")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("rail")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("cruise")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("insurance")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("carrentals")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("holidays")) {
			return new CarRentalsRuleGenerator();
		} else if (productName.equalsIgnoreCase("visa")) {
			return new CarRentalsRuleGenerator();
		}
		return null;
	}

}
