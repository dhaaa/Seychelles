package cnk.cce.configuration.carrentals;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONObject;
import cnk.cce.configuration.MappingConfiguration;
import cnk.cce.configuration.Rule;

public class CarRentalsRuleGenerator implements Rule{

	@Override
	public void createRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception{
		Map<String,Map<String,Object>> input=new HashMap<String,Map<String,Object>>();
		new MappingConfiguration();
		if(commercialType.equals("transactional")){
			if(entityType.equals("client")){
				for(int i=1;i<=MappingConfiguration.clientTransactionalSequence.size();i++){
					if(data.has(MappingConfiguration.clientTransactionalSequence.get(i))){
						insertRule(input,MappingConfiguration.clientTransactionalSequence.get(i),data,packageDir,productName,commercialType,entityType);
					}
				}
			}else{
				for(int i=1;i<=MappingConfiguration.supplierTransactionalSequence.size();i++){
					if(data.has(MappingConfiguration.supplierTransactionalSequence.get(i))){
						insertRule(input,MappingConfiguration.supplierTransactionalSequence.get(i),data,packageDir,productName,commercialType,entityType);
					}
				}
			}
		}else{
			Iterator<String> keys =data.keys();
			while(keys.hasNext()){
				String key=keys.next();																		//key is the DTname
				if(data.getJSONObject(key).length()>0)
				{	insertRule(input,key,data,packageDir,productName,commercialType,entityType);	}
			}
		}	
	}

	private void insertRule(Map<String, Map<String, Object>> input, String key, JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception {
		input.put(key, data.getJSONObject(key).toMap());
		RuleFunctions.insertRule(key, data.getJSONObject(key).toMap(), packageDir, productName, commercialType, entityType);
		
	}

	@Override
	public void updateRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception {
		Map<String,Map<String,Object>> input=new HashMap<String,Map<String,Object>>();
		Iterator<String> keys =data.keys();
		while(keys.hasNext()){
			String key=keys.next();																		//key is the DTname
			if(data.getJSONObject(key).length()>0)
			{
				input.put(key, data.getJSONObject(key).toMap());
				RuleFunctions.updateRule(key, data.getJSONObject(key).toMap(), packageDir, productName, commercialType, entityType);
			}
		}
	}

	@Override
	public void deleteRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception {
		Map<String,Map<String,Object>> input=new HashMap<String,Map<String,Object>>();
		Iterator<String> keys =data.keys();
		while(keys.hasNext()){
			String key=keys.next();																		//key is the DTname
			if(data.getJSONObject(key).length()>0)
			{
				input.put(key, data.getJSONObject(key).toMap());
				RuleFunctions.deleteRule(key, data.getJSONObject(key).toMap(), packageDir, productName, commercialType, entityType);
			}
		}
	}
}
