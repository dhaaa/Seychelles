package cnk.cce.rest;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.maven.shared.invoker.MavenInvocationException;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.configuration.Rule;
import cnk.cce.configuration.RuleFactory;
import cnk.cce.maven.MavenInvoker;

@Path("/cce")
public class RuleConfigurator {

	
	@Path("{product}/{entity}/{type}/create")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response createRule(InputStream ip,@PathParam("product") String productName, @PathParam("entity") String entityType, @PathParam("type") String commercialType){
		JSONTokener jt = new JSONTokener(ip);
		JSONObject data = new JSONObject(jt);
		Rule product=RuleFactory.getRule(productName);
		String location;															//key: DTname, value: selectedRow
		try {
			location = MavenInvoker.getInstance().getProperties().getProperty("BASE_Dir")+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName+"_"+entityType+"_"+commercialType);
			product.createRule(data,location,productName,commercialType,entityType);
			MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty("BASE_Dir")+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
			return Response.status(200).entity("{ \"Status\": \"Success\" }").build();
		}
		catch (IOException e) {e.printStackTrace();}
		catch (MavenInvocationException e) {e.printStackTrace();}
		catch(Exception e){e.printStackTrace();}
		
		return Response.status(500).entity("{ \"Status\": \"Failure\" }").build();
	}
	
	@Path("{product}/{entity}/{type}/update")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateRule(InputStream ip,@PathParam("product") String productName, @PathParam("entity") String entityType, @PathParam("type") String commercialType){
		JSONTokener jt = new JSONTokener(ip);
		JSONObject data = new JSONObject(jt);
		Rule product=RuleFactory.getRule(productName);
		String location;
		try {
			location = MavenInvoker.getInstance().getProperties().getProperty("BASE_Dir")+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName+"_"+entityType+"_"+commercialType);
			product.updateRule(data,location,productName,commercialType,entityType);
			MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty("BASE_Dir")+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
			return Response.status(200).entity("{ \"Status\": \"Success\" }").build();
		}
		catch (Exception e) {e.printStackTrace();}
		
		return Response.status(500).entity("{ \"Status\": \"Failure\" }").build();
	}
	
	@Path("{product}/{entity}/{type}/delete")
	@DELETE
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String deleteRule(InputStream ip,@PathParam("product") String productName, @PathParam("entity") String entityType, @PathParam("type") String commercialType){
		JSONTokener jt = new JSONTokener(ip);
		JSONObject data = new JSONObject(jt);
		Rule product=RuleFactory.getRule(productName);
		String location;
		try {
			location = MavenInvoker.getInstance().getProperties().getProperty("BASE_Dir")+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName+"_"+entityType+"_"+commercialType);
			product.deleteRule(data,location,productName,commercialType,entityType);
			MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty("BASE_Dir")+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
			return "{ \"Status\": \"Success\" }";
		}
		catch (Exception e) {e.printStackTrace();}
		
		return "{ \"Status\": \"Failure\" }";
	}
}
