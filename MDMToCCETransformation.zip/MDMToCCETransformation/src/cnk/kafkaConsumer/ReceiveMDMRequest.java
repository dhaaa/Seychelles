package cnk.kafkaConsumer;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.json.JSONException;
import org.json.JSONObject;

import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.transformation.MDMToCCETransformation;

public class ReceiveMDMRequest {

	public static void main(String args[]) throws JSONException, Exception{
	Properties properties = new Properties();
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    String str = "";
    String topic = "MDM.DEV.SUPPLIERCOMMERCIAL.PUB";

    try (InputStream in = classLoader.getResourceAsStream("Configuration.properties")) {
          properties.load(in);

          Enumeration<Object> enuKeys = properties.keys();
          while (enuKeys.hasMoreElements()) {
                 String key = (String) enuKeys.nextElement();
                 String value = properties.getProperty(key);
                 properties.put(key, value);
          }
    } catch (FileNotFoundException e) {
          e.printStackTrace();
    } 


    KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(properties);
 
	consumer.subscribe(Arrays.asList(topic));
    System.out.println("Subscribed to topic " + topic);

    while (true) {
          ConsumerRecords<String, String> records = consumer.poll(100);
          //System.out.println(records);
          for (ConsumerRecord<String, String> record : records) {
                 System.out.printf("offset = %d, message = %s\n", record.offset(), record.value());
                 str = record.value();
                 JSONObject mdmData = new JSONObject(str);
                 System.out.println("data :: " + mdmData);
                 String method = mdmData.getString("method");
                 System.out.println("method :: "+method);
                 String request = MDMToCCETransformation.readJSON(mdmData.getJSONObject("data").toString());
                 InvokeRuleConfigurator.invokeRuleConfigurator(request);
          }
          //consumer.close();
    }
	}
}
