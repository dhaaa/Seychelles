package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SupplierCommercialStandardCalculation {

	public static JSONObject createStandardCalculationDT(JSONObject req,JSONObject mdmDefn) throws JSONException{
		JSONObject stdCalcJson = new JSONObject(); 
		
		stdCalcJson.put("commercialName","Standard");
		stdCalcJson.put("type","calculation");
		stdCalcJson.put("supplier",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId"));
		stdCalcJson.put("supplierMarket",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
		
		JSONArray tempChainArr=new JSONArray();
		JSONArray tempBrandArr=new JSONArray();
		JSONArray tempNameArr=new JSONArray();
		for(int l=0;l<mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").length() && mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").length()>0;l++)
		{
			Object tempNameObj=new Object();
			Object tempChainObj=mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).get("chain");
			Object tempBrandObj=mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).get("brand");
			if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).has("name"))
				tempNameObj = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).get("name");
			tempChainArr.put(tempChainObj);
			tempBrandArr.put(tempBrandObj);
			tempNameArr.put(tempNameObj);
		}
		stdCalcJson.put("productChain",tempChainArr);
		stdCalcJson.put("productBrand",tempBrandArr);
		stdCalcJson.put("productName",tempNameArr);
		
		//=======================================Room Details=======================================================
				
		for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++)
		{
			 
			if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("advanceDefinitionsId").equals(
				mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).get("_id")) && mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategory").equals("Accommodation"))
			{
				JSONArray RoomDtlsInclsnArr=new JSONArray();
				JSONObject RoomDtlsObj=new JSONObject();
				JSONObject RoomDtlsInclsnObj=new JSONObject();
				if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").has("isInclusion") && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").get("isInclusion").equals(true))
				{
					JSONArray RoomCtgryInclsnArr=new JSONArray();
					JSONObject RoomCtgryInclsnObj=new JSONObject();
					
					for(int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").getJSONArray("roomCategories").length();j++)
					{
						RoomCtgryInclsnObj.put("roomCategory",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").getJSONArray("roomCategories").get(j));
						RoomCtgryInclsnArr.put(RoomCtgryInclsnObj);
						
						
					}
					RoomDtlsInclsnObj.put("inclusion", RoomCtgryInclsnArr);
					RoomDtlsInclsnArr.put(RoomDtlsInclsnObj);
				}
				else
				{
					JSONArray RoomCtgryExclsnArr=new JSONArray();
					JSONObject RoomCtgryExclsnObj=new JSONObject();
					
					
						
				}
					
					//RoomExclsnObj.put("inclusion", RoomCtgryInclsnArr);
					RoomDtlsInclsnArr.put(RoomDtlsInclsnObj);
					System.out.println(RoomDtlsInclsnArr);
					
					
				}	
				
			}
		
		
		
		
		if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("fixed"))
		{
			if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("fixed").get("isPercentage").equals(true))
			{
				stdCalcJson.put("percentage",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("fixed").getJSONArray("percentageDetails").getJSONObject(0).get("valuePercentage"));
				stdCalcJson.put("fareComponent",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("fixed").getJSONArray("percentageDetails").getJSONObject(0).get("farePriceComponents"));
			}
			if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("fixed").get("isAmount").equals(true))
			{
				stdCalcJson.put("amountValue",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("fixed").get("valueAmount"));
			}
			if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("fixed").has("currency"))
			stdCalcJson.put("currency",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("fixed").get("currency"));
			
		}
		return stdCalcJson;
	
	}
	
}
