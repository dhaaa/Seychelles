package cnk.transformation;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

public class MDMToCCETransformation {
	 //static File file = new File("D:\\vasudha\\tr\\MDM\\InputFile.json");
	static File file = new File("E:\\Feb1\\Latest\\InputFile.json");
	 static JSONObject rootJson = new JSONObject();
	
	private static void readJSON() throws Exception {
	   
	    String content = FileUtils.readFileToString(file, "utf-8");
	    JSONObject breDefn = new JSONObject(); 
	    JSONObject mdmDefn = new JSONObject(content);
	    	   
	    JSONObject commDefn=SupplierCommercialDefinition.createCommercialDefinitionDT(breDefn, mdmDefn);
	    rootJson.put("CommercialDefinitionDT",commDefn);
	    
	    JSONObject stdBaseJson = SupplierCommercialStandardBase.createStandardBaseDT(breDefn,mdmDefn);
	    rootJson.put("StandardCommercialBaseDT",stdBaseJson);
	   
	    JSONObject stdCalcJson = SupplierCommercialStandardCalculation.createStandardCalculationDT(breDefn,mdmDefn);
	    rootJson.put("StandardCommercialCalculationDT",stdCalcJson);
	    
	    JSONObject ovrrdngBaseJson = SupplierCommercialOverridingBase.createOverridingBaseDT(breDefn,mdmDefn);
	    rootJson.put("OverridingCommercialBaseDT",ovrrdngBaseJson);
	    
	    JSONObject ovrrdngCalcJson = SupplierCommercialOverridingCalculation.createOverridingCalculationDT(breDefn,mdmDefn);
	    rootJson.put("OverridingCommercialCalculationDT",ovrrdngCalcJson);
	    
	    System.out.println(rootJson);
	}

	public static void main(String args[]){
		MDMToCCETransformation t = null;
		try {
			t.readJSON();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
