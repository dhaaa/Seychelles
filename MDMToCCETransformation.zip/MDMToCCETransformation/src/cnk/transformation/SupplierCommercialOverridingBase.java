package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class SupplierCommercialOverridingBase {

	public static JSONObject createOverridingBaseDT(JSONObject breDefn,JSONObject mdmDefn) throws JSONException{
		 JSONObject ovrrdngBaseJson = new JSONObject(); 
		 ovrrdngBaseJson.put("commercialName","Overriding");
		 ovrrdngBaseJson.put("type","base");
		 ovrrdngBaseJson.put("supplier",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId"));
		 ovrrdngBaseJson.put("supplierMarket",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
		 //stdBaseJson.put("clientType",mdmDefn.getJSONObject("standardCommercial").getJSONArray("clients"));
		  //ipJson.put("clientGroup",mdmDefn.getJSONObject("standardCommercial").getJSONArray("clients").get(1));
		 // ipJson.put("clientName",mdmDefn.getJSONObject("standardCommercial").getJSONArray("clients").get(2));
		 ovrrdngBaseJson.put("iataNumber",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").get("IATANumbers"));
		
		 //----------Contract validity JSON Object creation -------------------------
		 JSONObject cntrctVldty = new JSONObject(); 
		 cntrctVldty.put("operator","BETWEEN");
		 cntrctVldty.put("from",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("contractValidityFrom"));
		 cntrctVldty.put("to",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("contractValidityTo"));
		 ovrrdngBaseJson.put("contractValidity",cntrctVldty);
		 
		 //------------Find Matching Advanced Definition for Standard Commercials of Accommodation ------------------
		
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++)
			{
				 
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").get("overRidingCommission").get("advanceDefinationId")equals(
						mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).get("_id")) && mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategory").equals("Accommodation"))
				{
					
					 JSONArray saleArr=new JSONArray();
					 JSONObject saleObj=new JSONObject();
					 JSONArray travelArr=new JSONArray();
					 JSONObject travelObj=new JSONObject();
					 JSONArray saleInclsnArr=new JSONArray();
					 JSONArray saleExclsnArr=new JSONArray();
					 JSONArray travelInclsnArr=new JSONArray();
					 JSONArray travelExclsnArr=new JSONArray();
					 
					 
					if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").has("validityType"))
					{ 
						
						if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").get("validityType").equals("sale"))
						{
						
						  for (int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("sale").length() && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("sale").length()>0;j++)
						  {
							          //-------Inclusion and Exclusion Object creation -----------
							  JSONObject saleInclsnObj=new JSONObject(); 
							  JSONObject mdmInclsnExclsnObj=new JSONObject();
							  JSONObject saleExclsnObj=new JSONObject(); 
							  mdmInclsnExclsnObj=mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("sale").getJSONObject(j);
						   	  if(mdmInclsnExclsnObj.has("saleFrom")){
						   		saleInclsnObj.put("operator","BETWEEN");
						   		saleInclsnObj.put("from",mdmInclsnExclsnObj.get("saleFrom"));
						   		saleInclsnObj.put("to",mdmInclsnExclsnObj.get("saleTo"));
						 	   }
						 	  saleInclsnArr.put(saleInclsnObj);
						 	  if(mdmInclsnExclsnObj.has("blockOutFrom")){
						 		saleExclsnObj.put("operator","BETWEEN");
						 		saleExclsnObj.put("from",mdmInclsnExclsnObj.get("blockOutFrom"));
						 		saleExclsnObj.put("to",mdmInclsnExclsnObj.get("blockOutTo"));
						 	   }
						   }
						  if(saleInclsnArr.length()>0)
						      saleObj.put("inclusion",saleInclsnArr);
						  if(saleExclsnArr.length()>0)
							  saleObj.put("exclusion",saleExclsnArr);
						  saleArr.put(saleObj);
						  ovrrdngBaseJson.put("sale",saleArr);
					    }
					    else if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").get("validityType").equals("travel"))
					    {
					    	System.out.println("Inside Travel");
					    	for (int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("travel").length() && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("travel").length()>0;j++)
					    	{
					          //-------Inclusion and Exclusion Object creation -----------
							 JSONObject travelInclsnObj=new JSONObject(); 
							 JSONObject mdmInclsnExclsnObj=new JSONObject();
							 JSONObject travelExclsnObj=new JSONObject(); 
							 mdmInclsnExclsnObj=mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("travel").getJSONObject(j);
							 	if(mdmInclsnExclsnObj.has("travelFrom")){
							 		travelInclsnObj.put("operator","BETWEEN");
							 		travelInclsnObj.put("from",mdmInclsnExclsnObj.get("travelFrom"));
							 		travelInclsnObj.put("to",mdmInclsnExclsnObj.get("travelTo"));
							 	}
							  travelInclsnArr.put(travelInclsnObj);
							 	if(mdmInclsnExclsnObj.has("blockOutFrom")){
							 		travelExclsnObj.put("operator","BETWEEN");
							 		travelExclsnObj.put("from",mdmInclsnExclsnObj.get("blockOutFrom"));
							 		travelExclsnObj.put("to",mdmInclsnExclsnObj.get("blockOutTo"));
							 	}
						     }
					    	if(travelInclsnArr.length()>0)
					    		travelObj.put("inclusion",travelInclsnArr);
					    	if(travelExclsnArr.length()>0)
					    		travelObj.put("exclusion",travelExclsnArr);
					    	travelArr.put(travelObj);
					    	ovrrdngBaseJson.put("travel",travelArr);
					    }
					    else
					    {
						 	for (int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("salePlusTravel").length() && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("salePlusTravel").length()>0;j++)
						 	{
					          //-------Inclusion and Exclusion Object creation -----------
							 		JSONObject saleInclsnObj=new JSONObject(); 
							 		JSONObject travelInclsnObj=new JSONObject(); 
							 		JSONObject mdmInclsnExclsnObj=new JSONObject();
							 		JSONObject saleExclsnObj=new JSONObject();
							 		JSONObject travelExclsnObj=new JSONObject(); 
							 		mdmInclsnExclsnObj=mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("salePlusTravel").getJSONObject(j);
							 		
							 		if(mdmInclsnExclsnObj.has("sales")){
							 			
							 			if(mdmInclsnExclsnObj.getJSONObject("sales").has("saleFrom")){
							 				saleInclsnObj.put("operator","BETWEEN");
							 				saleInclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("sales").get("saleFrom"));
							 				saleInclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("sales").get("saleTo"));
							 			 }
							 		    saleInclsnArr.put(saleInclsnObj);
							 		 	if(mdmInclsnExclsnObj.getJSONObject("sales").has("blockOutFrom")){
							 		 	
							 		 	 saleExclsnObj.put("operator","BETWEEN");
							 		 	 saleExclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("sales").get("blockOutFrom"));
							 		 	 saleExclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("sales").get("blockOutTo"));
							 		 	}
							 		 	 saleExclsnArr.put(saleExclsnObj);
							 		 	
							 		}
							 		if(mdmInclsnExclsnObj.has("travel")){
							 			if(mdmInclsnExclsnObj.getJSONObject("travel").has("travelFrom")){
							 				travelInclsnObj.put("operator","BETWEEN");
							 				travelInclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("travel").get("travelFrom"));
							 				travelInclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("travel").get("travelTo"));
							 			 }
							 		    travelInclsnArr.put(travelInclsnObj);
							 		 	if(mdmInclsnExclsnObj.getJSONObject("travel").has("blockOutFrom")){
							 		 		
							 		 		travelExclsnObj.put("operator","BETWEEN");
							 		 		travelExclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("travel").get("blockOutFrom"));
							 		 		travelExclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("travel").get("blockOutTo"));
							 		 	}
							 		 	travelExclsnArr.put(travelExclsnObj);
							 		}
						 	  }
						 	  if(saleInclsnArr.length()>0)
						 		  saleObj.put("inclusion",saleInclsnArr);
						 	  if(saleExclsnArr.length()>0)
						 		  saleObj.put("exclusion",saleExclsnArr);
						 	  saleArr.put(saleObj);
						 	  if(travelInclsnArr.length()>0)
						 		  travelObj.put("inclusion",travelInclsnArr);
						 	  if(travelExclsnArr.length()>0)
						 		 travelObj.put("exclusion",travelExclsnArr);
						 	  travelArr.put(travelObj);
						 	 ovrrdngBaseJson.put("sale",saleArr);
						 	 ovrrdngBaseJson.put("travel",travelArr);
						 
					       }
						}				
					
					 // -------------------------------Create Travel Destination array --------------------------------------------
						
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").has("travelDestination") &&
						 mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").length()>0)
					 {
						 JSONArray travelDstnArr=new JSONArray();
						 JSONObject travelDstnObj=new JSONObject();

						 JSONArray dstnInclsnArr=new JSONArray();
						 JSONObject dstnInclsnObj=new JSONObject();
						 JSONArray dstnExclsnArr=new JSONArray();
						 JSONObject dstnExclsnObj=new JSONObject();
						 for (int k=0;k<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").length();k++)
						 {
							 
							if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").get("isInclusion").equals("true")){
								 
								 dstnInclsnObj.put("continent",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("continent"));
								 dstnInclsnObj.put("country",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("coountry"));
								 dstnInclsnObj.put("state",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("state"));
								 dstnInclsnObj.put("city",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("city"));
								 dstnInclsnArr.put(dstnInclsnObj);
							}
							else
							{
								
								 dstnExclsnObj.put("continent",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("continent"));
								 dstnExclsnObj.put("country",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("country"));
								 dstnExclsnObj.put("state",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("state"));
								 dstnExclsnObj.put("city",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("city"));
								 dstnExclsnArr.put(dstnExclsnObj);
							}	
						 }	 
						 travelDstnObj.put("inclusion",dstnInclsnArr);
						 travelDstnObj.put("exclusion",dstnExclsnArr);
						 travelDstnArr.put(travelDstnObj);
						 ovrrdngBaseJson.put("travelDestination",travelDstnArr);
					 }		 
						
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").has("connectivity"))
					 {
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").has("supplierType"))
						 ovrrdngBaseJson.put("connectivitySupplierType",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").get("supplierType"));
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").has("supplierId"))
						 ovrrdngBaseJson.put("connectivitySupplierName",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").get("supplierId"));
					 }
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").has("credentials"))
						 ovrrdngBaseJson.put("credentialsName",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").get("credentials"));
				  }	
				}
	
		
			 
			
		 return ovrrdngBaseJson;
		
	}

}
