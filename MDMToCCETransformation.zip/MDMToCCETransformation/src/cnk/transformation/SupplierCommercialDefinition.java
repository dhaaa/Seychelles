package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SupplierCommercialDefinition {
	
	
public static JSONObject createCommercialDefinitionDT(JSONObject breDefn,JSONObject mdmDefn,int ovrdngId,int plbId,int dstnId,int sgmtId,int sctrId,int srvcChrgId,int mgmtId) throws JSONException{
		
		JSONObject commDefn =new JSONObject();
		commDefn.put("commercialName","definition");
		commDefn.put("type","definition");
		commDefn.put("supplier", mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId"));
		commDefn.put("supplierMarket",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
		commDefn.put("productCategorySubType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategorySubType"));
	

	    //Define Commercial Head Array
	    JSONArray commHead =new JSONArray();
	    
	    //Define Standard Commercial
	    JSONObject stdComm = new JSONObject();
	    
	    if(mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
	    	
	    	stdComm.put("commercialHeadName","Standard");
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").has("commercialType")){
	    	stdComm.put("commercialType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").get("commercialType"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("isSettlementTransactionWise")){
	    	stdComm.put("settlementTransactionWise",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("isSettlementTransactionWise"));
	    	}
	    		    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").has("isProvisional"))
	    	{stdComm.put("contractType","Provisional");}
	    	else
	    	{ stdComm.put("contractType","Final");}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("isCommisionable")){
	    	stdComm.put("commissionable",true);
	    	}
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("applicable")){
	    	stdComm.put("markDownApplicable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("applicable"));
	    	}

	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("clientType")){
	    	stdComm.put("markDownClientApplicable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("clientType"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("minimumPercent")){
	    	stdComm.put("minimumMarkUpPercentage",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("minimumPercent"));
	    	}
	    	else
	    	{ stdComm.put("minimumMarkUpPercentage",0);}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("maximumPercent")){
	    		stdComm.put("maximumMarkUpPercentage",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("maximumPercent"));
		    }
	    	else
	    	{ stdComm.put("maximumMarkUpPercentage",0);}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").has("clientType")){
	    		stdComm.put("markUpClientType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").get("clientType"));
		    }
	    	
	 
	    }
	  
	    commHead.put(stdComm);			
	    //Add Standard Commercial to Commercial Head Array
	     
	  
	    	//============================Define Overriding Commercial============================================
	    if(ovrdngId!=-1)
	    {
	    	JSONObject ovrdngComm = new JSONObject();
	    	ovrdngComm.put("commercialHeadName","Overriding");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("calculation").has("netOffCommercialHead") && 
	    			mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("calculation").get("netOffCommercialHead").toString().length()>0)
		    	ovrdngComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("calculation").get("netOffCommercialHead"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("commercialInformation").has("commercialType"))
	    		ovrdngComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("commercialInformation").get("commercialType"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("commercialInformation").has("isSettlementTransactionWise"))
	    	{ ovrdngComm.put("settlementTransactionWise",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("commercialInformation").get("isSettlementTransactionWise"));}
	    	else
	    		ovrdngComm.put("settlementTransactionWise",false);
		    
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("commercialInformation").has("isProvisional"))
		    {ovrdngComm.put("contractType","Provisional");}
		    else
		    {ovrdngComm.put("contractType","Final");}
		    
	    	ovrdngComm.put("commissionable",false);
		    ovrdngComm.put("markDownApplicable",false);  
		    ovrdngComm.put("minimumMarkUpPercentage",0);
		    ovrdngComm.put("maximumMarkUpPercentage",0);
		  
		
	    		    	
	    	commHead.put(ovrdngComm);
	    }
	    	
	  //============================Define PLB Commercial============================================
	    if(plbId!=-1)
	    {
	    	JSONObject plbComm = new JSONObject();
	    	plbComm.put("commercialHeadName","PLB");
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("calculation").has("netOffCommercialHead") && 
	    	   mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("calculation").get("netOffCommercialHead").toString().length()>0)
	    		plbComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("calculation").get("netOffCommercialHead"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("commercialInformation").has("commercialType"))
	    		plbComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("commercialInformation").get("commercialType"));
	    
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("commercialInformation").has("isSettlementTransactionWise"))
	    	{ plbComm.put("settlementTransactionWise",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("commercialInformation").get("isSettlementTransactionWise"));}
	    	else
	    		plbComm.put("settlementTransactionWise",false);
		    
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("commercialInformation").has("isProvisional"))
		    {plbComm.put("contractType","Provisional");}
		    else
		    {plbComm.put("contractType","Final");}
		    
	    	plbComm.put("commissionable",false);
	    	plbComm.put("markDownApplicable",false);  
	    	plbComm.put("minimumMarkUpPercentage",0);
	    	plbComm.put("maximumMarkUpPercentage",0);
	    	
	    		    	
	    	commHead.put(plbComm);
	    }
	    
	    //============================Define Destination Incentive============================================
	    if(dstnId>-1)
	    {
	    	System.out.println(dstnId);
	    	JSONObject dstnComm = new JSONObject();
	    	dstnComm.put("commercialHeadName","DestinationIncentive");
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("calculation").has("netOffCommercialHead")
	    	  && mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("calculation").get("netOffCommercialHead").toString().length()>0)
	    		dstnComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("calculation").get("netOffCommercialHead"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").has("commercialType"))
	    		dstnComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").get("commercialType"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").has("isSettlementTransactionWise"))
	    	{ dstnComm.put("settlementTransactionWise",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").get("isSettlementTransactionWise"));}
	    	else
	    		dstnComm.put("settlementTransactionWise",false);
		    
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").has("isProvisional"))
		    {dstnComm.put("contractType","Provisional");}
		    else
		    {dstnComm.put("contractType","Final");}
		    
	    	dstnComm.put("commissionable",false);
	    	dstnComm.put("markDownApplicable",false);  
	    	dstnComm.put("minimumMarkUpPercentage",0);
	    	dstnComm.put("maximumMarkUpPercentage",0);
	    		    	
	    	commHead.put(dstnComm);
	    }
	    
	    //============================Define Segment Fee============================================
	    if(sgmtId!=-1)
	    {
	    	JSONObject sgmtComm = new JSONObject();
	    	sgmtComm.put("commercialHeadName","SegmentFee");
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("calculation").has("netOffCommercialHead"))
	    		sgmtComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("calculation").get("netOffCommercialHead"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("commercialInformation").has("commercialType"))
	    		sgmtComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("commercialInformation").get("commercialType"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("commercialInformation").has("isSettlementTransactionWise"))
	    	{ sgmtComm.put("settlementTransactionWise",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("commercialInformation").get("isSettlementTransactionWise"));}
	    	else
	    		sgmtComm.put("settlementTransactionWise",false);
		    
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("commercialInformation").has("isProvisional"))
		    {sgmtComm.put("contractType","Provisional");}
		    else
		    {sgmtComm.put("contractType","Final");}
		    
	    	sgmtComm.put("commissionable",false);
	    	sgmtComm.put("markDownApplicable",false);  
	    	sgmtComm.put("minimumMarkUpPercentage",0);
	    	sgmtComm.put("maximumMarkUpPercentage",0);
	    	
	    		    	
	    	commHead.put(sgmtComm);
	    }
	    
	    //============================Define Service Charge============================================
	    if(srvcChrgId!=-1)
	    { 
	    	JSONObject srvcChrgComm = new JSONObject();
	    	srvcChrgComm.put("commercialHeadName","ServiceCharge");
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("calculation").has("netOffCommercialHead")
	    	 && mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("calculation").get("netOffCommercialHead").toString().length()>0)
	    		srvcChrgComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("calculation").get("netOffCommercialHead"));
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("commercialInformation").has("commercialType"))
	    		srvcChrgComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("commercialInformation").get("commercialType"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("commercialInformation").has("isSettlementTransactionWise"))
	    	{ srvcChrgComm.put("settlementTransactionWise",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").get("isSettlementTransactionWise"));}
	    	else
	    		srvcChrgComm.put("settlementTransactionWise",false);
		    
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("commercialInformation").has("isProvisional"))
		    {srvcChrgComm.put("contractType","Provisional");}
		    else
		    {srvcChrgComm.put("contractType","Final");}
		    
	    	srvcChrgComm.put("commissionable",false);
	    	srvcChrgComm.put("markDownApplicable",false);  
	    	srvcChrgComm.put("minimumMarkUpPercentage",0);
	    	srvcChrgComm.put("maximumMarkUpPercentage",0);
	    		    	
	    	commHead.put(srvcChrgComm);
	    }
	    
	    //============================ Define Management Fee ============================================
	    if(mgmtId!=-1)
	    {
	    	JSONObject mgmtComm = new JSONObject();
	    	mgmtComm.put("commercialHeadName","ManagementFee");
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("calculation").has("netOffCommercialHead")
	    	  && mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("calculation").get("netOffCommercialHead").toString().length()>0)
	    		mgmtComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("calculation").get("netOffCommercialHead"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("commercialInformation").has("commercialType"))
	    		mgmtComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("commercialInformation").get("commercialType"));
	    	
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("commercialInformation").has("isSettlementTransactionWise"))
	    	{ mgmtComm.put("settlementTransactionWise",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("commercialInformation").get("isSettlementTransactionWise"));}
	    	else
	    		mgmtComm.put("settlementTransactionWise",false);
		    
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("commercialInformation").has("isProvisional"))
		    {mgmtComm.put("contractType","Provisional");}
		    else
		    {mgmtComm.put("contractType","Final");}
		    
	    	mgmtComm.put("commissionable",false);
	    	mgmtComm.put("markDownApplicable",false);  
	    	mgmtComm.put("minimumMarkUpPercentage",0);
	    	mgmtComm.put("maximumMarkUpPercentage",0);
	    		    	
	    	commHead.put(mgmtComm);
	    }
	    
	    
	    commDefn.put("commercialHead",commHead);
	    
	    
	    
	    return commDefn;
	    }
		
	}



