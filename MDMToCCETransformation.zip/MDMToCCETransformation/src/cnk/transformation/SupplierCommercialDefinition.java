package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SupplierCommercialDefinition {
	static  int ovrdngId=0,plbId=0,dstnId=0,sgmtId=0,sctrId=0,srvcChrgId=0,mgmtId=0;
	
public static JSONObject createCommercialDefinitionDT(JSONObject breDefn,JSONObject mdmDefn) throws JSONException{
		
		JSONObject commDefn =new JSONObject();
		commDefn.put("commercialName","definition");
		commDefn.put("type","definition");
		commDefn.put("supplier", mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId"));
		commDefn.put("supplierMarket",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
		commDefn.put("productCategorySubType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategorySubType"));
		boolean ovrdngFlg,plbFlg, dstnFlg, sgmtFlg, sctrFlg, srvcChrgFlg, mgmtFlg;
		ovrdngFlg=false;plbFlg=false;dstnFlg=false;sgmtFlg=false;sctrFlg=false;srvcChrgFlg=false;mgmtFlg=false; 
		
		
	    //Define Commercial Head Array
	    JSONArray commHead =new JSONArray();
	    
	    //Define Standard Commercial
	    JSONObject stdComm = new JSONObject();
	    
	    if(mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
	    	stdComm.put("commercialHeadName","Standard");
	    	stdComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").has("commercialType")){
	    	stdComm.put("commercialType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").get("commercialType"));
	    	}
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("isSettlementTransactionWise")){
	    	stdComm.put("settlementTransactionWise",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("isSettlementTransactionWise"));
	    	}
	    	else
	    	{ stdComm.put("settlementTransactionWise",""); }
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").has("isProvisional"))
	    	{
	    		stdComm.put("contractType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").get("isProvisional"));
	    	}
	    	else
	    	{ stdComm.put("contractType","");}
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("isCommisionable")){
	    	stdComm.put("commissionable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("isCommisionable"));
	    	}
	    	{ stdComm.put("commissionable","");}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("applicable")){
	    	stdComm.put("markDownApplicable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("applicable"));
	    	}
	    	else
	    	{ stdComm.put("markDownApplicable","");}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("clientType")){
	    	stdComm.put("markDownClientApplicable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("clientType"));
	    	}
	    	else
	    	{ stdComm.put("markDownClientApplicable","");}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("minimumPercent")){
	    	stdComm.put("minimumMarkUpPercentage",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("minimumPercent"));
	    	}
	    	else
	    	{ stdComm.put("minimumMarkUpPercentage",0);}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("maximumPercent")){
	    		stdComm.put("maximumMarkUpPercentage",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("maximumPercent"));
		    }
	    	else
	    	{ stdComm.put("maximumMarkUpPercentage",0);}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").has("clientType")){
	    		stdComm.put("markUpClientType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").get("clientType"));
		    }
	    	else
	    	{ stdComm.put("markUpClientType","");}	
	       	stdComm.put("status","");
	 
	    }
	  
	    commHead.put(stdComm);			
	    //Add Standard Commercial to Commercial Head Array
	     
	    //=======================================All other Commercials ============================================================
	    
	    for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length() && mdmDefn.getJSONArray("advanceCommercialData").length()>0;i++)
	    {
	    	
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Overriding Commission"))
				{ ovrdngFlg=true;
				  ovrdngId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Productivity Linked Bonus"))
				{ plbFlg=true;
				  plbId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Destination Incentive"))
				{ dstnFlg=true;
				  dstnId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Segment Fee"))
				{ sgmtFlg=true;
				  sgmtId=i;				
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Sectorwise Incentive"))
				{ sctrFlg=true;
				  sctrId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Service Charge"))
				{ srvcChrgFlg=true;
				  srvcChrgId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Management Fee"))
				{ mgmtFlg=true;
				  mgmtId=i;
				}
			    
	    }
	    
	  
	    	//============================Define Overriding Commercial============================================
	    if(ovrdngFlg==true)
	    {
	    	JSONObject ovrdngComm = new JSONObject();
	    	ovrdngComm.put("commercialHeadName","Overriding");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("calculation").has("netOffCommercialHead"))
		    	ovrdngComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("calculation").get("netOffCommercialHead"));
		    else	
		    	ovrdngComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("commercialInformation").has("commercialType"))
	    		ovrdngComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("commercialInformation").get("commercialType"));
	    	else
	    		ovrdngComm.put("commercialType","");
		    ovrdngComm.put("settlementTransactionWise","");
		    ovrdngComm.put("contractType","");
		    ovrdngComm.put("commissionable","");
		    ovrdngComm.put("markDownApplicable","");
		    ovrdngComm.put("markDownClientApplicable","");
		    ovrdngComm.put("minimumMarkUpPercentage",0);
		    ovrdngComm.put("maximumMarkUpPercentage",0);
		    ovrdngComm.put("markUpClientType","");
		    ovrdngComm.put("status","");
	    		    	
	    	commHead.put(ovrdngComm);
	    }
	    	
	  //============================Define PLB Commercial============================================
	    if(plbFlg==true)
	    {
	    	JSONObject plbComm = new JSONObject();
	    	plbComm.put("commercialHeadName","PLB");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("calculation").has("netOffCommercialHead"))
	    		plbComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("calculation").get("netOffCommercialHead"));
		    else	
		    	plbComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("commercialInformation").has("commercialType"))
	    		plbComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(plbId).getJSONObject("advanceCommercial").getJSONObject("plb").getJSONObject("commercialInformation").get("commercialType"));
	    	else
	    		plbComm.put("commercialType","");
	    	plbComm.put("settlementTransactionWise","");
	    	plbComm.put("contractType","");
	    	plbComm.put("commissionable","");
	    	plbComm.put("markDownApplicable","");
	    	plbComm.put("markDownClientApplicable","");
	    	plbComm.put("minimumMarkUpPercentage","");
	    	plbComm.put("maximumMarkUpPercentage","");
	    	plbComm.put("markUpClientType","");
	    	plbComm.put("status","");
	    		    	
	    	commHead.put(plbComm);
	    }
	    
	    //============================Define Destination Incentive============================================
	    if(dstnFlg==true)
	    {
	    	JSONObject dstnComm = new JSONObject();
	    	dstnComm.put("commercialHeadName","DestinationIncentive");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("calculation").has("netOffCommercialHead"))
	    		dstnComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("calculation").get("netOffCommercialHead"));
		    else	
		    	dstnComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").has("commercialType"))
	    		dstnComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(dstnId).getJSONObject("advanceCommercial").getJSONObject("destinationIncentives").getJSONObject("commercialInformation").get("commercialType"));
	    	else
	    		dstnComm.put("commercialType","");
	    	dstnComm.put("settlementTransactionWise","");
	    	dstnComm.put("contractType","");
	    	dstnComm.put("commissionable","");
	    	dstnComm.put("markDownApplicable","");
	    	dstnComm.put("markDownClientApplicable","");
	    	dstnComm.put("minimumMarkUpPercentage","");
	    	dstnComm.put("maximumMarkUpPercentage","");
	    	dstnComm.put("markUpClientType","");
	    	dstnComm.put("status","");
	    		    	
	    	commHead.put(dstnComm);
	    }
	    
	    //============================Define Segment Fee============================================
	    if(sgmtFlg==true)
	    {
	    	JSONObject sgmtComm = new JSONObject();
	    	sgmtComm.put("commercialHeadName","SegmentFee");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("calculation").has("netOffCommercialHead"))
	    		sgmtComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("calculation").get("netOffCommercialHead"));
		    else	
		    	sgmtComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("commercialInformation").has("commercialType"))
	    		sgmtComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(sgmtId).getJSONObject("advanceCommercial").getJSONObject("segmentFees").getJSONObject("commercialInformation").get("commercialType"));
	    	else
	    		sgmtComm.put("commercialType","");
	    	sgmtComm.put("settlementTransactionWise","");
	    	sgmtComm.put("contractType","");
	    	sgmtComm.put("commissionable","");
	    	sgmtComm.put("markDownApplicable","");
	    	sgmtComm.put("markDownClientApplicable","");
	    	sgmtComm.put("minimumMarkUpPercentage","");
	    	sgmtComm.put("maximumMarkUpPercentage","");
	    	sgmtComm.put("markUpClientType","");
	    	sgmtComm.put("status","");
	    		    	
	    	commHead.put(sgmtComm);
	    }
	    
	    //============================Define Service Charge============================================
	    if(srvcChrgFlg==true)
	    { 
	    	JSONObject srvcChrgComm = new JSONObject();
	    	srvcChrgComm.put("commercialHeadName","ServiceCharge");
	    	//if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("calculation").has("netOffCommercialHead"))
	    		//srvcChrgComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("calculation").get("netOffCommercialHead"));
		    //else	
		    	srvcChrgComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("commercialInformation").has("commercialType"))
	    		srvcChrgComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(srvcChrgId).getJSONObject("advanceCommercial").getJSONObject("serviceCharge").getJSONObject("commercialInformation").get("commercialType"));
	    	else
	    		srvcChrgComm.put("commercialType","");
	    	srvcChrgComm.put("settlementTransactionWise","");
	    	srvcChrgComm.put("contractType","");
	    	srvcChrgComm.put("commissionable","");
	    	srvcChrgComm.put("markDownApplicable","");
	    	srvcChrgComm.put("markDownClientApplicable","");
	    	srvcChrgComm.put("minimumMarkUpPercentage","");
	    	srvcChrgComm.put("maximumMarkUpPercentage","");
	    	srvcChrgComm.put("markUpClientType","");
	    	srvcChrgComm.put("status","");
	    		    	
	    	commHead.put(srvcChrgComm);
	    }
	    
	    //============================ Define Management Fee ============================================
	    if(mgmtFlg==true)
	    {
	    	JSONObject mgmtComm = new JSONObject();
	    	mgmtComm.put("commercialHeadName","ManagementFee");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("calculation").has("netOffCommercialHead"))
	    		mgmtComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("calculation").get("netOffCommercialHead"));
		    else	
		    	mgmtComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("commercialInformation").has("commercialType"))
	    		mgmtComm.put("commercialType",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(mgmtId).getJSONObject("advanceCommercial").getJSONObject("ManagementFee").getJSONObject("commercialInformation").get("commercialType"));
	    	else
	    		mgmtComm.put("commercialType","");
	    	mgmtComm.put("settlementTransactionWise","");
	    	mgmtComm.put("contractType","");
	    	mgmtComm.put("commissionable","");
	    	mgmtComm.put("markDownApplicable","");
	    	mgmtComm.put("markDownClientApplicable","");
	    	mgmtComm.put("minimumMarkUpPercentage","");
	    	mgmtComm.put("maximumMarkUpPercentage","");
	    	mgmtComm.put("markUpClientType","");
	    	mgmtComm.put("status","");
	    		    	
	    	commHead.put(mgmtComm);
	    }
	    
	    
	    commDefn.put("commercialHead",commHead);
		return commDefn;
	    }
		
	}



