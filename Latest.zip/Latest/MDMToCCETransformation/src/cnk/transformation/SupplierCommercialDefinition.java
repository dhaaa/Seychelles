package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SupplierCommercialDefinition {
	static  int ovrdngId=0,plbId=0;
	
public static JSONObject createCommercialDefinitionDT(JSONObject breDefn,JSONObject mdmDefn) throws JSONException{
		
		JSONObject commDefn =new JSONObject();
		commDefn.put("commercialName","definition");
		commDefn.put("type","definition");
		commDefn.put("supplier", mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId"));
		commDefn.put("supplierMarket",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
		commDefn.put("productCategorySubType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategorySubType"));
		boolean ovrdngFlg,plbFlg, dstnFlg, sgmtFlg, sctrFlg, srvcChrgFlg, mgmtFlg;
		ovrdngFlg=false;plbFlg=false;dstnFlg=false;sgmtFlg=false;sctrFlg=false;srvcChrgFlg=false;mgmtFlg=false; 
		String dstnId=null; String sgmtId=null; String sctrId=null; String srvcChrgId=null; String mgmtId=null;
		
	    //Define Commercial Head Array
	    JSONArray commHead =new JSONArray();
	    
	    //Define Standard Commercial
	    JSONObject stdComm = new JSONObject();
	    
	    if(mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
	    	stdComm.put("commercialHeadName","Standard");
	    	stdComm.put("nettOffCommercialHeadName","");
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").has("commercialType")){
	    	stdComm.put("commercialType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").get("commercialType"));
	    	}
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("isSettlementTransactionWise")){
	    	stdComm.put("settlementTransactionWise",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("isSettlementTransactionWise"));
	    	}
	    	stdComm.put("contractType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("commercialInformation").get("isProvisional"));
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("isCommisionable")){
	    	stdComm.put("commissionable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("isCommisionable"));
	    	}
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("applicable")){
	    	stdComm.put("markDownApplicable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("applicable"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("clientType")){
	    	stdComm.put("markDownClientApplicable",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("clientType"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("minimumPercent")){
	    	stdComm.put("minimumMarkUpPercentage",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("minimumPercent"));
	    	}
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").has("maximumPercent")){
	    		stdComm.put("maximumMarkUpPercentage",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markDown").get("maximumPercent"));
		    }
	    	
	    	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").has("clientType")){
	    		stdComm.put("markUpClientType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("calculation").getJSONObject("markUp").get("clientType"));
		    }
	       	stdComm.put("status","");
	 
	    }
	  
	    commHead.put(stdComm);			//Add Standard Commercial to Commercial Head Array
	     
	    
	    for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length() && mdmDefn.getJSONArray("advanceCommercialData").length()>0;i++)
	    {
	    	
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Overriding Commission"))
				{ ovrdngFlg=true;
				  ovrdngId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Productivity Linked Bonus"))
				{ plbFlg=true;
				  plbId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Destination Incentive"))
				{ dstnFlg=true;
				  dstnId=(String) mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).get("_id");
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Segment Fee"))
				{ sgmtFlg=true;
				  sgmtId=(String) mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).get("_id");				
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Sectorwise Incentive"))
				{ sctrFlg=true;
				  sctrId=(String) mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).get("_id");
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Service Charge"))
				{ srvcChrgFlg=true;
				  srvcChrgId=(String) mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).get("_id");
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Management Fee"))
				{ mgmtFlg=true;
				  mgmtId=(String) mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).get("_id");
				}
			    
	    }
	    
	    System.out.println(ovrdngId);
		System.out.println(plbId);
	    	//============================Define Overriding Commercial============================================
	    if(ovrdngFlg=true)
	    {
	    	JSONObject ovrdngComm = new JSONObject();
	    	ovrdngComm.put("commercialHeadName","Overriding");
	    	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("calculation").has("netOffCommercialHead"))
		    	ovrdngComm.put("nettOffCommercialHeadName",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(ovrdngId).getJSONObject("advanceCommercial").getJSONObject("overRidingCommission").getJSONObject("calculation").get("netOffCommercialHead"));
		    else	
		    	ovrdngComm.put("nettOffCommercialHeadName","");
	    	ovrdngComm.put("commercialType","");
		    ovrdngComm.put("settlementTransactionWise","");
		    ovrdngComm.put("contractType","");
		    ovrdngComm.put("commissionable","");
		    ovrdngComm.put("markDownApplicable","");
		    ovrdngComm.put("markDownClientApplicable","");
		    ovrdngComm.put("minimumMarkUpPercentage","");
		    ovrdngComm.put("maximumMarkUpPercentage","");
		    ovrdngComm.put("markUpClientType","");
		    ovrdngComm.put("status","");
	    	
	    	
	    	
	    	
	    	commHead.put(ovrdngComm);
	    }
	    	
	    
	    commDefn.put("commercialHead",commHead);
		return commDefn;
	    }
		
	}



