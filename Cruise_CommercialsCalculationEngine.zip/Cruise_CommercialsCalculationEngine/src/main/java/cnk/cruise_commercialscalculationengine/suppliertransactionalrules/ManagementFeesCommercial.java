package cnk.cruise_commercialscalculationengine.suppliertransactionalrules;

public class ManagementFeesCommercial {
	private java.lang.String selectedRow;

	   private cnk.cruise_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead;

	   private cnk.cruise_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding;
	   
	   private cnk.cruise_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb;
	   
	   private cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive;

	   private cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees;

	   private cnk.cruise_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge;

	   private cnk.cruise_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees;
	   
	
	   
	   private boolean advancedDefinitionCompleted;
	   
	   public boolean isAdvancedDefinitionCompleted() {
			return advancedDefinitionCompleted;
	   }

	   public void setAdvancedDefinitionCompleted(boolean advancedDefinitionCompleted) {
			this.advancedDefinitionCompleted = advancedDefinitionCompleted;
	   }

	   
	   public ManagementFeesCommercial()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public cnk.cruise_commercialscalculationengine.suppliertransactionalrules.CommercialHead getCommercialHead()
	   {
	      return this.commercialHead;
	   }

	   public void setCommercialHead(
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
	   {
	      this.commercialHead = commercialHead;
	   }

	   public cnk.cruise_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial getOverriding()
	   {
	      return this.overriding;
	   }

	   public void setOverriding(
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding)
	   {
	      this.overriding = overriding;
	   }
	   
	   public cnk.cruise_commercialscalculationengine.suppliertransactionalrules.PLBCommercial getPlb()
	   {
	      return this.plb;
	   }

	   public void setPlb(
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb)
	   {
	      this.plb = plb;
	   }
	  
	   public cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial getSectorWiseIncentive()
	   {
	      return this.sectorWiseIncentive;
	   }

	   public void setSectorWiseIncentive(
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive)
	   {
	      this.sectorWiseIncentive = sectorWiseIncentive;
	   }

	   public cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial getSegmentFees()
	   {
	      return this.segmentFees;
	   }

	   public void setSegmentFees(
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees)
	   {
	      this.segmentFees = segmentFees;
	   }

	   public cnk.cruise_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial getServiceCharge()
	   {
	      return this.serviceCharge;
	   }

	   public void setServiceCharge(
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge)
	   {
	      this.serviceCharge = serviceCharge;
	   }

	   public cnk.cruise_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial getIssuanceFees()
	   {
	      return this.issuanceFees;
	   }

	   public void setIssuanceFees(
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees)
	   {
	      this.issuanceFees = issuanceFees;
	   }

		   
	 
	     public ManagementFeesCommercial(
	         java.lang.String selectedRow,
	         cnk.cruise_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead )
	   {
	      this.selectedRow = selectedRow;
	      this.commercialHead = commercialHead;
	     }

	     
	     public ManagementFeesCommercial(
	             java.lang.String selectedRow,
	             cnk.cruise_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead,
	             cnk.cruise_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding,
	             cnk.cruise_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb,
	             cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive,
	             cnk.cruise_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees,
	             cnk.cruise_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge,
	             cnk.cruise_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees
				)
	       {
	          this.selectedRow = selectedRow;
	          this.commercialHead = commercialHead;
	          this.overriding = overriding;
	          this.plb = plb;
	          this.sectorWiseIncentive = sectorWiseIncentive;
	          this.segmentFees = segmentFees;
	          this.serviceCharge = serviceCharge;
	          this.issuanceFees = issuanceFees;
			 
	          
	       }
}
