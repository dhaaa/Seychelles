package cnk.transformation;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

public class MDMToCCETransformation {
	 static File file = new File("D:\\vasudha\\tr\\MDM\\InputFile1.json");
	//static File file = new File("E:\\Feb1\\Latest\\InputFile.json");
	 static JSONObject rootJson = new JSONObject();
	 static int ovrdngId=-1;
	 static int srvcChrgId=-1;
	 static int plbId=-1;
	 static int dstnId=-1;
	 static int sgmtId=-1;
	 static int sctrId=-1;
	 static int mgmtId=-1;

	 
	private static void readJSON() throws Exception {
		
		
	    String content = FileUtils.readFileToString(file, "utf-8");
	    JSONObject breDefn = new JSONObject(); 
	    JSONObject mdmDefn = new JSONObject(content);
	    
	   
	    for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length() && mdmDefn.getJSONArray("advanceCommercialData").length()>0;i++)
	    {
	    	
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Overriding Commission"))
				{ 
				  ovrdngId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Productivity Linked Bonus"))
				{
				  plbId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Destination Incentive"))
				{ 
				  dstnId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Segment Fee"))
				{ 
				  sgmtId=i;				
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Sectorwise Incentive"))
				{ 
				  sctrId=i;
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Service Charge"))
				{ 
				  srvcChrgId=i;
				  
				}
				if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Management Fee"))
				{ 
				  mgmtId=i;
				}
			    
	    }
	
	    JSONObject commDefn=SupplierCommercialDefinition.createCommercialDefinitionDT(breDefn,mdmDefn,ovrdngId,plbId,dstnId,sgmtId,sctrId,srvcChrgId,mgmtId);
	    rootJson.put("CommercialDefinitionDT",commDefn);
	    
	    if(mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial"))
	    {
	    JSONObject stdBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"Standard","standardCommercial",-1);
	    rootJson.put("StandardCommercialBaseDT",stdBaseJson);
	   
	    JSONObject stdCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"Standard","standardCommercial",-1);
	    rootJson.put("StandardCommercialCalculationDT",stdCalcJson);
	    }
	    
	    if(ovrdngId!=-1){
	    JSONObject ovrrdngBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"Overriding","overRidingCommission",ovrdngId);
	    rootJson.put("OverridingCommercialBaseDT",ovrrdngBaseJson);
	    
	    JSONObject ovrrdngCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"Overriding","overRidingCommission",ovrdngId);
	    rootJson.put("OverridingCommercialCalculationDT",ovrrdngCalcJson);
	    }
	    
	    if(plbId!=-1){
		    JSONObject plbBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"PLB","plb",plbId);
		    rootJson.put("OverridingCommercialBaseDT",plbBaseJson);
		    
		   // JSONObject plbCalcJson = SupplierCommercialOverridingCalculation.createOverridingCalculationDT(breDefn,mdmDefn);
		   // rootJson.put("OverridingCommercialCalculationDT",plbCalcJson);
		    }
	    
	    System.out.println(rootJson);
	}

	public static void main(String args[]){
		MDMToCCETransformation t = null;
		try {
			t.readJSON();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
