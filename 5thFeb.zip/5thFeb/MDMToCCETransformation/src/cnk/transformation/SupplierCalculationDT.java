package cnk.transformation;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SupplierCalculationDT {

	public static JSONObject createCalculationDT(JSONObject req,JSONObject mdmDefn,String commName,String mdmCommName,int id) throws JSONException{
		JSONObject calcJson = new JSONObject(); 
		
		calcJson.put("commercialName","Standard");
		calcJson.put("type","calculation");
		calcJson.put("supplier",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId"));
		calcJson.put("supplierMarket",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
		
		JSONArray tempChainArr=new JSONArray();
		JSONArray tempBrandArr=new JSONArray();
		JSONArray tempNameArr=new JSONArray();
		
		
		if(commName.equals("Standard"))
		{	
			for(int l=0;l<mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").length() && mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").length()>0;l++)
			{
			
				Object tempChainObj=mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).get("chain");
				Object tempBrandObj=mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).get("brand");
			 
				if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).has("name"))
					{
						Object tempNameObj = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").getJSONArray("productInformation").getJSONObject(l).get("name");
						tempNameArr.put(tempNameObj);
					}
				tempChainArr.put(tempChainObj);
				tempBrandArr.put(tempBrandObj);
			
			}
		}
		else
		{
			JSONObject tmp=new JSONObject();
			tmp=mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName);
			for(int l=0;l<tmp.getJSONArray("product").length() && tmp.getJSONArray("product").length()>0;l++)
			{
			
				Object tempChainObj=tmp.getJSONArray("product").getJSONObject(l).get("chain");
				Object tempBrandObj=tmp.getJSONArray("product").getJSONObject(l).get("brand");
			 
				if(tmp.getJSONArray("product").getJSONObject(l).has("name"))
					{
						Object tempNameObj = tmp.getJSONArray("product").getJSONObject(l).get("name");
						tempNameArr.put(tempNameObj);
					}
				tempChainArr.put(tempChainObj);
				tempBrandArr.put(tempBrandObj);
			
			}
		}
		calcJson.put("productChain",tempChainArr);
		calcJson.put("productBrand",tempBrandArr);
		calcJson.put("productName",tempNameArr);
		
		//=======================================Room Details=======================================================
				
		for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++)
		{
			 
			if((mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).get("_id").equals(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("advanceDefinitionsId"))
				||(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).get("_id").equals(mdmDefn.getJSONObject("advanceCommercialData").getJSONObject(mdmCommName).getJSONObject("advanceDefinationId")))) && mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategory").equals("Accommodation"))
			{
				JSONArray RoomDtlsInclsnArr=new JSONArray();
				JSONObject RoomDtlsObj=new JSONObject();
				JSONObject RoomDtlsInclsnObj=new JSONObject();
				
				if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").has("isInclusion") && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").get("isInclusion").equals(true))
				{
					
					JSONArray RoomCtgryInclsnArr=new JSONArray();
					JSONObject RoomCtgryInclsnObj=new JSONObject();
					
					for(int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").getJSONArray("roomCategories").length();j++)
					{
						RoomCtgryInclsnObj.put("roomCategory",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("others").getJSONObject("roomCategories").getJSONArray("roomCategories").get(j));
						RoomCtgryInclsnArr.put(RoomCtgryInclsnObj);
						
						
					}
					RoomDtlsInclsnObj.put("inclusion", RoomCtgryInclsnArr);
					RoomDtlsInclsnArr.put(RoomDtlsInclsnObj);
					
				}
				else
				{
					
					JSONArray RoomCtgryExclsnArr=new JSONArray();
					JSONObject RoomCtgryExclsnObj=new JSONObject();
					
					
						
				}
					
					//RoomExclsnObj.put("inclusion", RoomCtgryInclsnArr);
					RoomDtlsInclsnArr.put(RoomDtlsInclsnObj);
					calcJson.put("RoomDetails", RoomDtlsInclsnArr);
					
					
				}	
				
			}	
		
		if(commName.equals("Standard"))
		{
			JSONObject tempObj=new JSONObject();
			tempObj=mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			if(tempObj.has("fixed"))
			{
				if(tempObj.getJSONObject("fixed").get("isPercentage").equals(true))
				{
					calcJson.put("percentage",tempObj.getJSONObject("fixed").getJSONArray("percentageDetails").getJSONObject(0).get("valuePercentage"));
					calcJson.put("fareComponent",tempObj.getJSONObject("fixed").getJSONArray("percentageDetails").getJSONObject(0).get("farePriceComponents"));
				}
				if(tempObj.getJSONObject("fixed").get("isAmount").equals(true))
				{
					calcJson.put("amountValue",tempObj.getJSONObject("fixed").get("valueAmount"));
				}
				if(tempObj.getJSONObject("fixed").has("currency"))
					calcJson.put("currency",tempObj.getJSONObject("fixed").get("currency"));
			
			}
		}
		else
		{
			JSONObject tempObj=new JSONObject();
			tempObj=mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName);
			if(tempObj.has("fixed"))
			{
				if(tempObj.getJSONObject("fixed").get("isPercentage").equals(true))
				{
					calcJson.put("percentage",tempObj.getJSONObject("fixed").getJSONArray("percentageDetails").getJSONObject(0).get("valuePercentage"));
					calcJson.put("fareComponent",tempObj.getJSONObject("fixed").getJSONArray("percentageDetails").getJSONObject(0).get("farePriceComponents"));
				}
				if(tempObj.getJSONObject("fixed").get("isAmount").equals(true))
				{
					calcJson.put("amountValue",tempObj.getJSONObject("fixed").get("valueAmount"));
				}
				if(tempObj.getJSONObject("fixed").has("currency"))
					calcJson.put("currency",tempObj.getJSONObject("fixed").get("currency"));
			
			}
		}
		return calcJson;
	
	}
	
}
