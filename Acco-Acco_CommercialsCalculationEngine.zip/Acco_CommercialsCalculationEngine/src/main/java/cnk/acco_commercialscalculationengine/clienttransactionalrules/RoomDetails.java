package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RoomDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String roomType;
   private java.lang.String roomCategory;
   private boolean isAdvanced;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails;
   private double totalReceivables;
   private double totalPayables;
   private java.util.List<java.lang.String> commercialsApplied;
   private double totalFare;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials;

   public void ClientCommercialCalculation(String CommercialName, String CommercialType, String CommercialProperty, double RetentionPercentage, double RetentionAmountPercentage, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetls)
   {

      if (CommercialProperty.toUpperCase().equals("RETENTION"))
         CalculateRetentionCommercial(CommercialName, CommercialType, RetentionPercentage, RetentionAmountPercentage, entyDtls, roomDetls);
      else
         CalculateAdditionalCommercial(CommercialName, AdditionalPercentage, AdditionalAmount, FareComponent, TaxComponent, Currency, entyDtls, roomDetls);
   }

   public void CalculateRetentionCommercial(String CommercialName, String CommercialType, double RetentionPercentage, double RetentionAmountPercentage, EntityDetails entyDtls, RoomDetails roomDetls)
   {
      RetentionCommercialDetails retComDtls = new RetentionCommercialDetails();
      double tempAmount = 0;
      if (entyDtls.getParentEntityName() == null)
      {
         for (CommercialDetails commdetails : roomDetls.getCommercialDetails())
         {
            if (CommercialName.equals(commdetails.getCommercialName()))
            {
               if (RetentionAmountPercentage != 0)
               {
                  tempAmount = commdetails.getCommercialCalculationAmount() * (RetentionAmountPercentage / 100);
                  retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                  retComDtls.setRemainingAmount(commdetails.getCommercialCalculationAmount() - tempAmount);
               }
               if (RetentionPercentage != 0)
               {
                  double percentageAmount = 0;
                  if (commdetails.getCommercialCalculationAmount() != 0)
                  {
                     percentageAmount = (commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount()) * (RetentionPercentage / 100);
                     retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  else
                  {
                     percentageAmount = commdetails.getCommercialAmount() * (RetentionPercentage / 100);
                     retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  retComDtls.setRetentionPercentage(RetentionPercentage);
               }
               retComDtls.setCommercialAmount(tempAmount);
               retComDtls.setCommercialName(CommercialName);
            }

         }
      }
      else
      {
         for (EntityCommercials parentEntity : roomDetls.getEntityCommercials())
         {
            if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName()))
            {
               for (RetentionCommercialDetails retcommdetails : parentEntity.getRetentionCommercialDetails())
               {
                  if (CommercialName.equals(retcommdetails.getCommercialName()))
                  {
                     if (RetentionAmountPercentage != 0)
                     {
                        tempAmount = retcommdetails.getRemainingAmount() * (RetentionAmountPercentage / 100);
                        retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                        retComDtls.setRemainingAmount(retcommdetails.getRemainingAmount() - tempAmount);
                     }
                     if (RetentionPercentage != 0)
                     {
                        double percentageAmount = 0;
                        percentageAmount = retcommdetails.getRemainingPercentageAmount() * (RetentionPercentage / 100);
                        tempAmount = tempAmount + percentageAmount;
                        retComDtls.setRetentionPercentage(RetentionPercentage);
                        retComDtls.setRemainingPercentageAmount(retcommdetails.getRemainingPercentageAmount() - percentageAmount);
                     }
                     retComDtls.setCommercialAmount(tempAmount);
                     retComDtls.setCommercialName(CommercialName);
                  }
               }
            }
         }
      }
      if (roomDetls.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
         entityCommercials.getRetentionCommercialDetails().add(retComDtls);
         roomDetls.setEntityCommercials(new ArrayList<EntityCommercials>());
         roomDetls.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetls.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getRetentionCommercialDetails() == null)
                  entityComm.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
               entityComm.getRetentionCommercialDetails().add(retComDtls);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
            entityCommercials.getRetentionCommercialDetails().add(retComDtls);
            roomDetls.getEntityCommercials().add(entityCommercials);
         }

      }
      entyDtls.getEntityStatus().add(CommercialName + "RetentionCompleted");
   }

   public void CalculateAdditionalCommercial(String CommercialName, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetls) {

		AdditionalCommercialDetails addComm = new AdditionalCommercialDetails();
		addComm.setCommercialName(CommercialName);
		addComm.setCommercialFareComponent(FareComponent);

		if (AdditionalPercentage > 0) {
			addComm.setCommercialCalculationPercentage(AdditionalPercentage);
			if (TaxComponent == null) {
				if (FareComponent.equals("Total")) addComm.setCommercialAmount(roomDetls.getTotalFare() * AdditionalPercentage / 100);
				else addComm.setCommercialAmount(roomDetls.getFareBreakUp().getBaseFare() * AdditionalPercentage / 100);
			}
			else {
				if (FareComponent.equals("Basic")) addComm.setCommercialAmount(roomDetls.getFareBreakUp().getBaseFare());

				List < String > tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
				double commercialAmount = 0;
				for (TaxDetails taxes: roomDetls.getFareBreakUp().getTaxDetails()) {
					for (String tempTaxName: tempTaxDetails) {
						if (tempTaxName.equals(taxes.getTaxName())) {
							commercialAmount = commercialAmount + taxes.getTaxValue();
							if (addComm.getCommercialFareComponent() == null) addComm.setCommercialFareComponent(tempTaxName);
							else addComm.setCommercialFareComponent(addComm.getCommercialFareComponent() + "," + tempTaxName);
						}
					}
				}
				addComm.setCommercialAmount((addComm.getCommercialAmount() + commercialAmount) * AdditionalPercentage / 100);
			}
		}
		if (AdditionalAmount > 0) {
			addComm.setCommercialAmount(addComm.getCommercialAmount() + AdditionalAmount);
			if (addComm.getCommercialCurrency() == null) addComm.setCommercialCurrency(Currency);
			addComm.setCommercialCalculationAmount(AdditionalAmount);
		}

		if (roomDetls.getEntityCommercials() == null) {
			EntityCommercials entityCommercials = new EntityCommercials();
			entityCommercials.setEntityName(entyDtls.getEntityName());
			roomDetls.setEntityCommercials(new ArrayList < EntityCommercials > ());
			entityCommercials.setAdditionalCommercialDetails(new ArrayList < AdditionalCommercialDetails > ());
			entityCommercials.getAdditionalCommercialDetails().add(addComm);
			roomDetls.getEntityCommercials().add(entityCommercials);
		}
		else {
			boolean isEntityPresent = false;
			for (EntityCommercials entityComm: roomDetls.getEntityCommercials()) {
				if (entyDtls.getEntityName().equals(entityComm.getEntityName())) {
					if (entityComm.getAdditionalCommercialDetails() == null) entityComm.setAdditionalCommercialDetails(new ArrayList < AdditionalCommercialDetails > ());
					entityComm.getAdditionalCommercialDetails().add(addComm);
					isEntityPresent = true;
					break;
				}
			}
			if (isEntityPresent == false) {
				EntityCommercials entityCommercials = new EntityCommercials();
				entityCommercials.setEntityName(entyDtls.getEntityName());
				entityCommercials.setAdditionalCommercialDetails(new ArrayList < AdditionalCommercialDetails > ());
				entityCommercials.getAdditionalCommercialDetails().add(addComm);
				roomDetls.getEntityCommercials().add(entityCommercials);
			}

		}
		entyDtls.getEntityStatus().add(CommercialName + "AdditionalCompleted");
	}

    
    

   public RoomDetails()
   {
   }

   public java.lang.String getRoomType()
   {
      return this.roomType;
   }

   public void setRoomType(java.lang.String roomType)
   {
      this.roomType = roomType;
   }

   public java.lang.String getRoomCategory()
   {
      return this.roomCategory;
   }

   public void setRoomCategory(java.lang.String roomCategory)
   {
      this.roomCategory = roomCategory;
   }

   public boolean isIsAdvanced()
   {
      return this.isAdvanced;
   }

   public void setIsAdvanced(boolean isAdvanced)
   {
      this.isAdvanced = isAdvanced;
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp getFareBreakUp()
   {
      return this.fareBreakUp;
   }

   public void setFareBreakUp(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp)
   {
      this.fareBreakUp = fareBreakUp;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> getCommercialDetails()
   {
      return this.commercialDetails;
   }

   public void setCommercialDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails)
   {
      this.commercialDetails = commercialDetails;
   }

   public double getTotalReceivables()
   {
      return this.totalReceivables;
   }

   public void setTotalReceivables(double totalReceivables)
   {
      this.totalReceivables = totalReceivables;
   }

   public double getTotalPayables()
   {
      return this.totalPayables;
   }

   public void setTotalPayables(double totalPayables)
   {
      this.totalPayables = totalPayables;
   }

   public java.util.List<java.lang.String> getCommercialsApplied()
   {
      return this.commercialsApplied;
   }

   public void setCommercialsApplied(
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.commercialsApplied = commercialsApplied;
   }

   public double getTotalFare()
   {
      return this.totalFare;
   }

   public void setTotalFare(double totalFare)
   {
      this.totalFare = totalFare;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> getEntityCommercials()
   {
      return this.entityCommercials;
   }

   public void setEntityCommercials(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials)
   {
      this.entityCommercials = entityCommercials;
   }

   public RoomDetails(
         java.lang.String roomType,
         java.lang.String roomCategory,
         boolean isAdvanced,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails,
         double totalReceivables,
         double totalPayables,
         java.util.List<java.lang.String> commercialsApplied,
         double totalFare,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials)
   {
      this.roomType = roomType;
      this.roomCategory = roomCategory;
      this.isAdvanced = isAdvanced;
      this.fareBreakUp = fareBreakUp;
      this.commercialDetails = commercialDetails;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.commercialsApplied = commercialsApplied;
      this.totalFare = totalFare;
      this.entityCommercials = entityCommercials;
   }

}