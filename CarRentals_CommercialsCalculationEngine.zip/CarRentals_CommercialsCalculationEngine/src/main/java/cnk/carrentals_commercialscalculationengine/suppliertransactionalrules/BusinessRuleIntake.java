package cnk.carrentals_commercialscalculationengine.suppliertransactionalrules;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class BusinessRuleIntake implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition advancedDefinition;
   private cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommonElements commonElements;
   private java.lang.String ruleFlowName;
   private java.lang.String selectedRow;
   private java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommercialHead> commercialHead;
   private java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.SlabDetails> slabDetails;

   private java.util.List<java.lang.String> commercialStatus;

   private java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.VehicleDetails> vehicleDetails;

   public void appendStandardCommercialHeads(String CommercialHeadName, String CommercialType, String ContractType, boolean Commissionable, boolean MarkDownApplicable, String MarkDownClientType, double MinimumMarkUpPercentage, double MaximumMarkUpPercentage, String MarkUpClientType)
   {
      //this.setSelectedRow(this.getCommonElements().getSupplier()+"_"+this.getCommonElements().getSupplierMarket());
      CommercialHead commercialHead = new CommercialHead(CommercialHeadName, null, CommercialType, false, ContractType, Commissionable, MarkDownApplicable, MarkDownClientType, MinimumMarkUpPercentage, MaximumMarkUpPercentage, MarkUpClientType, null);
      this.setCommercialHead(new ArrayList<CommercialHead>());
      this.getCommercialHead().add(commercialHead);
   }

   public void appendCommercialHead(cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
        if (this.getCommercialHead() == null)
        {
             this.setCommercialHead(new ArrayList<CommercialHead>());
        }
        this.getCommercialHead().add(commercialHead);
      //  this.setSelectedRow(this.getCommonElements().getSupplierName()+"_"+this.getCommonElements().getSupplierMarket());
   }

   public BusinessRuleIntake()
   {
   }

   public cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition getAdvancedDefinition()
   {
      return this.advancedDefinition;
   }

   public void setAdvancedDefinition(
         cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition advancedDefinition)
   {
      this.advancedDefinition = advancedDefinition;
   }

   public cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommonElements getCommonElements()
   {
      return this.commonElements;
   }

   public void setCommonElements(
         cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommonElements commonElements)
   {
      this.commonElements = commonElements;
   }

   public java.lang.String getRuleFlowName()
   {
      return this.ruleFlowName;
   }

   public void setRuleFlowName(java.lang.String ruleFlowName)
   {
      this.ruleFlowName = ruleFlowName;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommercialHead> getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommercialHead> commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public java.util.List<java.lang.String> getCommercialStatus()
   {
      return this.commercialStatus;
   }

   public void setCommercialStatus(
         java.util.List<java.lang.String> commercialStatus)
   {
      this.commercialStatus = commercialStatus;
   }

   public java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.VehicleDetails> getVehicleDetails()
   {
      return this.vehicleDetails;
   }

   public void setVehicleDetails(
         java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.VehicleDetails> vehicleDetails)
   {
      this.vehicleDetails = vehicleDetails;
   }

   public BusinessRuleIntake(
         cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition advancedDefinition,
         cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommonElements commonElements,
         java.lang.String ruleFlowName,
         java.lang.String selectedRow,
         java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.CommercialHead> commercialHead,
         java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.SlabDetails> slabDetails,
         java.util.List<java.lang.String> commercialStatus,
         java.util.List<cnk.carrentals_commercialscalculationengine.suppliertransactionalrules.VehicleDetails> vehicleDetails)
   {
      this.advancedDefinition = advancedDefinition;
      this.commonElements = commonElements;
      this.ruleFlowName = ruleFlowName;
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
      this.slabDetails = slabDetails;
      this.commercialStatus = commercialStatus;
      this.vehicleDetails = vehicleDetails;
   }

}