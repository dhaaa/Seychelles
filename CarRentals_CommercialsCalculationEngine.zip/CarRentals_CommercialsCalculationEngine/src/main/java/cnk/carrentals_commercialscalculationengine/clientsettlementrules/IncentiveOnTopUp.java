package cnk.carrentals_commercialscalculationengine.clientsettlementrules;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
@JsonSerialize(include=Inclusion.NON_NULL)
public class IncentiveOnTopUp implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String contractType;
   private double commercialAmount;
   private java.lang.String commercialCurrency;
   private java.lang.String bankName;
   private java.util.Date topUpDateTime;
   private java.lang.String modeOfPayment;
   private double incentivePercentage;
   private double incentiveAmount;
   private java.lang.String incentiveCurrency;
   private java.lang.String incentiveRateType;
   private java.lang.String incentiveRateCode;
   private boolean isApplicable;

   private java.lang.String commercialType;

   public IncentiveOnTopUp()
   {
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public java.lang.String getCommercialCurrency()
   {
      return this.commercialCurrency;
   }

   public void setCommercialCurrency(java.lang.String commercialCurrency)
   {
      this.commercialCurrency = commercialCurrency;
   }

   public java.lang.String getBankName()
   {
      return this.bankName;
   }

   public void setBankName(java.lang.String bankName)
   {
      this.bankName = bankName;
   }

   public java.util.Date getTopUpDateTime()
   {
      return this.topUpDateTime;
   }

   public void setTopUpDateTime(java.util.Date topUpDateTime)
   {
      this.topUpDateTime = topUpDateTime;
   }

   public java.lang.String getModeOfPayment()
   {
      return this.modeOfPayment;
   }

   public void setModeOfPayment(java.lang.String modeOfPayment)
   {
      this.modeOfPayment = modeOfPayment;
   }

   public double getIncentivePercentage()
   {
      return this.incentivePercentage;
   }

   public void setIncentivePercentage(double incentivePercentage)
   {
      this.incentivePercentage = incentivePercentage;
   }

   public double getIncentiveAmount()
   {
      return this.incentiveAmount;
   }

   public void setIncentiveAmount(double incentiveAmount)
   {
      this.incentiveAmount = incentiveAmount;
   }

   public java.lang.String getIncentiveCurrency()
   {
      return this.incentiveCurrency;
   }

   public void setIncentiveCurrency(java.lang.String incentiveCurrency)
   {
      this.incentiveCurrency = incentiveCurrency;
   }

   public java.lang.String getIncentiveRateType()
   {
      return this.incentiveRateType;
   }

   public void setIncentiveRateType(java.lang.String incentiveRateType)
   {
      this.incentiveRateType = incentiveRateType;
   }

   public java.lang.String getIncentiveRateCode()
   {
      return this.incentiveRateCode;
   }

   public void setIncentiveRateCode(java.lang.String incentiveRateCode)
   {
      this.incentiveRateCode = incentiveRateCode;
   }

   public boolean isIsApplicable()
   {
      return this.isApplicable;
   }

   public void setIsApplicable(boolean isApplicable)
   {
      this.isApplicable = isApplicable;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public IncentiveOnTopUp(java.lang.String contractType, double commercialAmount,
         java.lang.String commercialCurrency, java.lang.String bankName,
         java.util.Date topUpDateTime, java.lang.String modeOfPayment,
         double incentivePercentage, double incentiveAmount,
         java.lang.String incentiveCurrency, java.lang.String incentiveRateType,
         java.lang.String incentiveRateCode, boolean isApplicable,
         java.lang.String commercialType)
   {
      this.contractType = contractType;
      this.commercialAmount = commercialAmount;
      this.commercialCurrency = commercialCurrency;
      this.bankName = bankName;
      this.topUpDateTime = topUpDateTime;
      this.modeOfPayment = modeOfPayment;
      this.incentivePercentage = incentivePercentage;
      this.incentiveAmount = incentiveAmount;
      this.incentiveCurrency = incentiveCurrency;
      this.incentiveRateType = incentiveRateType;
      this.incentiveRateCode = incentiveRateCode;
      this.isApplicable = isApplicable;
      this.commercialType = commercialType;
   }

}