package cnk.carrentals_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

@JsonSerialize(include=Inclusion.NON_NULL)
public class BusinessRuleIntake implements java.io.Serializable
{

   public void modifyIncentiveOnTopUp(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getIncentiveOnTopUp() != null)
      {

         this.getIncentiveOnTopUp().setCommercialType(commercialType);
         this.getIncentiveOnTopUp().setContractType(contractType);
         this.getIncentiveOnTopUp().setIsApplicable(isApplicable);
      }
   }

   public void modifyPenaltyFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getPenaltyFee() != null)
      {

         this.getPenaltyFee().setCommercialType(commercialType);
         this.getPenaltyFee().setContractType(contractType);
         this.getPenaltyFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyTerminationFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getTerminationFee() != null)
      {

         this.getTerminationFee().setCommercialType(commercialType);
         this.getTerminationFee().setContractType(contractType);
         this.getTerminationFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyMsfFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getMsfFee() != null)
      {

         this.getMsfFee().setCommercialType(commercialType);
         this.getMsfFee().setContractType(contractType);
         this.getMsfFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyMaintenanceFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getMaintenanceFee() != null)
      {

         this.getMaintenanceFee().getOtherFees().setCommercialType(commercialType);
         this.getMaintenanceFee().getOtherFees().setContractType(contractType);
         this.getMaintenanceFee().getOtherFees().setIsApplicable(isApplicable);
         this.getMaintenanceFee().getOtherFees().setRefundable(refundable);
         this.getMaintenanceFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyIntegrationFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getIntegrationFee() != null)
      {

         this.getIntegrationFee().getOtherFees().setCommercialType(commercialType);
         this.getIntegrationFee().getOtherFees().setContractType(contractType);
         this.getIntegrationFee().getOtherFees().setIsApplicable(isApplicable);
         this.getIntegrationFee().getOtherFees().setRefundable(refundable);
         this.getIntegrationFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyLicenceFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getLicenceFee() != null)
      {

         this.getLicenceFee().getOtherFees().setCommercialType(commercialType);
         this.getLicenceFee().getOtherFees().setContractType(contractType);
         this.getLicenceFee().getOtherFees().setIsApplicable(isApplicable);
         this.getLicenceFee().getOtherFees().setRefundable(refundable);
         this.getLicenceFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyWebServiceFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getWebServiceFee() != null)
      {

         this.getWebServiceFee().getOtherFees().setCommercialType(commercialType);
         this.getWebServiceFee().getOtherFees().setContractType(contractType);
         this.getWebServiceFee().getOtherFees().setIsApplicable(isApplicable);
         this.getWebServiceFee().getOtherFees().setRefundable(refundable);
         this.getWebServiceFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyLoyaltyBonus(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getLoyaltyBonus() != null)
      {

         this.getLoyaltyBonus().getOtherFees().setCommercialType(commercialType);
         this.getLoyaltyBonus().getOtherFees().setContractType(contractType);
         this.getLoyaltyBonus().getOtherFees().setIsApplicable(isApplicable);
         this.getLoyaltyBonus().getOtherFees().setRefundable(refundable);
         this.getLoyaltyBonus().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyPreferenceBenefit(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getPreferenceBenefit() != null)
      {

         this.getPreferenceBenefit().getOtherFees().setCommercialType(commercialType);
         this.getPreferenceBenefit().getOtherFees().setContractType(contractType);
         this.getPreferenceBenefit().getOtherFees().setIsApplicable(isApplicable);
         this.getPreferenceBenefit().getOtherFees().setRefundable(refundable);
         this.getPreferenceBenefit().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyRetainerFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getRetainerFee() != null)
      {

         this.getRetainerFee().getOtherFees().setCommercialType(commercialType);
         this.getRetainerFee().getOtherFees().setContractType(contractType);
         this.getRetainerFee().getOtherFees().setIsApplicable(isApplicable);
         this.getRetainerFee().getOtherFees().setRefundable(refundable);
         this.getRetainerFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyListingFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getListingFee() != null)
      {

         this.getListingFee().getOtherFees().setCommercialType(commercialType);
         this.getListingFee().getOtherFees().setContractType(contractType);
         this.getListingFee().getOtherFees().setIsApplicable(isApplicable);
         this.getListingFee().getOtherFees().setRefundable(refundable);
         this.getListingFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifySignUpFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getSignUpFee() != null)
      {

         this.getSignUpFee().getOtherFees().setCommercialType(commercialType);
         this.getSignUpFee().getOtherFees().setContractType(contractType);
         this.getSignUpFee().getOtherFees().setIsApplicable(isApplicable);
         this.getSignUpFee().getOtherFees().setRefundable(refundable);
         this.getSignUpFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyContentAccessFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getContentAccessFee() != null)
      {

         this.getContentAccessFee().getOtherFees().setCommercialType(commercialType);
         this.getContentAccessFee().getOtherFees().setContractType(contractType);
         this.getContentAccessFee().getOtherFees().setIsApplicable(isApplicable);
         this.getContentAccessFee().getOtherFees().setRefundable(refundable);
         this.getContentAccessFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifyTrainingFee(String commercialType, String contractType, boolean isApplicable, boolean refundable, boolean recurring)
   {

      if (this.getTrainingFee() != null)
      {

         this.getTrainingFee().getOtherFees().setCommercialType(commercialType);
         this.getTrainingFee().getOtherFees().setContractType(contractType);
         this.getTrainingFee().getOtherFees().setIsApplicable(isApplicable);
         this.getTrainingFee().getOtherFees().setRefundable(refundable);
         this.getTrainingFee().getOtherFees().setRecurring(recurring);
      }
   }

   public void modifySignUpBonus(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getSignUpBonus() != null)
      {

         this.getSignUpBonus().setCommercialType(commercialType);
         this.getSignUpBonus().setContractType(contractType);
         this.getSignUpBonus().setIsApplicable(isApplicable);
      }
   }

   public void modifyRemittanceFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getRemittanceFee() != null)
      {

         this.getRemittanceFee().setCommercialType(commercialType);
         this.getRemittanceFee().setContractType(contractType);
         this.getRemittanceFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyLookToBook(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getLookToBook() != null)
      {

         this.getLookToBook().setCommercialType(commercialType);
         this.getLookToBook().setContractType(contractType);
         this.getLookToBook().setIsApplicable(isApplicable);
      }
   }

   public void calculateTerminationFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getTerminationFee().getReturnableCommercialHead())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getTerminationFee().setCommercialAmount(this.getTerminationFee().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateMaintenanceFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getMaintenanceFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getMaintenanceFee().getOtherFees().setCommercialAmount(this.getMaintenanceFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateIntegrationFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getIntegrationFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getIntegrationFee().getOtherFees().setCommercialAmount(this.getIntegrationFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateLicenceFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getLicenceFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getLicenceFee().getOtherFees().setCommercialAmount(this.getLicenceFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateWebServiceFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getWebServiceFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getWebServiceFee().getOtherFees().setCommercialAmount(this.getWebServiceFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateLoyaltyBonus(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getLoyaltyBonus().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getLoyaltyBonus().getOtherFees().setCommercialAmount(this.getLoyaltyBonus().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculatePreferenceBenefit(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getPreferenceBenefit().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getPreferenceBenefit().getOtherFees().setCommercialAmount(this.getPreferenceBenefit().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateRetainerFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getRetainerFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getRetainerFee().getOtherFees().setCommercialAmount(this.getRetainerFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateListingFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getListingFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getListingFee().getOtherFees().setCommercialAmount(this.getListingFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateSignUpFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getSignUpFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getSignUpFee().getOtherFees().setCommercialAmount(this.getSignUpFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateContentAccessFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getContentAccessFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getContentAccessFee().getOtherFees().setCommercialAmount(this.getContentAccessFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateTrainingFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getTrainingFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getTrainingFee().getOtherFees().setCommercialAmount(this.getTrainingFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   static final long serialVersionUID = 1L;

   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.CommonElements commonElements;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.AdvancedDefinition advancedDefinition;
   private java.lang.String ruleFlowName;
   private java.lang.String selectedRow;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.IncentiveOnTopUp incentiveOnTopUp;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.PenaltyFee penaltyFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.TerminationFee terminationFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.MSFFee msfFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpBonus signUpBonus;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.RemittanceFee remittanceFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.LookToBook lookToBook;
   private EntityDetails entityDetails;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.TrainingFee trainingFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.ContentAccessFee contentAccessFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.MaintenanceFee maintenanceFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.IntegrationFee integrationFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpFee signUpFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.LicenceFee licenceFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.WebServiceFee webServiceFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.ListingFee listingFee;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.LoyaltyBonus loyaltyBonus;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.PreferenceBenefit preferenceBenefit;
   private cnk.carrentals_commercialscalculationengine.clientsettlementrules.RetainerFee retainerFee;
   private java.util.List<cnk.carrentals_commercialscalculationengine.clientsettlementrules.SlabDetails> slabDetails;

   public BusinessRuleIntake()
   {
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.CommonElements getCommonElements()
   {
      return this.commonElements;
   }

   public void setCommonElements(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.CommonElements commonElements)
   {
      this.commonElements = commonElements;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.AdvancedDefinition getAdvancedDefinition()
   {
      return this.advancedDefinition;
   }

   public void setAdvancedDefinition(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.AdvancedDefinition advancedDefinition)
   {
      this.advancedDefinition = advancedDefinition;
   }

   public java.lang.String getRuleFlowName()
   {
      return this.ruleFlowName;
   }

   public void setRuleFlowName(java.lang.String ruleFlowName)
   {
      this.ruleFlowName = ruleFlowName;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.IncentiveOnTopUp getIncentiveOnTopUp()
   {
      return this.incentiveOnTopUp;
   }

   public void setIncentiveOnTopUp(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.IncentiveOnTopUp incentiveOnTopUp)
   {
      this.incentiveOnTopUp = incentiveOnTopUp;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.PenaltyFee getPenaltyFee()
   {
      return this.penaltyFee;
   }

   public void setPenaltyFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.PenaltyFee penaltyFee)
   {
      this.penaltyFee = penaltyFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.TerminationFee getTerminationFee()
   {
      return this.terminationFee;
   }

   public void setTerminationFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.TerminationFee terminationFee)
   {
      this.terminationFee = terminationFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.MSFFee getMsfFee()
   {
      return this.msfFee;
   }

   public void setMsfFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.MSFFee msfFee)
   {
      this.msfFee = msfFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpBonus getSignUpBonus()
   {
      return this.signUpBonus;
   }

   public void setSignUpBonus(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpBonus signUpBonus)
   {
      this.signUpBonus = signUpBonus;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.RemittanceFee getRemittanceFee()
   {
      return this.remittanceFee;
   }

   public void setRemittanceFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.RemittanceFee remittanceFee)
   {
      this.remittanceFee = remittanceFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.LookToBook getLookToBook()
   {
      return this.lookToBook;
   }

   public void setLookToBook(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.LookToBook lookToBook)
   {
      this.lookToBook = lookToBook;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.TrainingFee getTrainingFee()
   {
      return this.trainingFee;
   }

   public void setTrainingFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.TrainingFee trainingFee)
   {
      this.trainingFee = trainingFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.ContentAccessFee getContentAccessFee()
   {
      return this.contentAccessFee;
   }

   public void setContentAccessFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.ContentAccessFee contentAccessFee)
   {
      this.contentAccessFee = contentAccessFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.MaintenanceFee getMaintenanceFee()
   {
      return this.maintenanceFee;
   }

   public void setMaintenanceFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.MaintenanceFee maintenanceFee)
   {
      this.maintenanceFee = maintenanceFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.IntegrationFee getIntegrationFee()
   {
      return this.integrationFee;
   }

   public void setIntegrationFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.IntegrationFee integrationFee)
   {
      this.integrationFee = integrationFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpFee getSignUpFee()
   {
      return this.signUpFee;
   }

   public void setSignUpFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpFee signUpFee)
   {
      this.signUpFee = signUpFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.LicenceFee getLicenceFee()
   {
      return this.licenceFee;
   }

   public void setLicenceFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.LicenceFee licenceFee)
   {
      this.licenceFee = licenceFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.WebServiceFee getWebServiceFee()
   {
      return this.webServiceFee;
   }

   public void setWebServiceFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.WebServiceFee webServiceFee)
   {
      this.webServiceFee = webServiceFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.ListingFee getListingFee()
   {
      return this.listingFee;
   }

   public void setListingFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.ListingFee listingFee)
   {
      this.listingFee = listingFee;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.LoyaltyBonus getLoyaltyBonus()
   {
      return this.loyaltyBonus;
   }

   public void setLoyaltyBonus(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.LoyaltyBonus loyaltyBonus)
   {
      this.loyaltyBonus = loyaltyBonus;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.PreferenceBenefit getPreferenceBenefit()
   {
      return this.preferenceBenefit;
   }

   public void setPreferenceBenefit(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.PreferenceBenefit preferenceBenefit)
   {
      this.preferenceBenefit = preferenceBenefit;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.RetainerFee getRetainerFee()
   {
      return this.retainerFee;
   }

   public void setRetainerFee(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.RetainerFee retainerFee)
   {
      this.retainerFee = retainerFee;
   }

   public java.util.List<cnk.carrentals_commercialscalculationengine.clientsettlementrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.carrentals_commercialscalculationengine.clientsettlementrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public cnk.carrentals_commercialscalculationengine.clientsettlementrules.EntityDetails getEntityDetails()
   {
      return this.entityDetails;
   }

   public void setEntityDetails(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.EntityDetails entityDetails)
   {
      this.entityDetails = entityDetails;
   }

   public BusinessRuleIntake(
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.CommonElements commonElements,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.AdvancedDefinition advancedDefinition,
         java.lang.String ruleFlowName,
         java.lang.String selectedRow,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.IncentiveOnTopUp incentiveOnTopUp,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.PenaltyFee penaltyFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.TerminationFee terminationFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.MSFFee msfFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpBonus signUpBonus,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.RemittanceFee remittanceFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.LookToBook lookToBook,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.EntityDetails entityDetails,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.TrainingFee trainingFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.ContentAccessFee contentAccessFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.MaintenanceFee maintenanceFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.IntegrationFee integrationFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.SignUpFee signUpFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.LicenceFee licenceFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.WebServiceFee webServiceFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.ListingFee listingFee,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.LoyaltyBonus loyaltyBonus,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.PreferenceBenefit preferenceBenefit,
         cnk.carrentals_commercialscalculationengine.clientsettlementrules.RetainerFee retainerFee,
         java.util.List<cnk.carrentals_commercialscalculationengine.clientsettlementrules.SlabDetails> slabDetails)
   {
      this.commonElements = commonElements;
      this.advancedDefinition = advancedDefinition;
      this.ruleFlowName = ruleFlowName;
      this.selectedRow = selectedRow;
      this.incentiveOnTopUp = incentiveOnTopUp;
      this.penaltyFee = penaltyFee;
      this.terminationFee = terminationFee;
      this.msfFee = msfFee;
      this.signUpBonus = signUpBonus;
      this.remittanceFee = remittanceFee;
      this.lookToBook = lookToBook;
      this.entityDetails = entityDetails;
      this.trainingFee = trainingFee;
      this.contentAccessFee = contentAccessFee;
      this.maintenanceFee = maintenanceFee;
      this.integrationFee = integrationFee;
      this.signUpFee = signUpFee;
      this.licenceFee = licenceFee;
      this.webServiceFee = webServiceFee;
      this.listingFee = listingFee;
      this.loyaltyBonus = loyaltyBonus;
      this.preferenceBenefit = preferenceBenefit;
      this.retainerFee = retainerFee;
      this.slabDetails = slabDetails;
   }

}