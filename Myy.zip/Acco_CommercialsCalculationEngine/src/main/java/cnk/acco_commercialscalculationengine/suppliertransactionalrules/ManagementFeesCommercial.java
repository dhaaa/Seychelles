package cnk.acco_commercialscalculationengine.suppliertransactionalrules;

public class ManagementFeesCommercial implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String selectedRow;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.DestinationIncentiveCommercial destinationIncentive;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge;

   private boolean advancedDefinitionCompleted;

   public ManagementFeesCommercial()
   {
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial getOverriding()
   {
      return this.overriding;
   }

   public void setOverriding(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding)
   {
      this.overriding = overriding;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial getPlb()
   {
      return this.plb;
   }

   public void setPlb(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb)
   {
      this.plb = plb;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.DestinationIncentiveCommercial getDestinationIncentive()
   {
      return this.destinationIncentive;
   }

   public void setDestinationIncentive(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.DestinationIncentiveCommercial destinationIncentive)
   {
      this.destinationIncentive = destinationIncentive;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial getSegmentFees()
   {
      return this.segmentFees;
   }

   public void setSegmentFees(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees)
   {
      this.segmentFees = segmentFees;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial getServiceCharge()
   {
      return this.serviceCharge;
   }

   public void setServiceCharge(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge)
   {
      this.serviceCharge = serviceCharge;
   }

   public ManagementFeesCommercial(
         java.lang.String selectedRow,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
   }

   public boolean isAdvancedDefinitionCompleted()
   {
      return this.advancedDefinitionCompleted;
   }

   public void setAdvancedDefinitionCompleted(boolean advancedDefinitionCompleted)
   {
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

   public ManagementFeesCommercial(
         java.lang.String selectedRow,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.DestinationIncentiveCommercial destinationIncentive,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge,
         boolean advancedDefinitionCompleted)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
      this.overriding = overriding;
      this.plb = plb;
      this.destinationIncentive = destinationIncentive;
      this.segmentFees = segmentFees;
      this.serviceCharge = serviceCharge;
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

}