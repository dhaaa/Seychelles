package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.util.ArrayList;

public class EntityDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String entityType;
   private java.lang.String entityName;
   private java.lang.String entityMarket;
   private java.lang.String parentEntityName;
   private java.lang.String selectedRow;
   private java.lang.String childEntityName;
   private java.util.List<java.lang.String> commercialsApplied;
   private java.util.List<java.lang.String> entityStatus;

   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> commercialHead;

   private java.lang.String standardSelectedRow;

   private java.lang.String markUpSelectedRow;

   private java.lang.String overridingSelectedRow;

   private java.lang.String plbSelectedRow;

   private java.lang.String serviceChargeSelectedRow;

   private java.lang.String sectorWiseIncentiveSelectedRow;

   private java.lang.String managementFeeSelectedRow;

   private java.lang.String discountSelectedRow;

   private java.lang.String destinationIncentiveSelectedRow;

   private java.lang.String segmentFeesSelectedRow;

   public void appendCommercials(String CommercialHeadName,
         String CommercialType, String CommercialProperty)
   {
      //this.setSelectedRow(this.getCommonElements().getSupplier()+"_"+this.getCommonElements().getSupplierMarket());
      CommercialHead commercialHead = new CommercialHead(CommercialHeadName,
            null,
            CommercialType, false,
            null, false,
            false, null,
            0.0, 0.0,
            null, null, CommercialProperty, true);
      if (this.getCommercialHead() == null)
         this.setCommercialHead(new ArrayList<CommercialHead>());
      this.getCommercialHead().add(commercialHead);

   }

   public EntityDetails()
   {
   }

   public java.lang.String getEntityType()
   {
      return this.entityType;
   }

   public void setEntityType(java.lang.String entityType)
   {
      this.entityType = entityType;
   }

   public java.lang.String getEntityName()
   {
      return this.entityName;
   }

   public void setEntityName(java.lang.String entityName)
   {
      this.entityName = entityName;
   }

   public java.lang.String getEntityMarket()
   {
      return this.entityMarket;
   }

   public void setEntityMarket(java.lang.String entityMarket)
   {
      this.entityMarket = entityMarket;
   }

   public java.lang.String getParentEntityName()
   {
      return this.parentEntityName;
   }

   public void setParentEntityName(java.lang.String parentEntityName)
   {
      this.parentEntityName = parentEntityName;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public java.lang.String getChildEntityName()
   {
      return this.childEntityName;
   }

   public void setChildEntityName(java.lang.String childEntityName)
   {
      this.childEntityName = childEntityName;
   }

   public java.util.List<java.lang.String> getCommercialsApplied()
   {
      return this.commercialsApplied;
   }

   public void setCommercialsApplied(
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.commercialsApplied = commercialsApplied;
   }

   public java.util.List<java.lang.String> getEntityStatus()
   {
      return this.entityStatus;
   }

   public void setEntityStatus(java.util.List<java.lang.String> entityStatus)
   {
      this.entityStatus = entityStatus;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public java.lang.String getStandardSelectedRow()
   {
      return this.standardSelectedRow;
   }

   public void setStandardSelectedRow(java.lang.String standardSelectedRow)
   {
      this.standardSelectedRow = standardSelectedRow;
   }

   public java.lang.String getMarkUpSelectedRow()
   {
      return this.markUpSelectedRow;
   }

   public void setMarkUpSelectedRow(java.lang.String markUpSelectedRow)
   {
      this.markUpSelectedRow = markUpSelectedRow;
   }

   public java.lang.String getOverridingSelectedRow()
   {
      return this.overridingSelectedRow;
   }

   public void setOverridingSelectedRow(java.lang.String overridingSelectedRow)
   {
      this.overridingSelectedRow = overridingSelectedRow;
   }

   public java.lang.String getPlbSelectedRow()
   {
      return this.plbSelectedRow;
   }

   public void setPlbSelectedRow(java.lang.String plbSelectedRow)
   {
      this.plbSelectedRow = plbSelectedRow;
   }

   public java.lang.String getServiceChargeSelectedRow()
   {
      return this.serviceChargeSelectedRow;
   }

   public void setServiceChargeSelectedRow(
         java.lang.String serviceChargeSelectedRow)
   {
      this.serviceChargeSelectedRow = serviceChargeSelectedRow;
   }

   public java.lang.String getSectorWiseIncentiveSelectedRow()
   {
      return this.sectorWiseIncentiveSelectedRow;
   }

   public void setSectorWiseIncentiveSelectedRow(
         java.lang.String sectorWiseIncentiveSelectedRow)
   {
      this.sectorWiseIncentiveSelectedRow = sectorWiseIncentiveSelectedRow;
   }

   public java.lang.String getManagementFeeSelectedRow()
   {
      return this.managementFeeSelectedRow;
   }

   public void setManagementFeeSelectedRow(
         java.lang.String managementFeeSelectedRow)
   {
      this.managementFeeSelectedRow = managementFeeSelectedRow;
   }

   public java.lang.String getDiscountSelectedRow()
   {
      return this.discountSelectedRow;
   }

   public void setDiscountSelectedRow(java.lang.String discountSelectedRow)
   {
      this.discountSelectedRow = discountSelectedRow;
   }

   public java.lang.String getDestinationIncentiveSelectedRow()
   {
      return this.destinationIncentiveSelectedRow;
   }

   public void setDestinationIncentiveSelectedRow(
         java.lang.String destinationIncentiveSelectedRow)
   {
      this.destinationIncentiveSelectedRow = destinationIncentiveSelectedRow;
   }

   public java.lang.String getSegmentFeesSelectedRow()
   {
      return this.segmentFeesSelectedRow;
   }

   public void setSegmentFeesSelectedRow(java.lang.String segmentFeesSelectedRow)
   {
      this.segmentFeesSelectedRow = segmentFeesSelectedRow;
   }

   public EntityDetails(
         java.lang.String entityType,
         java.lang.String entityName,
         java.lang.String entityMarket,
         java.lang.String parentEntityName,
         java.lang.String selectedRow,
         java.lang.String childEntityName,
         java.util.List<java.lang.String> commercialsApplied,
         java.util.List<java.lang.String> entityStatus,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> commercialHead,
         java.lang.String standardSelectedRow,
         java.lang.String markUpSelectedRow,
         java.lang.String overridingSelectedRow,
         java.lang.String plbSelectedRow,
         java.lang.String serviceChargeSelectedRow,
         java.lang.String sectorWiseIncentiveSelectedRow,
         java.lang.String managementFeeSelectedRow,
         java.lang.String discountSelectedRow,
         java.lang.String destinationIncentiveSelectedRow,
         java.lang.String segmentFeesSelectedRow)
   {
      this.entityType = entityType;
      this.entityName = entityName;
      this.entityMarket = entityMarket;
      this.parentEntityName = parentEntityName;
      this.selectedRow = selectedRow;
      this.childEntityName = childEntityName;
      this.commercialsApplied = commercialsApplied;
      this.entityStatus = entityStatus;
      this.commercialHead = commercialHead;
      this.standardSelectedRow = standardSelectedRow;
      this.markUpSelectedRow = markUpSelectedRow;
      this.overridingSelectedRow = overridingSelectedRow;
      this.plbSelectedRow = plbSelectedRow;
      this.serviceChargeSelectedRow = serviceChargeSelectedRow;
      this.sectorWiseIncentiveSelectedRow = sectorWiseIncentiveSelectedRow;
      this.managementFeeSelectedRow = managementFeeSelectedRow;
      this.discountSelectedRow = discountSelectedRow;
      this.destinationIncentiveSelectedRow = destinationIncentiveSelectedRow;
      this.segmentFeesSelectedRow = segmentFeesSelectedRow;
   }

}