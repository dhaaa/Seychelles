package cnk.acco_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)

public class TrainingFee implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees;

   public TrainingFee()
   {
   }

   public cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees getOtherFees()
   {
      return this.otherFees;
   }

   public void setOtherFees(
         cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

   public TrainingFee(
         cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

}