package cnk.transfers_commercialscalculationengine.suppliertransactionalrules;

public class DestinationIncentiveCommercial {

	
	private java.lang.String selectedRow;

	   private cnk.transfers_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead;

	   private cnk.transfers_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding;
	   
	   private cnk.transfers_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb;
	   
	   private cnk.transfers_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees;

	   private cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge;

	   private cnk.transfers_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees;

	   private cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees;

	   private boolean advancedDefinitionCompleted;
	   
	   public boolean isAdvancedDefinitionCompleted() {
			return advancedDefinitionCompleted;
	   }

	   public void setAdvancedDefinitionCompleted(boolean advancedDefinitionCompleted) {
			this.advancedDefinitionCompleted = advancedDefinitionCompleted;
	   }

	   public DestinationIncentiveCommercial()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public cnk.transfers_commercialscalculationengine.suppliertransactionalrules.CommercialHead getCommercialHead()
	   {
	      return this.commercialHead;
	   }

	   public void setCommercialHead(
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
	   {
	      this.commercialHead = commercialHead;
	   }

	   public cnk.transfers_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial getOverriding()
	   {
	      return this.overriding;
	   }

	   public void setOverriding(
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding)
	   {
	      this.overriding = overriding;
	   }
	   
	   public cnk.transfers_commercialscalculationengine.suppliertransactionalrules.PLBCommercial getPlb()
	   {
	      return this.plb;
	   }

	   public void setPlb(
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb)
	   {
	      this.plb = plb;
	   }
	  

	   public cnk.transfers_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial getSegmentFees()
	   {
	      return this.segmentFees;
	   }

	   public void setSegmentFees(
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees)
	   {
	      this.segmentFees = segmentFees;
	   }

	   public cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial getServiceCharge()
	   {
	      return this.serviceCharge;
	   }

	   public void setServiceCharge(
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge)
	   {
	      this.serviceCharge = serviceCharge;
	   }

	   public cnk.transfers_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial getIssuanceFees()
	   {
	      return this.issuanceFees;
	   }

	   public void setIssuanceFees(
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees)
	   {
	      this.issuanceFees = issuanceFees;
	   }

	   public cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial getManagementFees()
	   {
	      return this.managementFees;
	   }

	   public void setManagementFees(
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees)
	   {
	      this.managementFees = managementFees;
	   }
	   
	   
	     public DestinationIncentiveCommercial(
	         java.lang.String selectedRow,
	         cnk.transfers_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead )
	   {
	      this.selectedRow = selectedRow;
	      this.commercialHead = commercialHead;
	     }

	     
	     public DestinationIncentiveCommercial(
	             java.lang.String selectedRow,
	             cnk.transfers_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead,
	             cnk.transfers_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding,
	             cnk.transfers_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb,
	             cnk.transfers_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees,
	             cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge,
	             cnk.transfers_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees,
	             cnk.transfers_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees)
	       {
	          this.selectedRow = selectedRow;
	          this.commercialHead = commercialHead;
	          this.overriding = overriding;
	          this.plb = plb;
	          this.segmentFees = segmentFees;
	          this.serviceCharge = serviceCharge;
	          this.issuanceFees = issuanceFees;
	          this.managementFees = managementFees;
	       }



}
