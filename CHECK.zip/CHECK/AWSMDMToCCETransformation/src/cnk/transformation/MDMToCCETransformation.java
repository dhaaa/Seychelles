package cnk.transformation;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;

public class MDMToCCETransformation {
	//static File file = new File("D:\\Project\\5thFeb\\pls.json");
	static File file = new File("C:\\Users\\capiot\\Desktop\\test.json");
	
	 static JSONObject rootJson = new JSONObject();
	 static int ovrdngId=-1;
	 static int srvcChrgId=-1;
	 static int plbId=-1;
	 static int dstnId=-1;
	 static int sgmtId=-1;
	 static int sctrId=-1;
	 static int mgmtId=-1;
	 
	 public static String readJSON(String content) throws Exception {

		 JSONObject breDefn = new JSONObject(); 
		 JSONObject mdmDefn = new JSONObject(content);

		 if(mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial"))
		 {
			
			 if(mdmDefn.has("advanceCommercialData"))
			 {
				 for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length() && mdmDefn.getJSONArray("advanceCommercialData").length()>0;i++)
				 {
					 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Overriding Commission"))
					 { 						 
						 ovrdngId=i;						
					 }
					 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Productivity Linked Bonus"))
					 {
						 plbId=i;
					 }
					 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Destination Incentive"))
					 { 
						 dstnId=i;					 
					 }
					 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Segment Fee"))
					 { 
						 sgmtId=i;		
					 }
					 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Sectorwise Incentive"))
					 { 
						 sctrId=i;
					 }
					 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Service Charge"))
					 { 
						 srvcChrgId=i;
					 }
					 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject("commercialHeadInfo").get("displayName").equals("Management Fee"))
					 { 
						 mgmtId=i;
					 }

				 }

				 /* if(mgmtId!=-1){
		    JSONObject mgmtBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"ManagementFees","",mgmtId);
		    rootJson.put("ManagementFeeBaseDT",mgmtBaseJson);

		   JSONObject mgmtCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"ManagementFees","",mgmtId);
		   rootJson.put("ManagementFeeCalculationDT",mgmtCalcJson);
		}*/
			 } 
			 
			 JSONObject commDefn=SupplierCommercialDefinition.createCommercialDefinitionDT(breDefn,mdmDefn,ovrdngId,plbId,dstnId,sgmtId,sctrId,srvcChrgId,mgmtId);
			 rootJson.put("CommercialDefinitionDT",commDefn);
			 
			 JSONObject stdBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"Standard","standardCommercial",-1);
			 rootJson.put("StandardCommercialBaseDT",stdBaseJson);

			 JSONObject stdCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"Standard","standardCommercial",-1);
			 rootJson.put("StandardCommercialCalculationDT",stdCalcJson);
			 
			 if(ovrdngId>-1){	 
				 JSONObject ovrrdngBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"Overriding","overRidingCommission",ovrdngId);
				 rootJson.put("OverridingCommercialBaseDT",ovrrdngBaseJson);

				 JSONObject ovrrdngCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"Overriding","overRidingCommission",ovrdngId);
				 rootJson.put("OverridingCommercialCalculationDT",ovrrdngCalcJson);
			 }
			 
			 if(plbId>-1){	
				 JSONObject plbBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"PLB","plb",plbId);
				 rootJson.put("PLBCommercialBaseDT",plbBaseJson);

				 JSONObject plbCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"PLB","plb",plbId);
				 rootJson.put("PLBCommercialCalculationDT",plbCalcJson);
			 }
			 
			 if(dstnId>-1){
				 JSONObject dstnBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"DestinationIncentive","destinationIncentives",dstnId);
				 rootJson.put("DestinationIncentiveBaseDT",dstnBaseJson);

				 JSONObject dsthnCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"DestinationIncentive","destinationIncentives",dstnId);
				 rootJson.put("DestinationIncentiveCalculationDT",dsthnCalcJson);
			 }
			 
			 if(sgmtId>-1){
				 JSONObject sgmtBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"SegmentFees","segmentFees",sgmtId);
				 rootJson.put("SegmentFeeBaseDT",sgmtBaseJson);

				 JSONObject sgmtCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"SegmentFees","segmentFees",sgmtId);
				 rootJson.put("SegmentFeeCalculationDT",sgmtCalcJson);
			 }
			 
			 if(srvcChrgId>-1){
				 JSONObject srvcChrgBaseJson = SupplierBaseDT.createBaseDT(breDefn,mdmDefn,"ServiceCharge","serviceCharge",srvcChrgId);
				 rootJson.put("ServiceChargeBaseDT",srvcChrgBaseJson);

				 JSONObject srvcChrgCalcJson = SupplierCalculationDT.createCalculationDT(breDefn,mdmDefn,"ServiceCharge","serviceCharge",srvcChrgId);
				 rootJson.put("ServiceChargeCalculationDT",srvcChrgCalcJson);
			 }
		 }
		 return rootJson.toString();
	 }

	public static void main(String args[]){
		MDMToCCETransformation t = null;
	try {
		String content = FileUtils.readFileToString(file, "utf-8");
			String ip=t.readJSON(content).toString();
			System.out.println(ip);
			InvokeRuleConfigurator.invokeRuleConfigurator(ip,"accomodation","POST");
			//InvokeRuleConfigurator.invokeRuleConfigurator(t.readJSON());		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
