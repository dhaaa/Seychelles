package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SupplierBaseDT {
	
	public static JSONObject getCntrctValidity(JSONObject mdmDefn, int id,String mdmCommName){
		JSONObject cntrctVldty = new JSONObject(); 
		cntrctVldty.put("operator","BETWEEN");
		if(mdmCommName.equals("standardCommercial"))
		{
			cntrctVldty.put("from",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("contractValidityFrom").toString().substring(0,19));
			cntrctVldty.put("to",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("contractValidityTo").toString().substring(0,19));
		}
		else
		{
			cntrctVldty.put("from",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName).get("contractValidityFrom").toString().substring(0,19));
			cntrctVldty.put("to",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName).get("contractValidityTo").toString().substring(0,19));
		}
		return cntrctVldty;
	}
	
	public static JSONObject createBaseDT(JSONObject breDefn,JSONObject mdmDefn,String commName,String mdmCommName,int id) throws JSONException{
		 JSONObject baseJson = new JSONObject(); 
		 if(commName.equals("Standard"))
		 {	baseJson.put("RuleID",mdmDefn.getJSONObject("SupplierCommercialData").get("_id"));
		 	if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("contractValidityFrom"))
		 	{baseJson.put("contractValidity",getCntrctValidity(mdmDefn,id,mdmCommName));}
		 }
		 else
		 {	baseJson.put("RuleID",mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).get("_id"));
		  	if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName).has("contractValidityFrom"))
		 	{baseJson.put("contractValidity",getCntrctValidity(mdmDefn,id,mdmCommName));}
		 }
		 baseJson.put("selectedRow",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId").toString()+"_"+("Accomodation")+"_"+(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategorySubType")+"_"+(mdmDefn.getJSONObject("SupplierCommercialData").get("_id"))));
		// baseJson.put("commercialName",commName);
		 baseJson.put("type","base");
		// baseJson.put("productCategorySubType",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategorySubType"));
		// baseJson.put("supplier",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("supplierId"));
		// baseJson.put("supplierMarket",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").getJSONArray("supplierMarkets"));
		 baseJson.put("iataNumber",mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONObject("product").getJSONObject("accommodation").get("IATANumbers"));

		      
	     JSONArray tmpClient=new JSONArray();
	     if(commName.equals("Standard"))
	    	 {if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONArray("clients").length()>0)
	    	 tmpClient=mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getJSONArray("clients");}
	     else
	     { 
	    	 if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName).getJSONArray("client").length()>0)
	    	 tmpClient=mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName).getJSONArray("client");
	     }
	     
	     if(tmpClient.length()>0)
	     {
	    	 JSONArray clientTypeArr=new JSONArray();
		     JSONArray clientGroupArr=new JSONArray();
		     JSONArray clientNameArr=new JSONArray();

		     Object clientTypeObj=new JSONObject();
		     Object clientGroupObj=new JSONObject();
		     Object clientNameObj=new JSONObject();
	     
	    	 for(int t=0;t < tmpClient.length();t++)
	    	 {
	    		 if(tmpClient.getJSONObject(t).has("clientType"))
	    		 {clientTypeObj=tmpClient.getJSONObject(t).get("clientType");
	    		 clientTypeArr.put(clientTypeObj);
	    		 }
	    		 if(tmpClient.getJSONObject(t).has("clientGroup"))
	    		 {clientGroupObj=tmpClient.getJSONObject(t).get("clientGroup");
	    		 clientGroupArr.put(clientGroupObj);
	    		 }
	    		 if(tmpClient.getJSONObject(t).has("clientName"))
	    		 {clientNameObj=tmpClient.getJSONObject(t).get("clientName");
	    		 clientNameArr.put(clientNameObj);
	    		 }
	    	 }
	
         if(clientTypeArr.length()>0)
        	 baseJson.put("clientType", clientTypeArr);
         if(clientGroupArr.length()>0)
	     baseJson.put("clientGroup", clientGroupArr);
         if(clientNameArr.length()>0)
	     baseJson.put("clientName", clientNameArr);
	     }
	     
		//------------Find Matching Advanced Definition for Standard Commercials of Accommodation ------------------
	 		Object tmp=new Object();
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++)
			{
			
				if(commName.equals("Standard"))
					if(mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("advanceDefinationId").toString().length()>0)
					{tmp=mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").get("advanceDefinationId");}
					else
					{tmp=null;}
				else
					if(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName).get("advanceDefinationId").toString().length()>0)
					{tmp=mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(id).getJSONObject("advanceCommercial").getJSONObject(mdmCommName).get("advanceDefinationId");}
					else
					{tmp=null;}
				if(tmp!=null)
				{
				if(tmp.equals(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).get("_id")) && mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition").get("productCategory").equals("Accommodation"))
				{
					
					 JSONArray saleArr=new JSONArray();
					 //JSONObject saleObj=new JSONObject();
					 JSONObject InclsnsaleObj=new JSONObject();
					 JSONObject ExclsnsaleObj=new JSONObject();
					 JSONArray travelArr=new JSONArray();
					 //JSONObject travelObj=new JSONObject();
					 JSONObject InclsnTravelObj=new JSONObject();
					 JSONObject ExclsnTravelObj=new JSONObject();
					 JSONArray saleInclsnArr=new JSONArray();
					 JSONArray saleExclsnArr=new JSONArray();
					 JSONArray travelInclsnArr=new JSONArray();
					 JSONArray travelExclsnArr=new JSONArray();
					 					 
					if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").has("validityType"))
					{ 
						if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").get("validityType").equals("sale"))
						{
						  for (int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("sale").length() && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("sale").length()>0;j++)
						  {
							          //-------Inclusion and Exclusion Object creation -----------
							  JSONObject saleInclsnObj=new JSONObject(); 
							  JSONObject mdmInclsnExclsnObj=new JSONObject();
							  JSONObject saleExclsnObj=new JSONObject(); 
							  mdmInclsnExclsnObj=mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("sale").getJSONObject(j);
						   	  if(mdmInclsnExclsnObj.has("saleFrom")){
						   		saleInclsnObj.put("operator","BETWEEN");
						   		saleInclsnObj.put("from",mdmInclsnExclsnObj.get("saleFrom").toString().substring(0,19));
						   		saleInclsnObj.put("to",mdmInclsnExclsnObj.get("saleTo").toString().substring(0,19));
						   		saleInclsnArr.put(saleInclsnObj);
						   		System.out.println(saleInclsnArr);
						 	   }
						 	 
						 	  if(mdmInclsnExclsnObj.has("blockOutFrom")){
						 		saleExclsnObj.put("operator","BETWEEN");
						 		saleExclsnObj.put("from",mdmInclsnExclsnObj.get("blockOutFrom").toString().substring(0,19));
						 		saleExclsnObj.put("to",mdmInclsnExclsnObj.get("blockOutTo").toString().substring(0,19));
						 		saleExclsnArr.put(saleExclsnObj);
						 	   }
						 	
						   }
						  if(saleInclsnArr.length()>0)
							  InclsnsaleObj.put("inclusion",saleInclsnArr);
						  	  saleArr.put(InclsnsaleObj);
						  if(saleExclsnArr.length()>0)
							  ExclsnsaleObj.put("exclusion",saleExclsnArr);
						  saleArr.put(ExclsnsaleObj);
						  System.out.println(saleArr);
						  baseJson.put("sale",saleArr);
					    }
					    else if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").get("validityType").equals("travel"))
					    {
					    	
					    	for (int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("travel").length() && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("travel").length()>0;j++)
					    	{
					          //-------Inclusion and Exclusion Object creation -----------
							 JSONObject travelInclsnObj=new JSONObject(); 
							 JSONObject mdmInclsnExclsnObj=new JSONObject();
							 JSONObject travelExclsnObj=new JSONObject(); 
							 mdmInclsnExclsnObj=mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("travel").getJSONObject(j);
							 	if(mdmInclsnExclsnObj.has("travelFrom")){
							 		travelInclsnObj.put("operator","BETWEEN");
							 		travelInclsnObj.put("from",mdmInclsnExclsnObj.get("travelFrom").toString().substring(0,19));
							 		travelInclsnObj.put("to",mdmInclsnExclsnObj.get("travelTo").toString().substring(0,19));
							 	}
							  travelInclsnArr.put(travelInclsnObj);
							 	if(mdmInclsnExclsnObj.has("blockOutFrom")){
							 		travelExclsnObj.put("operator","BETWEEN");
							 		travelExclsnObj.put("from",mdmInclsnExclsnObj.get("blockOutFrom").toString().substring(0,19));
							 		travelExclsnObj.put("to",mdmInclsnExclsnObj.get("blockOutTo").toString().substring(0,19));
							 	}
							 	travelExclsnArr.put(travelExclsnObj);
						     }
					    	if(travelInclsnArr.length()>0)
					    		InclsnTravelObj.put("inclusion",travelInclsnArr);
					    		travelArr.put(InclsnTravelObj);
					    	if(travelExclsnArr.length()>0)
					    		ExclsnTravelObj.put("exclusion",travelExclsnArr);
					    		travelArr.put(ExclsnTravelObj);
					    	baseJson.put("travel",travelArr);
					    }
					    else{
					    	if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").has("salePlusTravel")){
						 	for (int j=0;j<mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("salePlusTravel").length() && mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("salePlusTravel").length()>0;j++)
						 	{
					          //-------Inclusion and Exclusion Object creation -----------
							 		JSONObject saleInclsnObj=new JSONObject(); 
							 		JSONObject travelInclsnObj=new JSONObject(); 
							 		JSONObject mdmInclsnExclsnObj=new JSONObject();
							 		JSONObject saleExclsnObj=new JSONObject();
							 		JSONObject travelExclsnObj=new JSONObject(); 
							 		mdmInclsnExclsnObj=mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("validity").getJSONArray("salePlusTravel").getJSONObject(j);
							 		
							 		if(mdmInclsnExclsnObj.has("sales")){
							 			
							 			if(mdmInclsnExclsnObj.getJSONObject("sales").has("saleFrom")){
							 				saleInclsnObj.put("operator","BETWEEN");
							 				saleInclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("sales").get("saleFrom").toString().substring(0,19));
							 				saleInclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("sales").get("saleTo").toString().substring(0,19));
							 			 }
							 		    saleInclsnArr.put(saleInclsnObj);
							 		 	if(mdmInclsnExclsnObj.getJSONObject("sales").has("blockOutFrom")){
							 		 	 saleExclsnObj.put("operator","BETWEEN");
							 		 	 saleExclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("sales").get("blockOutFrom").toString().substring(0,19));
							 		 	 saleExclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("sales").get("blockOutTo").toString().substring(0,19));
							 		 	}
							 		 	 saleExclsnArr.put(saleExclsnObj);
							 		 	
							 		}
							 		if(mdmInclsnExclsnObj.has("travel")){
							 			if(mdmInclsnExclsnObj.getJSONObject("travel").has("travelFrom")){
							 				travelInclsnObj.put("operator","BETWEEN");
							 				travelInclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("travel").get("travelFrom").toString().substring(0,19));
							 				travelInclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("travel").get("travelTo").toString().substring(0,19));
							 			 }
							 		    travelInclsnArr.put(travelInclsnObj);
							 		 	if(mdmInclsnExclsnObj.getJSONObject("travel").has("blockOutFrom")){
							 		 		
							 		 		travelExclsnObj.put("operator","BETWEEN");
							 		 		travelExclsnObj.put("from",mdmInclsnExclsnObj.getJSONObject("travel").get("blockOutFrom").toString().substring(0,19));
							 		 		travelExclsnObj.put("to",mdmInclsnExclsnObj.getJSONObject("travel").get("blockOutTo").toString().substring(0,19));
							 		 	}
							 		 	travelExclsnArr.put(travelExclsnObj);
							 		}
						 	  }
						 	  if(saleInclsnArr.length()>0)
						 		 InclsnsaleObj.put("inclusion",saleInclsnArr);
						 	  	 saleArr.put(InclsnsaleObj);
						 	  if(saleExclsnArr.length()>0)
						 		 ExclsnsaleObj.put("exclusion",saleExclsnArr);
						 	  	 saleArr.put(ExclsnsaleObj);
						 	  if(travelInclsnArr.length()>0)
						 		 InclsnTravelObj.put("inclusion",travelInclsnArr);
						 	     travelArr.put(InclsnTravelObj);
						 	  if(travelExclsnArr.length()>0)
						 		 ExclsnTravelObj.put("exclusion",travelExclsnArr);
						 	  	 travelArr.put(ExclsnTravelObj);
						 	 baseJson.put("sale",saleArr);
						 	baseJson.put("travel",travelArr);
					    }
					       }
						}				
					
					 // -------------------------------Create Travel Destination array --------------------------------------------
						
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").has("travelDestination") &&
						 mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("travelDestination").getJSONArray("destinations").length()>0)
					 {
						 JSONArray travelDstnArr=new JSONArray();
						 JSONObject travelDstnInclsnObj=new JSONObject();
						 JSONObject travelDstnExclsnObj=new JSONObject();
						 
						 JSONArray dstnInclsnArr=new JSONArray();
						 JSONObject dstnInclsnObj=new JSONObject();
						 JSONArray dstnExclsnArr=new JSONArray();
						 JSONObject dstnExclsnObj=new JSONObject();
						 
						 JSONObject tmpObj=new JSONObject();
						 tmpObj = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation");
						 
						 for (int k=0;k<tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").length();k++)
						 {
							 
							if(tmpObj.getJSONObject("travelDestination").get("isInclusion").equals(true)){
								 
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("continent") && tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("continent")!="ALL")
									 dstnInclsnObj.put("tocontinent",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("continent"));
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("country") && tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("country")!="ALL")
									 dstnInclsnObj.put("tocountry",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("country"));
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("state") && tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("state")!="ALL")
								 	dstnInclsnObj.put("tostate",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("state"));
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("city") && tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("city")!="ALL")
									 dstnInclsnObj.put("tocity",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("city"));
								 
								 JSONObject dstnTmp=new JSONObject();
								 JSONArray dstnArr=new JSONArray();
								 dstnArr.put(dstnInclsnObj);
								 dstnTmp.put("to", dstnArr);
								 dstnInclsnArr.put(dstnTmp);
							}
							else
							{
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("continent"))
								 	dstnExclsnObj.put("tocontinent",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("continent"));
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("country"))
									dstnExclsnObj.put("tocountry",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("country"));
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("state"))
									 dstnExclsnObj.put("tostate",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("state"));
								 if(tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).has("city"))
									 dstnExclsnObj.put("tocity",tmpObj.getJSONObject("travelDestination").getJSONArray("destinations").getJSONObject(k).get("city"));
								 
								 
								 JSONObject dstnTmp=new JSONObject();
								 JSONArray dstnArr=new JSONArray();
								 dstnArr.put(dstnExclsnObj);
								 dstnTmp.put("to",dstnArr);
								 dstnExclsnArr.put(dstnTmp);
							}	
						 }	 
						 travelDstnInclsnObj.put("inclusion",dstnInclsnArr);
						 travelDstnExclsnObj.put("exclusion",dstnExclsnArr);
						 travelDstnArr.put(travelDstnInclsnObj);
						 travelDstnArr.put(travelDstnExclsnObj);
						 baseJson.put("travelDestination",travelDstnArr);
					 }		 
						
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").has("connectivity"))
					 {
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").get("supplierType").toString().length()>0)
						 baseJson.put("connectivitySupplierType",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").get("supplierType"));
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").get("supplierId").toString().length()>0)
						 baseJson.put("connectivitySupplierName",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONObject("connectivity").get("supplierId"));
					 }
					 if(mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").getJSONArray("credentials").length()>0)
						 baseJson.put("credentialsName",mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i).getJSONObject("advanceDefinitionAccommodation").get("credentials"));
				  }	
				}
				}
		 return baseJson;	
	}

}
